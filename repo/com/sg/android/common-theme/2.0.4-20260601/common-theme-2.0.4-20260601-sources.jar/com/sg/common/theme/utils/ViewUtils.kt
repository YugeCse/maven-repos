package com.sg.common.theme.utils

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import com.sg.common.theme.BuildConfig


/** 获取状态栏高度，单位：pixel **/
val Context.statusBarHeight: Int
    @SuppressLint("PrivateApi", "LogNotTimber")
    get() {
        val defaultHeightValue = 75
        runCatching {
            getPxDimensionSizeById(
                getResourceId(
                    "status_bar_height",
                    "dimen",
                    "android"
                )
            )
        }.let { result ->
            result.exceptionOrNull()?.let { e ->
                if (BuildConfig.DEBUG) {
                    Log.e("AppUtils", e.message ?: "")
                }
            }
        }
        return defaultHeightValue
    }

/** 获取ActionBar高度 **/
val Context.actionBarHeight: Int
    get() = resources.getDimensionPixelSize(androidx.appcompat.R.dimen.abc_action_bar_default_height_material)

/** 获取底部导航栏高度，单位：pixel **/
val Context.bottomNavigationBarHeight: Int
    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    get() = resources.getDimensionPixelSize(
        resources.getIdentifier("navigation_bar_height", "dimen", "android")
    )