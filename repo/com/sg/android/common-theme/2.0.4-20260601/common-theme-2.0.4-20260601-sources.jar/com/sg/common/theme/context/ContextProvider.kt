package com.sg.common.theme.context

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context

/**
 * 提供Context实例的类
 * @param context 上下文对象
 */
internal class ContextProvider private constructor(val context: Context) {

    companion object {

        @Volatile
        @SuppressLint("StaticFieldLeak")
        private var instance: ContextProvider? = null

        /** 获取实例 **/
        fun get(): ContextProvider {
            if (instance == null) {
                synchronized(ContextProvider::class.java) {
                    if (instance == null) {
                        val context: Context = InnerContextProvider.context
                            ?: throw IllegalStateException("ContextProvider：context == null, InnerConetxtProvider未能提供正确的context对象！")
                        instance = ContextProvider(context)
                    }
                }
            }
            return instance!!
        }
    }

    /** application实例 **/
    val application: Application
        get() = context.applicationContext as Application

}