package com.sg.common.theme

import android.content.Context
import androidx.annotation.StringRes
import com.sg.common.theme.utils.sp2px
import kotlin.math.absoluteValue

/**
 * 字体缩放等级封装类
 * @param value 代表值，如果被选中，对应的等级的值会被存储在本地记录中
 * @param offset 字体计算时用的增量值，单位为：sp
 * @param textId 文本资源ID
 * @param trackingValue 埋点取值命名
 * @param webAssignFontSize 网站分配的字体大小, 对应JS方法取值：window.android.appFontSize(): String
 *
 * @date 2024-04-06 14:27
 * @author huangzhongyu@sph.com.sg
 */
enum class TypographyScaleType(
    val value: Int,
    val offset: Int,
    @param:StringRes val textId: Int,
    val trackingValue: String,
    val webAssignFontSize: String
) {

    // /** 超小，取值-2 **/
    // @Deprecated("该值在当前应用中无效，已废弃")
    // data object XSmall : ArticleFontSizeLevel(-2, R.string.common_article_font_size_x_small)

    /**超小，取值-1 **/
    Small(-1, -2, R.string.__common_article_font_size_small, "small", "16"),

    /** 标准，取值0 **/
    Standard(0, 0, R.string.__common_article_font_size_standard, "standard", "18"),

    /** 中，取值1 **/
    Medium(1, 2, R.string.__common_article_font_size_medium, "medium", "20"),

    /** 大，取值2 **/
    Large(2, 6, R.string.__common_article_font_size_large, "large", "24"),

    /** 超大，取值3 **/
    XLarge(3, 10, R.string.__common_article_font_size_x_large, "extra large", "28"),

    /** 特大，取值4 **/
    ExtraLarge(4, 18, R.string.__common_article_font_size_extra_large, "super extra large", "36");

    companion object {

        /**
         * 获取所有文字缩放类型文字描述
         * @param context 上下文
         */
        @JvmStatic
        fun getAllScaleDescriptions(context: Context): List<String> =
            entries.map { context.getString(it.textId) }.toList()

        /** 为新闻栏目重新计算缩放类型 **/
        @JvmStatic
        context(origin: TypographyScaleType)
        val calculateForNewsColumn: TypographyScaleType
            get() {
                return when (origin) {
                    Small -> Small
                    Standard -> Standard
                    Medium, Large, XLarge, ExtraLarge -> Medium
                }
            }

        /** 为新闻列表重新计算缩放类型 **/
        @JvmStatic
        context(origin: TypographyScaleType)
        val calculateForNewsList: TypographyScaleType
            get() {
                return when (origin) {
                    Small, Standard -> Standard
                    Medium -> Medium
                    Large -> Large
                    XLarge, ExtraLarge -> XLarge
                }
            }

        /** 获取与标准计算的缩放倍率 **/
        @JvmStatic
        fun TypographyScaleType.calculateScale(type: TypographyType): Float {
            val curFontValue = type.fontValue + offset
            val standardFontValue = type.fontValue + Standard.offset
            return curFontValue.toFloat() / standardFontValue.toFloat()
        }

        /** 获取所有字体的缩放映射表 **/
        @JvmStatic
        fun getAllTypographyScaleMap(): List<Map<String, Any>> {
            return entries.map {
                mapOf(
                    "name" to it.name,
                    "offset" to it.offset.run {
                        val value = Dimens.singleton()
                            .getTextUnitFromValue(it.offset.absoluteValue)
                            .value
                        (if (this < 0) value * -1.0f else value).sp2px
                    }
                )
            }
        }

    }

}

/** Int转换为文章字号等级，转换失败默认为Standard **/
fun Int.toTypographyScaleType(): TypographyScaleType = when (this) {
    TypographyScaleType.Small.value -> TypographyScaleType.Small
    TypographyScaleType.Standard.value -> TypographyScaleType.Standard
    TypographyScaleType.Medium.value -> TypographyScaleType.Medium
    TypographyScaleType.Large.value -> TypographyScaleType.Large
    TypographyScaleType.XLarge.value -> TypographyScaleType.XLarge
    TypographyScaleType.ExtraLarge.value -> TypographyScaleType.ExtraLarge
    else -> TypographyScaleType.Standard
}

/**
 * 转换老项目中的字体缩放到新的字号等级类，转换失败时默认返回Standard
 * [查看文字等级修复的文档说明](https://sph.atlassian.net/wiki/spaces/ZBCQ/pages/1709375490/2024.04.25+APP)
 */
fun Int.convertOldFontScaleToTypographyScaleType(): TypographyScaleType {
    return if (this == 89) TypographyScaleType.Small
    else if (this in arrayOf(100, 122)) TypographyScaleType.Standard
    else if (this in arrayOf(111, 156)) TypographyScaleType.Medium
    else if (this in arrayOf(133, 166)) TypographyScaleType.Large
    else if (this == 181) TypographyScaleType.XLarge
    else if (this == 200) TypographyScaleType.ExtraLarge
    else TypographyScaleType.Standard
}
