package com.sg.common.theme.utils

import android.annotation.SuppressLint
import android.content.Context


/**
 * 获取资源Id
 * @param name 资源名称
 * @param defType 资源类型，例如：mipmap, drawable ...
 * @param defPackage 资源所在包名
 */
@SuppressLint("DiscouragedApi")
fun Context.getResourceId(name: String?, defType: String?, defPackage: String?) =
    resources.getIdentifier(name, defType, defPackage)