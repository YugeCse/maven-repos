package com.sg.common.theme

import android.util.Log
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/**
 * SPH应用配色实体类
 * @author Hwang huangzhongyu@sph.com.sg
 */
@Stable
data class SphAppColorScheme(
    val dividerPrimary: Color,
    val dividerPrimaryOnDark: Color,
    val dividerSecondary: Color,
    val dividerBrand: Color,
    val dividerSubscriber: Color,
    val dividerHighlightPrimary: Color,
    val dividerHighlightSecondary: Color,

    val iconPrimaryDefault: Color,
    val iconSecondaryDefault: Color,
    val iconOnDarkDefault: Color,
    val iconOnDarkHover: Color,
    val iconInverseDefault: Color,
    val iconEmphasis: Color,
    val iconBrandPrimaryDefault: Color,
    val iconBrandPrimaryActive: Color,
    val iconBrandSecondary: Color,
    val iconSuccessDefault: Color,
    val iconAlertDefault: Color,
    val iconAlertHover: Color,
    val iconFlagChina: Color,
    val iconFlagSingapore: Color,

    val inputBorderDefault: Color,
    val inputBorderActive: Color,
    val inputBorderError: Color,
    val inputTextLabel: Color,
    val inputTextInput: Color,
    val inputTextError: Color,
    val inputTextSuccess: Color,

    val linkInComponentPrimary: Color,
    val linkInComponentOnDark: Color,
    val linkInComponentBrandPrimary: Color,
    val linkInComponentBrandSecondary: Color,
    val linkHeadlineDefault: Color,
    val linkHeadlineHover: Color,
    val linkHeadlineOnDarkDefault: Color,
    val linkHeadlineOnDarkHover: Color,
    val linkDefault: Color,
    val linkHover: Color,
    val linkEmphasisDefault: Color,
    val linkEmphasisHover: Color,
    val linkHighlightDefault: Color,
    val linkHighlightHover: Color,
    val linkOnDarkDefault: Color,
    val linkOnDarkHover: Color,

    val logoName: Color,
    val logoBrandPrimary: Color,
    val logoBrandSecondary: Color,
    val logoOnDark: Color,

    val textPrimary: Color,
    val textPrimaryInverse: Color,
    val textSecondary: Color,
    val textSecondaryInverse: Color,
    val textBrandPrimary: Color,
    val textBrandSecondary: Color,

    val textEmphasis: Color,
    val textEmphasisInverse: Color,
    val textOnDark: Color,
    val textSubscriber: Color,
    val textHighlight: Color,
    val textSuccess: Color,
    val textAlert: Color,

    val backgroundPrimary: Color,
    val backgroundSecondary: Color,
    val backgroundTertiary: Color,
    val backgroundQuaternary: Color,
    val backgroundQuinary: Color,
    val backgroundCinemaPrimary: Color,
    val backgroundCinemaSecondary: Color,
    val backgroundSubscriberPrimary: Color,
    val backgroundSubscriberSecondary: Color,
    val backgroundHighlight: Color,
    val backgroundSuccessPrimary: Color,
    val backgroundSuccessSecondary: Color,
    val backgroundAlertPrimary: Color,
    val backgroundAlertSecondary: Color,
    val backgroundBrandPrimary: Color,
    val backgroundBrandSecondary: Color,
    val backgroundOverlayPrimary: Color,
    val backgroundOverlaySecondary: Color,
    val backgroundOverlaySecondaryInverse: Color,
    val backgroundOverlayTertiary: Color,
    val backgroundOverlayQuaternary: Color,
    val backgroundOverlayQuinary: Color,
    val backgroundGradientPrimary: Color,
    val backgroundGradientSecondary: Color,

    val buttonPrimaryDefault: Color,
    val buttonPrimaryHover: Color,
    val buttonPrimaryLabel: Color,
    val buttonSecondaryDefault: Color,
    val buttonSecondaryHover: Color,
    val buttonSecondaryLabel: Color,
    val buttonTertiaryDefault: Color,
    val buttonTertiaryHover: Color,
    val buttonQuaternaryDefault: Color,
    val buttonQuaternaryHover: Color,
    val buttonQuaternaryLabel: Color,
    val buttonAlertDefault: Color,
    val buttonAlertHover: Color,
    val buttonGhostDefault: Color,
    val buttonGhostHover: Color,
    val buttonSegmentedPrimaryDefault: Color,
    val buttonSegmentedPrimaryHover: Color,
    val buttonSegmentedSecondaryDefault: Color,
    val buttonSegmentedSecondaryHover: Color,

    val controlOnDarkDefault: Color,
    val controlOnDarkDisabled: Color,
    val controlPrimaryDefault: Color,
    val controlPrimaryDisabled: Color,
    val controlPrimaryOverlay: Color,
    val controlSecondary: Color,
    val controlTertiary: Color,
    val controlUnselected: Color,
    val controlBrandPrimaryDefault: Color,
    val controlBrandPrimaryDisabled: Color,
    val controlBrandOverlay: Color,
    val controlBrandSecondaryDefault: Color,
    val controlBrandTertiaryDefault: Color,
)

/**
 * 调色盘枚举，分为：dark, light
 * @author Hwang huangzhongyu@sph.com.sg
 */
object ColorPallet {

    /**
     * 提供亮色主题调色
     * @param context 上下文对象
     */
    @JvmStatic
    val lightColorScheme: SphAppColorScheme by lazy {
        SphAppColorScheme(
            dividerPrimary = Color(0xFFEAEAEA),
            dividerPrimaryOnDark = Color(0xFF323232),
            dividerSecondary = Color(0xFFF4F5F7),
            dividerBrand = Color(0xFFA80034),
            dividerSubscriber = Color(0xFFFF8BC6),
            dividerHighlightPrimary = Color(0xFFB39412),
            dividerHighlightSecondary = Color(0xFFFFB500),

            iconPrimaryDefault = Color(0xFF464646),
            iconSecondaryDefault = Color(0xFF6F6F6F),
            iconOnDarkDefault = Color(0xFFFFFFFF),
            iconOnDarkHover = Color(0xFF9E9E9E),
            iconInverseDefault = Color(0xFFFFFFFF),
            iconEmphasis = Color(0xFF000000),
            iconBrandPrimaryDefault = Color(0xFFA80034),
            iconBrandPrimaryActive = Color(0xFFFF96A7),
            iconBrandSecondary = Color(0xFF003866),
            iconSuccessDefault = Color(0xFF008BCA),
            iconAlertDefault = Color(0xFFCC0F2E),
            iconAlertHover = Color(0xFFA30C25),
            iconFlagChina = Color(0xFFFFB500),
            iconFlagSingapore = Color(0xFFE90044),

            inputBorderDefault = Color(0xFFEAEAEA),
            inputBorderActive = Color(0xFF464646),
            inputBorderError = Color(0xFFCC0F2E),
            inputTextLabel = Color(0xFF9E9E9E),
            inputTextInput = Color(0xFF464646),
            inputTextError = Color(0xFFCC0F2E),
            inputTextSuccess = Color(0xFF008BCA),

            linkInComponentPrimary = Color(0xFF464646),
            linkInComponentOnDark = Color(0xFFFFFFFF),
            linkInComponentBrandPrimary = Color(0xFFA80034),
            linkInComponentBrandSecondary = Color(0xFF003866),
            linkHeadlineDefault = Color(0xFF464646),
            linkHeadlineHover = Color(0xFF003866),
            linkHeadlineOnDarkDefault = Color(0xFFE0E0E0),
            linkHeadlineOnDarkHover = Color(0xFFACC7E8),
            linkDefault = Color(0xFF6F6F6F),
            linkHover = Color(0xFF000000),
            linkEmphasisDefault = Color(0xFF000000),
            linkEmphasisHover = Color(0xFF6F6F6F),
            linkHighlightDefault = Color(0xFFB39412),
            linkHighlightHover = Color(0xFF805B00),
            linkOnDarkDefault = Color(0xFFFFFFFF),
            linkOnDarkHover = Color(0xFF9E9E9E),

            logoName = Color(0xFF000000),
            logoBrandPrimary = Color(0xFFA80034),
            logoBrandSecondary = Color(0xFFE90044),
            logoOnDark = Color(0xFFFFFFFF),

            textPrimary = Color(0xFF464646),
            textPrimaryInverse = Color(0xFFE0E0E0),
            textSecondary = Color(0xFF6F6F6F),
            textSecondaryInverse = Color(0xFF9E9E9E),
            textBrandPrimary = Color(0xFFA80034),
            textBrandSecondary = Color(0xFF003866),
            textEmphasis = Color(0xFF000000),
            textEmphasisInverse = Color(0xFFFFFFFF),
            textOnDark = Color(0xFFFFFFFF),
            textSubscriber = Color(0xFFFF8BC6),
            textHighlight = Color(0xFFB39412),
            textSuccess = Color(0xFF008BCA),
            textAlert = Color(0xFFCC0F2E),

            backgroundPrimary = Color(0xFFFFFFFF),
            backgroundSecondary = Color(0xFFF4F5F7),
            backgroundTertiary = Color(0xFFF9F9F9),
            backgroundQuaternary = Color(0xFF9E9E9E),
            backgroundQuinary = Color(0xFFEAEAEA),
            backgroundCinemaPrimary = Color(0xFF1E1E1E),
            backgroundCinemaSecondary = Color(0xFF383838),
            backgroundSubscriberPrimary = Color(0xFFFF8BC6),
            backgroundSubscriberSecondary = Color(0xFFFFF8F8),
            backgroundHighlight = Color(0xFFFFFBE8),
            backgroundSuccessPrimary = Color(0xFF003866),
            backgroundSuccessSecondary = Color(0xFFEFF5FC),
            backgroundAlertPrimary = Color(0xFFCC0F2E),
            backgroundAlertSecondary = Color(0xFFFFDDE5),
            backgroundBrandPrimary = Color(0xFFA80034),
            backgroundBrandSecondary = Color(0xFFF6E6EB),
            backgroundOverlayPrimary = Color(0x66000000),
            backgroundOverlaySecondary = Color(0x66000000),
            backgroundOverlaySecondaryInverse = Color(0x66FFFFFF),
            backgroundOverlayTertiary = Color(0xD9000000),
            backgroundOverlayQuaternary = Color(0x33000000),
            backgroundOverlayQuinary = Color(0x66000000),
            backgroundGradientPrimary = Color(0xFFFFFFFF),
            backgroundGradientSecondary = Color(0x00FFFFFF),

            buttonPrimaryDefault = Color(0xFFA80034),
            buttonPrimaryHover = Color(0xFF771828),
            buttonPrimaryLabel = Color(0xFFFFFFFF),
            buttonSecondaryDefault = Color(0xFF464646),
            buttonSecondaryHover = Color(0xFF383838),
            buttonSecondaryLabel = Color(0xFFFFFFFF),
            buttonTertiaryDefault = Color(0xFF464646),
            buttonTertiaryHover = Color(0xFFEAEAEA),
            buttonQuaternaryDefault = Color(0x66000000),
            buttonQuaternaryHover = Color(0x99000000),
            buttonQuaternaryLabel = Color(0xFFFFFFFF),
            buttonAlertDefault = Color(0xFFCC0F2E),
            buttonAlertHover = Color(0xFFFFDDE5),
            buttonGhostDefault = Color(0xFF6F6F6F),
            buttonGhostHover = Color(0xFFF4F5F7),
            buttonSegmentedPrimaryDefault = Color(0xFFFFFFFF),
            buttonSegmentedPrimaryHover = Color(0xFFF9F9F9),
            buttonSegmentedSecondaryDefault = Color(0xFFF4F5F7),
            buttonSegmentedSecondaryHover = Color(0xFFEAEAEA),

            controlOnDarkDefault = Color(0xFFFFFFFF),
            controlOnDarkDisabled = Color(0x66FFFFFF),
            controlPrimaryDefault = Color(0xFF464646),
            controlPrimaryDisabled = Color(0x66464646),
            controlPrimaryOverlay = Color(0x1F464646),
            controlSecondary = Color(0xFF6F6F6F),
            controlTertiary = Color(0xFF9E9E9E),
            controlUnselected = Color(0xFFE0E0E0),
            controlBrandPrimaryDefault = Color(0xFFA80034),
            controlBrandPrimaryDisabled = Color(0x66A80034),
            controlBrandOverlay = Color(0x1FA80034),
            controlBrandSecondaryDefault = Color(0xFFF6E6EB),
            controlBrandTertiaryDefault = Color(0xFFE90044),
        )
    }

    /**
     * 提供暗色主题调色
     * @param context 上下文对象
     */
    @JvmStatic
    val darkColorScheme: SphAppColorScheme by lazy {
        SphAppColorScheme(
            dividerPrimary = Color(0xFF464646),
            dividerPrimaryOnDark = Color(0xFFEAEAEA),
            dividerSecondary = Color(0xFF383838),
            dividerBrand = Color(0xFFE90044),
            dividerSubscriber = Color(0xFFFF8BC6),
            dividerHighlightPrimary = Color(0xFFFFFBE8),
            dividerHighlightSecondary = Color(0xFFFFB500),

            iconPrimaryDefault = Color(0xFFE0E0E0),
            iconSecondaryDefault = Color(0xFF9E9E9E),
            iconOnDarkDefault = Color(0xFFFFFFFF),
            iconOnDarkHover = Color(0xFF9E9E9E),
            iconInverseDefault = Color(0xFF464646),
            iconEmphasis = Color(0xFFFFFFFF),
            iconBrandPrimaryDefault = Color(0xFFFF405F),
            iconBrandPrimaryActive = Color(0xFFFF96A7),
            iconBrandSecondary = Color(0xFFBECDDF),
            iconSuccessDefault = Color(0xFF4DAEDA),
            iconAlertDefault = Color(0xFFFF6F86),
            iconAlertHover = Color(0xFFFFDDE5),
            iconFlagChina = Color(0xFFFFB500),
            iconFlagSingapore = Color(0xFFE90044),

            inputBorderDefault = Color(0xFF323232),
            inputBorderActive = Color(0xFFE0E0E0),
            inputBorderError = Color(0xFFFF6F86),
            inputTextLabel = Color(0xFF9E9E9E),
            inputTextInput = Color(0xFFE0E0E0),
            inputTextError = Color(0xFFFF6F86),
            inputTextSuccess = Color(0xFF4DAEDA),

            linkInComponentPrimary = Color(0xFFE0E0E0),
            linkInComponentOnDark = Color(0xFFFFFFFF),
            linkInComponentBrandPrimary = Color(0xFFFF405F),
            linkInComponentBrandSecondary = Color(0xFFBECDDF),
            linkHeadlineDefault = Color(0xFFE0E0E0),
            linkHeadlineHover = Color(0xFF003866),
            linkHeadlineOnDarkDefault = Color(0xFFE0E0E0),
            linkHeadlineOnDarkHover = Color(0xFFACC7E8),
            linkDefault = Color(0xFFFFFFFF),
            linkHover = Color(0xFF000000),
            linkEmphasisDefault = Color(0xFFFFFFFF),
            linkEmphasisHover = Color(0xFF6F6F6F),
            linkHighlightDefault = Color(0xFFB39412),
            linkHighlightHover = Color(0xFF805B00),
            linkOnDarkDefault = Color(0xFFFFFFFF),
            linkOnDarkHover = Color(0xFF9E9E9E),

            logoName = Color(0xFFFFFFFF),
            logoBrandPrimary = Color(0xFFA80034),
            logoBrandSecondary = Color(0xFFE90044),
            logoOnDark = Color(0xFFFFFFFF),

            textPrimary = Color(0xFFE0E0E0),
            textPrimaryInverse = Color(0xFF464646),
            textSecondary = Color(0xFF9E9E9E),
            textSecondaryInverse = Color(0xFF6F6F6F),
            textBrandPrimary = Color(0xFFFFFFFF),
            textBrandSecondary = Color(0xFFBECDDF),
            textEmphasis = Color(0xFFFFFFFF),
            textEmphasisInverse = Color(0xFF000000),
            textOnDark = Color(0xFFFFFFFF),
            textSubscriber = Color(0xFFFF8BC6),
            textHighlight = Color(0xFFFFFBE8),
            textSuccess = Color(0xFF4DAEDA),
            textAlert = Color(0xFFFF6F86),

            backgroundPrimary = Color(0xFF1E1E1E),
            backgroundSecondary = Color(0xFF383838),
            backgroundTertiary = Color(0xFF323232),
            backgroundQuaternary = Color(0xFF6F6F6F),
            backgroundQuinary = Color(0xFF464646),
            backgroundCinemaPrimary = Color(0xFF1E1E1E),
            backgroundCinemaSecondary = Color(0xFF383838),
            backgroundSubscriberPrimary = Color(0xFFFF8BC6),
            backgroundSubscriberSecondary = Color(0xFF66384F),
            backgroundHighlight = Color(0xFF805B00),
            backgroundSuccessPrimary = Color(0xFFEFF5FC),
            backgroundSuccessSecondary = Color(0xFF003866),
            backgroundAlertPrimary = Color(0xFFFF6F86),
            backgroundAlertSecondary = Color(0xFF662C36),
            backgroundBrandPrimary = Color(0xFFE90044),
            backgroundBrandSecondary = Color(0xFF5B212B),
            backgroundOverlayPrimary = Color(0xD9000000),
            backgroundOverlaySecondary = Color(0x66000000),
            backgroundOverlaySecondaryInverse = Color(0x66FFFFFF),
            backgroundOverlayTertiary = Color(0xD9000000),
            backgroundOverlayQuaternary = Color(0x33000000),
            backgroundOverlayQuinary = Color(0xB22A2A2A),
            backgroundGradientPrimary = Color(0xFF000000),
            backgroundGradientSecondary = Color(0x00000000),

            buttonPrimaryDefault = Color(0xFFE90044),
            buttonPrimaryHover = Color(0xFFC96685),
            buttonPrimaryLabel = Color(0xFFFFFFFF),
            buttonSecondaryDefault = Color(0xFFE0E0E0),
            buttonSecondaryHover = Color(0xFFF4F5F7),
            buttonSecondaryLabel = Color(0xFF464646),
            buttonTertiaryDefault = Color(0xFFE0E0E0),
            buttonTertiaryHover = Color(0xFF464646),
            buttonQuaternaryDefault = Color(0x66000000),
            buttonQuaternaryHover = Color(0x99000000),
            buttonQuaternaryLabel = Color(0xFFFFFFFF),
            buttonAlertDefault = Color(0xFFFF6F86),
            buttonAlertHover = Color(0xFF662C36),
            buttonGhostDefault = Color(0xFF9E9E9E),
            buttonGhostHover = Color(0xFF383838),
            buttonSegmentedPrimaryDefault = Color(0xFF1E1E1E),
            buttonSegmentedPrimaryHover = Color(0xFF323232),
            buttonSegmentedSecondaryDefault = Color(0xFF383838),
            buttonSegmentedSecondaryHover = Color(0xFF2A2A2A),

            controlOnDarkDefault = Color(0xFFFFFFFF),
            controlOnDarkDisabled = Color(0x66FFFFFF),
            controlPrimaryDefault = Color(0xFFE0E0E0),
            controlPrimaryDisabled = Color(0x66E0E0E0),
            controlPrimaryOverlay = Color(0x1FE0E0E0),
            controlSecondary = Color(0xFF9E9E9E),
            controlTertiary = Color(0xFF9E9E9E),
            controlUnselected = Color(0xFF6F6F6F),
            controlBrandPrimaryDefault = Color(0xFFE90044),
            controlBrandPrimaryDisabled = Color(0x66E90044),
            controlBrandOverlay = Color(0x1FE90044),
            controlBrandSecondaryDefault = Color(0xFF5B212B),
            controlBrandTertiaryDefault = Color(0xFFE90044),
        )
    }

    /**
     * 获取当前主题调色盘
     * @param darkTheme 是否使用暗色主题，默认使用系统方法[isSystemInDarkTheme]
     */
    @Composable
    fun rememberColorPallet(
        darkTheme: Boolean = LocalUiUseDarkTheme.current
    ): SphAppColorScheme {
        return remember(darkTheme) {
            if (darkTheme)
                darkColorScheme
            else lightColorScheme
        }
    }

    /**
     * 从颜色名字获取颜色值
     * @param colorScheme 颜色协议对象
     * @param name 颜色名字
     */
    @JvmStatic
    fun fromColorName(
        colorScheme: SphAppColorScheme,
        name: String?
    ): Color? {
        try {
            if (name?.trim().isNullOrEmpty()) return null
            val field = SphAppColorScheme::class.java.javaClass
                .getField(
                    name.trim()
                        .replace(Regex("-(\\w)")) { it.groupValues[1].uppercase() })
            if (field == null) return null
            field.isAccessible = true
            return field.get(colorScheme) as Color?
        } catch (e: Exception) {
            Log.i("ColorPallet", "无法从颜色名字中获取颜色数据：$e")
            return null
        }
    }

    /** 把颜色转换成十六进制表示的颜色字符串, 例如结果输出：#FF000000 **/
    fun Color.formatHex() = "#%08X".format(this.toArgb())

}

/** 自定义Local调色盘对象 **/
val LocalColorPallet =
    compositionLocalOf<SphAppColorScheme> { error("Nothing SphAppColors Provided!") }

/** 当前UI展示颜色模式是否是暗色模式 **/
val LocalUiUseDarkTheme = compositionLocalOf<Boolean> { error("Nothing UiUseDarkTheme Provided!") }