package com.sg.common.theme

import android.util.Log
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RippleConfiguration
import androidx.compose.material3.RippleDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.em

/**
 * 应用Jetpack Compose主题方法
 * @param useDarkTheme UI主题应用模式，默认：跟随系统
 * @param fontFamily 字体家族信息
 * @param content 内容视图方法
 */
@Composable
fun SphAppTheme(
    useDarkTheme: Boolean = isSystemInDarkTheme(),
    fontFamily: FontFamily = FontFamily.Default,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val inEditMode = LocalInspectionMode.current
    val dimens = remember(inEditMode) {
        if (inEditMode) Dimens(context) else Dimens.singleton()
    }
    val appTypography = TypographyHandler
        .getAppTypographyByFontFamily(fontFamily = fontFamily)
    CompositionLocalProvider(
        LocalDefaultFontFamily provides fontFamily,
        LocalDimens provides dimens,
        LocalUiUseDarkTheme provides useDarkTheme,
        LocalColorPallet provides ColorPallet.rememberColorPallet(useDarkTheme),
        LocalTextStyle provides TextStyle(lineHeight = 1.2.em, fontFamily = fontFamily)
    ) {
        MaterialTheme(
            content = content,
            typography = appTypography,
            shapes = MaterialTheme.shapes,
            colorScheme = when {
                useDarkTheme -> darkColorScheme(
                    primary = colorResource(R.color.background_brand_primary),
                    onPrimary = colorResource(R.color.text_primary),
                    secondary = colorResource(R.color.text_secondary),
                    tertiary = colorResource(R.color.text_emphasis),
                    background = colorResource(R.color.background_primary),
                )

                else -> lightColorScheme(
                    primary = colorResource(R.color.background_brand_primary_night),
                    onPrimary = colorResource(R.color.text_primary_night),
                    secondary = colorResource(R.color.text_secondary_night),
                    tertiary = colorResource(R.color.text_emphasis_night),
                    background = colorResource(R.color.background_primary_night)
                )
            },
        )
    }
}

/** SPH应用主题类 **/
object SphAppTheme {

    /** 使用原始的Dimen数据单位, 默认：false **/
    var useOriginalDimens: Boolean = false

    /** 获取默认的Ripple效果 **/
    @OptIn(ExperimentalMaterial3Api::class)
    val defaultRipple: RippleConfiguration =
        RippleConfiguration(
            color = Color.LightGray,
            rippleAlpha = RippleDefaults.RippleAlpha
        )

    /**
     * 修改Jetpack Compose中的默认值设定函数
     *
     * 1.修改TabRow中的ScrollableTabRowMinimumTabWidth为0f;
     * 2.修改所有Button的默认最小高度为0，最小宽度也为0;
     */
    @JvmStatic
    fun applyJetpackComposeDefaultValues() {
        runCatching {
            val buttonDefaultClazz = ButtonDefaults::class.java
            buttonDefaultClazz.getDeclaredField("MinWidth")
                .let { field ->
                    field.isAccessible = true
                    field.set(null, 0f)
                }
            buttonDefaultClazz.getDeclaredField("MinHeight")
                .let { field ->
                    field.isAccessible = true
                    field.set(null, 0f)
                }
        }.let { result ->
            result.exceptionOrNull()?.let { ex ->
                Log.e("ComposeViewUtils", "设置按钮的默认值错误：$ex")
            }
        }
    }

}