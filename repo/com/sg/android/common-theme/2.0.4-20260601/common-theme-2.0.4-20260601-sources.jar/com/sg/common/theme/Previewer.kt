package com.sg.common.theme

import android.content.res.Configuration
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

/**
 * 默认预览方法，内部只能使用自定义的[LocalDimens]
 * @param darkTheme 是否是暗色主题，默认使用系统方法[isSystemInDarkTheme]
 * @param content Compose布局内容
 */
@Composable
@OptIn(ExperimentalSharedTransitionApi::class)
fun DefaultPreview(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    LaunchedEffect(Unit) { SphAppTheme.applyJetpackComposeDefaultValues() }
    SphAppTheme { content() } //调用主题样式主方法
}

@Composable
@Preview(uiMode = Configuration.UI_MODE_NIGHT_NO)
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun DefaultPreviewSample() {
    DefaultPreview {
        var useDarkTheme = LocalUiUseDarkTheme.current
        val colors = LocalColorPallet.current
        Column(Modifier.padding(12.dp)) {
            Text(
                color = colors.logoBrandPrimary,
                textAlign = TextAlign.Center,
                text = "DefaultPreview\n(当前主题：${if (useDarkTheme) "Dark" else "Light"})"
            )
            Button(onClick = { useDarkTheme = !useDarkTheme }) {
                Text(text = "切换主题 (${if (useDarkTheme) "Light" else "Dark"})")
            }
        }
    }
}