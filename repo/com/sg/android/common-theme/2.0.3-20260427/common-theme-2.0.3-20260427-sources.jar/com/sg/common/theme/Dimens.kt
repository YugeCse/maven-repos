package com.sg.common.theme

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.util.Log
import android.util.TypedValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.sg.common.theme.context.ContextProvider
import com.sg.common.theme.utils.actionBarHeight
import com.sg.common.theme.utils.statusBarHeight

/**
 * Dimens类，提供DP/SP的资源
 * @param context 上下文对象
 */
class Dimens(private val context: Context) {

    @SuppressLint("StaticFieldLeak")
    companion object {

        @JvmStatic
        @SuppressLint("StaticFieldLeak")
        private var instance: Dimens? = null

        @JvmStatic
        fun singleton(): Dimens {
            return instance
                ?: throw Throwable("Please call Dimens.initialized first!")
        }

        /**
         * 获取实例
         * @param context 上下文
         */
        @JvmStatic
        fun initialize(context: Context = ContextProvider.get().context): Dimens {
            if (instance == null) {
                synchronized(Dimens::class.java) {
                    if (instance == null) {
                        instance = Dimens(context)
                    }
                }
            }
            return instance!!
        }

    }

    private val resources by lazy { context.resources }

    val dp0: Dp get() = resources.getDimension(R.dimen.dp_0).pixelToDp()
    val dp0_5: Dp get() = resources.getDimension(R.dimen.dp_0_5).pixelToDp()
    val dp1: Dp get() = resources.getDimension(R.dimen.dp_1).pixelToDp()
    val dp1_5: Dp get() = resources.getDimension(R.dimen.dp_1_5).pixelToDp()
    val dp2: Dp get() = resources.getDimension(R.dimen.dp_2).pixelToDp()
    val dp3: Dp get() = resources.getDimension(R.dimen.dp_3).pixelToDp()
    val dp4: Dp get() = resources.getDimension(R.dimen.dp_4).pixelToDp()
    val dp5: Dp get() = resources.getDimension(R.dimen.dp_5).pixelToDp()
    val dp6: Dp get() = resources.getDimension(R.dimen.dp_6).pixelToDp()
    val dp7: Dp get() = resources.getDimension(R.dimen.dp_7).pixelToDp()
    val dp8: Dp get() = resources.getDimension(R.dimen.dp_8).pixelToDp()
    val dp9: Dp get() = resources.getDimension(R.dimen.dp_9).pixelToDp()
    val dp10: Dp get() = resources.getDimension(R.dimen.dp_10).pixelToDp()
    val dp11: Dp get() = resources.getDimension(R.dimen.dp_11).pixelToDp()
    val dp12: Dp get() = resources.getDimension(R.dimen.dp_12).pixelToDp()
    val dp13: Dp get() = resources.getDimension(R.dimen.dp_13).pixelToDp()
    val dp14: Dp get() = resources.getDimension(R.dimen.dp_14).pixelToDp()
    val dp15: Dp get() = resources.getDimension(R.dimen.dp_15).pixelToDp()
    val dp16: Dp get() = resources.getDimension(R.dimen.dp_16).pixelToDp()
    val dp17: Dp get() = resources.getDimension(R.dimen.dp_17).pixelToDp()
    val dp18: Dp get() = resources.getDimension(R.dimen.dp_18).pixelToDp()
    val dp19: Dp get() = resources.getDimension(R.dimen.dp_19).pixelToDp()
    val dp20: Dp get() = resources.getDimension(R.dimen.dp_20).pixelToDp()
    val dp21: Dp get() = resources.getDimension(R.dimen.dp_21).pixelToDp()
    val dp22: Dp get() = resources.getDimension(R.dimen.dp_22).pixelToDp()
    val dp23: Dp get() = resources.getDimension(R.dimen.dp_23).pixelToDp()
    val dp24: Dp get() = resources.getDimension(R.dimen.dp_24).pixelToDp()
    val dp25: Dp get() = resources.getDimension(R.dimen.dp_25).pixelToDp()
    val dp26: Dp get() = resources.getDimension(R.dimen.dp_26).pixelToDp()
    val dp27: Dp get() = resources.getDimension(R.dimen.dp_27).pixelToDp()
    val dp28: Dp get() = resources.getDimension(R.dimen.dp_28).pixelToDp()
    val dp29: Dp get() = resources.getDimension(R.dimen.dp_29).pixelToDp()
    val dp30: Dp get() = resources.getDimension(R.dimen.dp_30).pixelToDp()
    val dp31: Dp get() = resources.getDimension(R.dimen.dp_31).pixelToDp()
    val dp32: Dp get() = resources.getDimension(R.dimen.dp_32).pixelToDp()
    val dp33: Dp get() = resources.getDimension(R.dimen.dp_33).pixelToDp()
    val dp34: Dp get() = resources.getDimension(R.dimen.dp_34).pixelToDp()
    val dp35: Dp get() = resources.getDimension(R.dimen.dp_35).pixelToDp()
    val dp36: Dp get() = resources.getDimension(R.dimen.dp_36).pixelToDp()
    val dp37: Dp get() = resources.getDimension(R.dimen.dp_37).pixelToDp()
    val dp38: Dp get() = resources.getDimension(R.dimen.dp_38).pixelToDp()
    val dp40: Dp get() = resources.getDimension(R.dimen.dp_40).pixelToDp()
    val dp41: Dp get() = resources.getDimension(R.dimen.dp_41).pixelToDp()
    val dp42: Dp get() = resources.getDimension(R.dimen.dp_42).pixelToDp()
    val dp43: Dp get() = resources.getDimension(R.dimen.dp_43).pixelToDp()
    val dp44: Dp get() = resources.getDimension(R.dimen.dp_44).pixelToDp()
    val dp45: Dp get() = resources.getDimension(R.dimen.dp_45).pixelToDp()
    val dp46: Dp get() = resources.getDimension(R.dimen.dp_46).pixelToDp()
    val dp47: Dp get() = resources.getDimension(R.dimen.dp_47).pixelToDp()
    val dp48: Dp get() = resources.getDimension(R.dimen.dp_48).pixelToDp()
    val dp49: Dp get() = resources.getDimension(R.dimen.dp_49).pixelToDp()
    val dp50: Dp get() = resources.getDimension(R.dimen.dp_50).pixelToDp()
    val dp51: Dp get() = resources.getDimension(R.dimen.dp_51).pixelToDp()
    val dp52: Dp get() = resources.getDimension(R.dimen.dp_52).pixelToDp()
    val dp53: Dp get() = resources.getDimension(R.dimen.dp_53).pixelToDp()
    val dp54: Dp get() = resources.getDimension(R.dimen.dp_54).pixelToDp()
    val dp55: Dp get() = resources.getDimension(R.dimen.dp_55).pixelToDp()
    val dp56: Dp get() = resources.getDimension(R.dimen.dp_56).pixelToDp()
    val dp57: Dp get() = resources.getDimension(R.dimen.dp_57).pixelToDp()
    val dp58: Dp get() = resources.getDimension(R.dimen.dp_58).pixelToDp()
    val dp59: Dp get() = resources.getDimension(R.dimen.dp_59).pixelToDp()
    val dp60: Dp get() = resources.getDimension(R.dimen.dp_60).pixelToDp()
    val dp66: Dp get() = resources.getDimension(R.dimen.dp_66).pixelToDp()
    val dp70: Dp get() = resources.getDimension(R.dimen.dp_70).pixelToDp()
    val dp74: Dp get() = resources.getDimension(R.dimen.dp_74).pixelToDp()
    val dp80: Dp get() = resources.getDimension(R.dimen.dp_80).pixelToDp()
    val dp90: Dp get() = resources.getDimension(R.dimen.dp_90).pixelToDp()
    val dp100: Dp get() = resources.getDimension(R.dimen.dp_100).pixelToDp()
    val dp110: Dp get() = resources.getDimension(R.dimen.dp_110).pixelToDp()
    val dp120: Dp get() = resources.getDimension(R.dimen.dp_120).pixelToDp()
    val dp130: Dp get() = resources.getDimension(R.dimen.dp_130).pixelToDp()
    val dp140: Dp get() = resources.getDimension(R.dimen.dp_140).pixelToDp()
    val dp150: Dp get() = resources.getDimension(R.dimen.dp_150).pixelToDp()
    val dp160: Dp get() = resources.getDimension(R.dimen.dp_160).pixelToDp()
    val dp170: Dp get() = resources.getDimension(R.dimen.dp_170).pixelToDp()
    val dp180: Dp get() = resources.getDimension(R.dimen.dp_180).pixelToDp()
    val dp200: Dp get() = resources.getDimension(R.dimen.dp_200).pixelToDp()
    val dp227: Dp get() = resources.getDimension(R.dimen.dp_227).pixelToDp()

    val dp240: Dp get() = resources.getDimension(R.dimen.dp_240).pixelToDp()
    val dp260: Dp get() = resources.getDimension(R.dimen.dp_260).pixelToDp()
    val dp300: Dp get() = resources.getDimension(R.dimen.dp_300).pixelToDp()
    val dp500: Dp get() = resources.getDimension(R.dimen.dp_500).pixelToDp()
    val dp640: Dp get() = resources.getDimension(R.dimen.dp_640).pixelToDp()


    /***************************************
     *                                     *
     *                                     *
     *       下面是关于字体大小的一些定义       *
     *                                     *
     *                                     *
     ***************************************/

    val sp6: TextUnit = resources.getDimension(R.dimen.sp_6).pixelToSp()

    val sp8: TextUnit = resources.getDimension(R.dimen.sp_8).pixelToSp()

    val sp9: TextUnit = resources.getDimension(R.dimen.sp_9).pixelToSp()

    val sp10: TextUnit = resources.getDimension(R.dimen.sp_10).pixelToSp()

    val sp11: TextUnit = resources.getDimension(R.dimen.sp_11).pixelToSp()

    val sp12: TextUnit = resources.getDimension(R.dimen.sp_12).pixelToSp()

    val sp13: TextUnit = resources.getDimension(R.dimen.sp_13).pixelToSp()

    val sp14: TextUnit = resources.getDimension(R.dimen.sp_14).pixelToSp()

    val sp15: TextUnit = resources.getDimension(R.dimen.sp_15).pixelToSp()

    val sp16: TextUnit = resources.getDimension(R.dimen.sp_16).pixelToSp()

    val sp17: TextUnit = resources.getDimension(R.dimen.sp_17).pixelToSp()

    val sp18: TextUnit = resources.getDimension(R.dimen.sp_18).pixelToSp()

    val sp19: TextUnit = resources.getDimension(R.dimen.sp_19).pixelToSp()

    val sp20: TextUnit = resources.getDimension(R.dimen.sp_20).pixelToSp()

    val sp21: TextUnit = resources.getDimension(R.dimen.sp_21).pixelToSp()

    val sp22: TextUnit = resources.getDimension(R.dimen.sp_22).pixelToSp()

    val sp23: TextUnit = resources.getDimension(R.dimen.sp_23).pixelToSp()

    val sp24: TextUnit = resources.getDimension(R.dimen.sp_24).pixelToSp()

    val sp25: TextUnit = resources.getDimension(R.dimen.sp_25).pixelToSp()

    val sp26: TextUnit = resources.getDimension(R.dimen.sp_26).pixelToSp()

    val sp27: TextUnit = resources.getDimension(R.dimen.sp_27).pixelToSp()

    val sp28: TextUnit = resources.getDimension(R.dimen.sp_28).pixelToSp()

    val sp29: TextUnit = resources.getDimension(R.dimen.sp_29).pixelToSp()

    val sp30: TextUnit = resources.getDimension(R.dimen.sp_30).pixelToSp()

    val sp31: TextUnit = resources.getDimension(R.dimen.sp_31).pixelToSp()

    val sp32: TextUnit = resources.getDimension(R.dimen.sp_32).pixelToSp()

    val sp33: TextUnit = resources.getDimension(R.dimen.sp_33).pixelToSp()

    val sp34: TextUnit = resources.getDimension(R.dimen.sp_34).pixelToSp()

    val sp35: TextUnit = resources.getDimension(R.dimen.sp_35).pixelToSp()

    val sp36: TextUnit = resources.getDimension(R.dimen.sp_36).pixelToSp()

    val sp37: TextUnit = resources.getDimension(R.dimen.sp_37).pixelToSp()

    val sp38: TextUnit = resources.getDimension(R.dimen.sp_38).pixelToSp()

    val sp39: TextUnit = resources.getDimension(R.dimen.sp_39).pixelToSp()

    val sp40: TextUnit = resources.getDimension(R.dimen.sp_40).pixelToSp()

    val sp41: TextUnit = resources.getDimension(R.dimen.sp_41).pixelToSp()

    val sp42: TextUnit = resources.getDimension(R.dimen.sp_42).pixelToSp()

    val sp43: TextUnit = resources.getDimension(R.dimen.sp_43).pixelToSp()

    val sp44: TextUnit = resources.getDimension(R.dimen.sp_44).pixelToSp()

    val sp45: TextUnit = resources.getDimension(R.dimen.sp_45).pixelToSp()

    val sp46: TextUnit = resources.getDimension(R.dimen.sp_46).pixelToSp()

    val sp47: TextUnit = resources.getDimension(R.dimen.sp_47).pixelToSp()

    val sp48: TextUnit = resources.getDimension(R.dimen.sp_48).pixelToSp()

    val sp49: TextUnit = resources.getDimension(R.dimen.sp_49).pixelToSp()

    val sp50: TextUnit = resources.getDimension(R.dimen.sp_50).pixelToSp()

    val sp51: TextUnit = resources.getDimension(R.dimen.sp_51).pixelToSp()

    val sp52: TextUnit = resources.getDimension(R.dimen.sp_52).pixelToSp()

    val sp53: TextUnit = resources.getDimension(R.dimen.sp_53).pixelToSp()

    val sp54: TextUnit = resources.getDimension(R.dimen.sp_54).pixelToSp()

    val sp55: TextUnit = resources.getDimension(R.dimen.sp_55).pixelToSp()

    val sp56: TextUnit = resources.getDimension(R.dimen.sp_56).pixelToSp()

    val sp57: TextUnit = resources.getDimension(R.dimen.sp_57).pixelToSp()

    val sp58: TextUnit = resources.getDimension(R.dimen.sp_58).pixelToSp()

    val sp59: TextUnit = resources.getDimension(R.dimen.sp_59).pixelToSp()

    val sp60: TextUnit = resources.getDimension(R.dimen.sp_60).pixelToSp()

    val sp61: TextUnit = resources.getDimension(R.dimen.sp_61).pixelToSp()

    val sp62: TextUnit = resources.getDimension(R.dimen.sp_62).pixelToSp()

    val sp63: TextUnit = resources.getDimension(R.dimen.sp_63).pixelToSp()

    val sp64: TextUnit = resources.getDimension(R.dimen.sp_64).pixelToSp()

    val sp65: TextUnit = resources.getDimension(R.dimen.sp_65).pixelToSp()

    val sp66: TextUnit = resources.getDimension(R.dimen.sp_66).pixelToSp()

    val sp67: TextUnit = resources.getDimension(R.dimen.sp_67).pixelToSp()

    val sp68: TextUnit = resources.getDimension(R.dimen.sp_68).pixelToSp()

    val sp69: TextUnit = resources.getDimension(R.dimen.sp_69).pixelToSp()

    val sp70: TextUnit = resources.getDimension(R.dimen.sp_70).pixelToSp()

    /** 状态栏DP高度 **/
    val statusBarHeightDp: Dp get() = context.statusBarHeight.pixelToDp()

    /** ActionBar的DP高度 **/
    val actionBarHeightDp: Dp get() = context.actionBarHeight.pixelToDp()

    /** 状态栏 + ActonBar的DP高度 **/
    val actionBarMaxHeightDp: Dp get() = (context.actionBarHeight + context.statusBarHeight).pixelToDp()

    /** 标题文本的行高距, 默认：1.35.em **/
    val headlineLineHeight: TextUnit get() = 1.35.em

    /** border的圆角 **/
    val orderRadiusMd = dp4

    /** Dimens的Pixel数据转为Dp数据 **/
    private fun Number.pixelToDp(): Dp =
        with(context.resources) { toFloat() / displayMetrics.density }.dp

    /** Dimens的Pixel数据转为Sp数据 **/
    private fun Number.pixelToSp(): TextUnit = with(context.resources) {
        @Suppress("DEPRECATION")
        if (!BuildConfig.DEBUG && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
            TypedValue.deriveDimension(
                TypedValue.COMPLEX_UNIT_SP, toFloat(), displayMetrics
            )
        else toFloat() / context.resources.displayMetrics.scaledDensity
    }.sp

    /** 缓存数值和sp的配对Map **/
    private val spCache = mutableMapOf<Int, TextUnit>()

    /**
     * 根据数值获取字体映射值
     * @param spNumValue 数值映射值
     * @param fallback 未找到结果时的兜底值
     **/
    fun getTextUnitFromValue(
        spNumValue: Int,
        fallback: () -> TextUnit = { sp14 }
    ): TextUnit {
        if (spCache.contains(spNumValue))
            return spCache[spNumValue] ?: fallback()
        return (try {
            R.dimen::class.java
                .getField("sp_$spNumValue")
                .run {
                    isAccessible = true
                    isAccessible = true
                    (get(this) as? Int)
                        ?.let { resources.getDimension(it).pixelToSp() }
                }
        } catch (e: Exception) {
           Log.e("Dimens", "[convertToSp] - $e")
            null
        } ?: fallback()).also { spCache[spNumValue] to it }
    }

    /** 缓存数值和dip的配对Map **/
    private val dipCache = mutableMapOf<Int, Dp>()

    /**
     * 转换数字到DP
     * @param dpNumValue dp数字映射值
     * @param fallback 未找到结果时的兜底值
     */
    fun getDpFromValue(
        dpNumValue: Int,
        fallback: () -> Dp = { dpNumValue.dp }
    ): Dp {
        if (dipCache.contains(dpNumValue))
            return dipCache[dpNumValue] ?: fallback()
        return (try {
            R.dimen::class.java
                .getField("dp_$dpNumValue")
                .run {
                    isAccessible = true
                    (get(this) as? Int)
                        ?.let { resources.getDimension(it).pixelToDp() }
                }
        } catch (e: Exception) {
            Log.e("Dimens", "[convertToDip] - $e")
            null
        } ?: fallback()).also { dipCache[dpNumValue] to it }
    }


    /**
     * 在折叠/展开、旋转、显示密度等配置变化时调用，清理缓存避免沿用旧的换算结果。
     *
     * 注意：Dimens 依赖 resources/displayMetrics 做 dp/sp 换算，缓存必须跟随配置更新失效。
     */
    fun onConfigurationChanged() {
        spCache.clear()
        dipCache.clear()
    }

}

/** Jetpack Compose代码中适用的Dimens对象 **/
val LocalDimens = staticCompositionLocalOf<Dimens> { error("None Dimension Provided!") }