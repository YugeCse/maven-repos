package com.sg.common.theme

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.util.TypedValue
import android.widget.TextView
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.em
import androidx.core.content.res.ResourcesCompat
import com.sg.common.theme.utils.sp2px
import kotlin.math.absoluteValue

/**
 * 字体信息实体声明
 * @author Hwang huangzhongyu@sph.com.sg
 * @param fontSize 字体大小
 * @param fontWeight 字体粗细
 * @param lineHeight 行高
 * @param letterSpacing 字间距
 */
data class TypographyInfo(
    val type: TypographyType,
    val fontSize: TextUnit,
    val fontWeight: FontWeight,
    val lineHeight: TextUnit,
    val letterSpacing: TextUnit
) {

    /**
     * 转换成TextStyle
     * @param color 文本颜色
     * @param textAlign 文本模式
     * @param lineHeight 行高，默认：null，不覆盖默认值
     **/
    @Composable
    fun toTextStyle(
        color: Color = Color.Unspecified,
        textAlign: TextAlign = TextAlign.Unspecified,
        lineHeight: TextUnit? = null
    ): TextStyle = TextStyle(
        color = color,
        textAlign = textAlign,
        fontSize = fontSize,
        fontWeight = fontWeight,
        lineHeight = lineHeight ?: this.lineHeight,
        letterSpacing = letterSpacing,
        fontFamily = LocalDefaultFontFamily.current
    )

    /**
     * 应用印刷体信息到TextView
     * @param textView TextView对象
     * @param fontFamilyResId 字体家族资源id，默认：null，不覆盖默认值
     */
    fun applyToTextView(textView: TextView, fontFamilyResId: Int? = null): TextView {
        return textView.apply {
            runCatching {
                if (fontWeight == FontWeight.Bold)
                    setTypeface(null, Typeface.BOLD)
                else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                        fontFamilyResId != null
                    ) {
                        typeface = Typeface.create(
                            ResourcesCompat.getFont(context, fontFamilyResId),
                            fontWeight.weight, false
                        )
                    } else setTypeface(null, Typeface.NORMAL)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                setLineHeight(
                    TypedValue.COMPLEX_UNIT_PX,
                    this@TypographyInfo.lineHeight.value
                )
            }
            this.letterSpacing = this@TypographyInfo.letterSpacing.value
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, fontSize.value)
        }
    }

}

/**
 * 字体声明
 * @param fontValue 字体取值，单位为sp
 */
enum class TypographyType(val fontValue: Int) {
    Display1(32),
    Header1(24),
    Header2(22),
    Header3(18),
    Header4(18),
    SubHeader1(24),
    SubHeader2(18),
    SubHeader3(16),
    SubHeader4(14),
    Body1(18),
    Body2(16),
    Button1(16),
    Button2(16),
    Button3(12),
    Button4(14),
    Label1(16),
    Label2(14),
    Label3(14),
    Label4(12),
    Label5(12),
    Label6(14),
    Label7(16),
    Label8(16),
    Label9(14),
    Label10(14),

}


/** 字体处理类 **/
object TypographyHandler {

    val lineHeightSmall = 1.5.em

    val lineHeightMedium = 1.8.em

    val letterSpacing0 = 0.em

    val letterSpacingSmall = 0.02.em

    val letterSpacingMedium = 0.04.em

    /**
     * 获取字重
     * @param type 字体类型
     */
    @JvmStatic
    fun getFontWeight(type: TypographyType): FontWeight {
        if (type in arrayOf(
                TypographyType.Display1,
                TypographyType.Header1,
                TypographyType.Header2,
                TypographyType.Header4,
                TypographyType.SubHeader2,
                TypographyType.Button1,
                TypographyType.Button3,
                TypographyType.Button4,
                TypographyType.Label1,
                TypographyType.Label3,
                TypographyType.Label5,
                TypographyType.Label7,
                TypographyType.Label9
            )
        )
            return FontWeight.Medium
        else if (type == TypographyType.SubHeader1)
            return FontWeight.Light
        return FontWeight.Normal
    }

    /**
     * 获取行高
     * @param type 字体类型
     */
    @JvmStatic
    fun getLineHeight(type: TypographyType): TextUnit {
        if (type in arrayOf(
                TypographyType.Display1,
                TypographyType.Header1,
                TypographyType.Header2,
                TypographyType.Header3,
                TypographyType.Header4,
                TypographyType.SubHeader2,
                TypographyType.SubHeader3,
                TypographyType.SubHeader4,
                TypographyType.Body1,
                TypographyType.Body2,
                TypographyType.Button1,
                TypographyType.Button2,
                TypographyType.Button3,
                TypographyType.Button4,
                TypographyType.Label1,
                TypographyType.Label2,
                TypographyType.Label3,
                TypographyType.Label4,
                TypographyType.Label5,
                TypographyType.Label6,
                TypographyType.Label7,
                TypographyType.Label8,
                TypographyType.Label9,
                TypographyType.Label10
            )
        )
            return lineHeightSmall
        return lineHeightMedium
    }

    /**
     * 获取字间距
     * @param type 字体类型
     */
    @JvmStatic
    fun getLetterSpacing(type: TypographyType): TextUnit {
        if (type in arrayOf(
                TypographyType.Display1,
                TypographyType.Header1,
                TypographyType.Header2,
                TypographyType.Header3,
                TypographyType.Header4,
                TypographyType.SubHeader1,
                TypographyType.Body2,
                TypographyType.Button3,
                TypographyType.Label2,
                TypographyType.Label3,
                TypographyType.Label4,
                TypographyType.Label5,
                TypographyType.Label6,
                TypographyType.Label9,
                TypographyType.Label10,
            )
        )
            return letterSpacing0
        else if (type in arrayOf(
                TypographyType.SubHeader2,
                TypographyType.SubHeader3,
                TypographyType.SubHeader4,
                TypographyType.Body1,
            )
        )
            return letterSpacingSmall
        return letterSpacingMedium
    }

    /**
     * 获取字体信息
     * @param type 字体类型
     * @param size 字体缩放等级，默认为标准字体
     */
    @JvmStatic
    fun getTypographyInfo(
        context: Context,
        type: TypographyType,
        size: TypographyScaleType = TypographyScaleType.Standard
    ): TypographyInfo {
        return TypographyInfo(
            type = type,
            fontWeight = getFontWeight(type),
            lineHeight = getLineHeight(type),
            letterSpacing = getLetterSpacing(type),
            fontSize = Dimens.singleton()
                .getTextUnitFromValue(type.fontValue + size.offset),
        )
    }

    /**
     * 获取字体信息
     * @param type 字体类型
     * @param size 字体缩放等级，默认为标准字体
     */
    @JvmStatic
    @Composable
    fun getTypographyInfo(
        type: TypographyType,
        size: TypographyScaleType = TypographyScaleType.Standard
    ): TypographyInfo {
        val dimens = LocalDimens.current
        return remember(type, size) {
            TypographyInfo(
                type = type,
                fontWeight = getFontWeight(type),
                lineHeight = getLineHeight(type),
                letterSpacing = getLetterSpacing(type),
                fontSize = dimens.getTextUnitFromValue(type.fontValue + size.offset),
            )
        }
    }

    /**
     * 获取所有印刷字体的映射表
     * @param context 上下文对象
     */
    @JvmStatic
    fun getAllTypographyMap(): List<Map<String, Any>> {
        return TypographyType.entries.map {
            mapOf(
                "name" to it.name,
                "fontSize" to it.fontValue.run {
                    val value = Dimens.singleton()
                        .getTextUnitFromValue(it.fontValue.absoluteValue)
                        .value
                    (if (this < 0) value * -1.0f else value).sp2px
                }
            )
        }
    }

    /**
     * 通过FontFamily获取应用的字体typography
     * @param fontFamily 字体家族
     * @return Typography
     */
    @JvmStatic
    @Composable
    fun getAppTypographyByFontFamily(fontFamily: FontFamily): Typography {
        val appTypography = remember(fontFamily) {
            Typography().apply {
                copy(
                    displayLarge = displayLarge.copy(fontFamily = fontFamily),
                    displayMedium = displayMedium.copy(fontFamily = fontFamily),
                    displaySmall = displaySmall.copy(fontFamily = fontFamily),
                    headlineLarge = headlineLarge.copy(fontFamily = fontFamily),
                    headlineMedium = headlineMedium.copy(fontFamily = fontFamily),
                    headlineSmall = headlineSmall.copy(fontFamily = fontFamily),
                    titleLarge = titleLarge.copy(fontFamily = fontFamily),
                    titleMedium = titleMedium.copy(fontFamily = fontFamily),
                    titleSmall = titleSmall.copy(fontFamily = fontFamily),
                    bodyLarge = bodyLarge.copy(fontFamily = fontFamily),
                    bodyMedium = bodyMedium.copy(fontFamily = fontFamily),
                    bodySmall = bodySmall.copy(fontFamily = fontFamily),
                    labelLarge = labelLarge.copy(fontFamily = fontFamily),
                    labelMedium = labelMedium.copy(fontFamily = fontFamily),
                    labelSmall = labelSmall.copy(fontFamily = fontFamily)
                )
            }
        }
        return appTypography
    }

}

/** 提供默认的字体家族 **/
val LocalDefaultFontFamily = compositionLocalOf<FontFamily> { FontFamily.Default }