package com.sg.common.context

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context

/** 提供Context实例的类 **/
internal class ContextProvider private constructor(context: Context?) {

    private val mContext: Context? = context

    /** 获取上下文 **/
    val context: Context?
        get() = mContext

    /** application实例 **/
    val application: Application?
        get() = mContext?.applicationContext as? Application

    companion object {

        @Volatile
        @SuppressLint("StaticFieldLeak")
        private var instance: ContextProvider? = null

        /** 获取实例 **/
        fun get(): ContextProvider {
            if (instance == null) {
                synchronized(ContextProvider::class.java) {
                    if (instance == null) {
                        val context: Context = AppContextProvider.context
                            ?: throw IllegalStateException("context == null")
                        instance = ContextProvider(context)
                    }
                }
            }
            return instance!!
        }
    }

}