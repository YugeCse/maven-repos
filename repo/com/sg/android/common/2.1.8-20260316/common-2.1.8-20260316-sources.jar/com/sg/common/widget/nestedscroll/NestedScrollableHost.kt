/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.sg.common.widget.nestedscroll

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.ORIENTATION_HORIZONTAL
import androidx.viewpager2.widget.ViewPager2.SCROLL_STATE_SETTLING
import com.sg.common.app.LogUtils.log4d
import com.sg.common.app.LogUtils.log4e
import kotlin.math.abs
import kotlin.math.absoluteValue
import kotlin.math.sign

/**
 * Layout to wrap a scrollable component inside a ViewPager2. Provided as a solution to the problem
 * where pages of ViewPager2 have nested scrollable elements that scroll in the same direction as
 * ViewPager2. The scrollable element needs to be the immediate and only child of this host layout.
 *
 * This solution has limitations when using multiple levels of nested scrollable elements
 * (e.g. a horizontal RecyclerView in a vertical RecyclerView in a horizontal ViewPager2).
 *  @Link https://github.com/android/views-widgets-samples/blob/master/ViewPager2/app/src/main/java/androidx/viewpager2/integration/testapp/NestedScrollableHost.kt
 */
class NestedScrollableHost : FrameLayout {

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes)


    private var touchSlop = 0
    private var initialX = 0f
    private var initialY = 0f
    private val parentViewPager: ViewPager2?
        get() {
            var v: View? = parent as? View
            while (v != null && v !is ViewPager2) {
                v = v.parent as? View
            }
            rootViewpager = v
            return v
        }

    companion object {
        var rootViewpager: ViewPager2? = null
        private val TAG = NestedScrollableHost::class.java.simpleName
    }

    private val child: View? get() = if (childCount > 0) getChildAt(0) else null

    init {
        touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    }

    private fun canChildScroll(orientation: Int, delta: Float): Boolean {
        val direction = -delta.sign.toInt()
        return when (orientation) {
            0 -> child?.canScrollHorizontally(direction) ?: false
            1 -> child?.canScrollVertically(direction) ?: false
            else -> throw IllegalArgumentException()
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean {
        ev?.let {
            handleInterceptTouchEvent(it)
        }
        return super.onInterceptTouchEvent(ev)
    }

    private fun handleInterceptTouchEvent(e: MotionEvent) {
        val orientation = parentViewPager?.orientation ?: return

        // Early return if child can't scroll in same direction as parent
        if (!canChildScroll(orientation, -1f) && !canChildScroll(orientation, 1f)) {
            log4e(TAG, "调试ViewPager : handleInterceptTouchEvent ，viewpager滑动被拒绝")
            return
        }
        if (e.action == MotionEvent.ACTION_DOWN) {
            initialX = e.x
            initialY = e.y
            if (child is ViewPager2) {
                log4e(
                    TAG,
                    "调试ViewPager : MotionEvent.ACTION_DOWN 开始  -- ${(child as ViewPager2).scrollState}"
                )
            }else {
                log4e(TAG, "调试ViewPager : MotionEvent.ACTION_DOWN 开始  -- 未知\n")
            }
            parentViewPager?.isUserInputEnabled = false
            if ((child as ViewPager2).scrollState == SCROLL_STATE_SETTLING && child is ViewPager2) {
                parentViewPager?.isUserInputEnabled = true
            }
        } else if (e.action == MotionEvent.ACTION_MOVE) {
            log4e(TAG, "调试ViewPager : MotionEvent.ACTION_MOVE 开始")
            val dx = e.x - initialX
            val dy = e.y - initialY
            val isVpHorizontal = orientation == ORIENTATION_HORIZONTAL
            val scaledDx = dx.absoluteValue * if (isVpHorizontal) .5f else 1f
            val scaledDy = dy.absoluteValue * if (isVpHorizontal) 1f else .5f
            log4d(TAG, "调试ViewPager :  scaledDx = $scaledDx, touchSlop = $touchSlop ")
            if ((scaledDx > touchSlop || scaledDy > touchSlop)) {
                if (child is ViewPager2) {
                    (child as ViewPager2).let {
                        val count = it.adapter?.itemCount ?: 0
                        val current = it.currentItem
                        parentViewPager?.isUserInputEnabled =
                            ((current == 0 && dx > 0) || (current == count - 1 && dx < 0))
                                    && abs(dy) < abs(dx) && it.isUserInputEnabled
                        log4e(TAG, "调试ViewPager : parentViewPager isUserInputEnabled 2 = ${parentViewPager?.isUserInputEnabled}")
                    }
                } else {
                    parentViewPager?.isUserInputEnabled = abs(dx) > abs(dy)
                    log4e(TAG, "调试ViewPager : parentViewPager isUserInputEnabled 3 = ${parentViewPager?.isUserInputEnabled}")
                }
            }
        } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
            rootViewpager = null
            log4e(TAG, "调试ViewPager : 手势释放")
        }
    }
}