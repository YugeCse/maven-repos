package com.sg.common.gson

import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.sg.common.app.LogUtils


/**
 * json字符串转object
 * @param extraBuilder 额外配置构建器
 */
inline fun <reified T> String.toJsonObject(
    extraBuilder: GsonBuilder.() -> Unit = {}
): T? {
    return try {
        if (trim().isEmpty()) null
        else GsonBuilder()
            .apply { serializeNulls() }
            .apply(extraBuilder)
            .create()
            .fromJson<T>(this, object : TypeToken<T>() {}.type)
    } catch (e: Exception) {
        LogUtils.log4e("GsonUtils", e)
        null
    }
}

/**
 * object转JSON字符串
 * @param prettyJson 是否是友好格式的JSON支付输出
 * @param extraBuilder 额外配置构建器
 */
fun Any.toJsonString(
    prettyJson: Boolean = false,
    extraBuilder: GsonBuilder.() -> Unit = {}
): String {
    return try {
        return GsonBuilder()
            .apply { serializeNulls() }
            .run { if (!prettyJson) this else setPrettyPrinting() }
            .apply(extraBuilder)
            .create()
            .toJson(this)
    } catch (e: Exception) {
        LogUtils.log4e("GsonUtils", e)
        ""
    }
}
