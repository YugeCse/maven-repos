//package com.sg.common.widget.carousel
//
//import android.annotation.SuppressLint
//import android.content.Context
//import android.graphics.Canvas
//import android.graphics.Paint
//import android.graphics.RectF
//import android.util.AttributeSet
//import android.util.TypedValue
//import com.rd.IndicatorManager
//import com.rd.PageIndicatorView
//import com.rd.utils.CoordinatesUtils
//import com.sg.common.R
//
//class CarouselPageIndicator : PageIndicatorView {
//
//    private var paint: Paint = Paint()
//
//    private var indicatorManager: IndicatorManager? = null
//
//    constructor(context: Context) : super(context) {
//        initialize()
//    }
//
//    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
//        initialize()
//    }
//
//    private fun initialize() {
//        indicatorManager = javaClass.superclass.getDeclaredField("manager")
//            .run {
//                isAccessible = true
//                get(this@CarouselPageIndicator)
//            } as IndicatorManager
//    }
//
//    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
//        if (indicatorManager == null)
//            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
//        else {
//            val size =
//                indicatorManager!!.drawer().measureViewSize(widthMeasureSpec, heightMeasureSpec)
//            val dp12pixel = context.resources.getDimensionPixelSize(R.dimen.dp_12)
//            setMeasuredDimension(size.first + dp12pixel * 2, size.second)
//        }
//    }
//
//    /** 设置或获取Indicator的总数 **/
//    var totalCount: Int
//        set(value) {
//            val outValue = TypedValue()
//            context.resources.getValue(R.dimen.dp_0, outValue, true)
//            val numberOfHideArticle = outValue.float.toInt()
//            super.setCount(value - numberOfHideArticle)
//        }
//        get() = super.getCount()
//
//    @SuppressLint("DrawAllocation")
//    override fun onDraw(canvas: Canvas?) {
//        val dp12pixel = context.resources.getDimension(R.dimen.dp_12)
//        if (indicatorManager != null)
//            canvas?.translate(dp12pixel, 0f)
//        super.onDraw(canvas)
//        if (indicatorManager != null) {
//            val indicator = indicatorManager!!.indicator()
//            canvas?.translate(-dp12pixel / 2f, 0f)
//            val x = CoordinatesUtils.getXCoordinate(indicator, selection) - dp12pixel / 3f
//            paint.apply {
//                reset()
//                isAntiAlias = true
//                color = selectedColor
//                style = Paint.Style.FILL
//            }
//            val selectionRectF = toRectF(
//                x, 0f,
//                dp12pixel + dp12pixel * 2f / 3f,
//                measuredHeight.toFloat()
//            )
//            canvas?.drawRoundRect(selectionRectF, dp12pixel, dp12pixel, paint)
//        }
//    }
//
//    private fun toRectF(left: Float, top: Float, width: Float, height: Float) =
//        RectF(left, top, left + width, top + height)
//
//}