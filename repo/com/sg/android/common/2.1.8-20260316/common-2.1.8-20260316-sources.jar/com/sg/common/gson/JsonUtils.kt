package com.sg.common.gson

import org.json.JSONObject

/** 判断一个字符串是否是JSON字符串 **/
val String.isJSONString: Pair<Boolean, JSONObject?>
    get() {
        val text = trim()
        if (text.isEmpty() ||
            !(text.startsWith("[") && text.endsWith("]")) ||
            !(text.startsWith("{") && text.endsWith("}")))
            return false to null
        return try {
            true to JSONObject(text) //尝试解析，解析成功为JSON字符串
        } catch (e: Exception) {
            false to null
        }
    }