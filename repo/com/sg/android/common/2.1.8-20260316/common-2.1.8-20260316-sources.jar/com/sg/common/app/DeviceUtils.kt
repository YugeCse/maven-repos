package com.sg.common.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.provider.Settings
import com.sg.common.context.ContextProvider
import java.util.UUID


/** 设备辅助方法 **/
object DeviceUtils {

    /** 获取设备UniqueID **/
    @JvmStatic
    @SuppressLint("HardwareIds")
    fun getDeviceId(): String {
        val deviceId: String
        var androidId: String? = null
        try {
            androidId = Settings.Secure.getString(
                ContextProvider.get().context?.contentResolver,
                Settings.Secure.ANDROID_ID
            )
        } finally {
            if (androidId.isNullOrEmpty() || "9774d56d682e549c" == androidId)
                androidId = UUID.randomUUID().toString()
            val deviceInfo =
                "$androidId-${Build.HARDWARE}-${Build.BRAND}-${Build.MANUFACTURER}-${Build.PRODUCT}-${Build.FINGERPRINT}-${Build.HOST}-${Build.DISPLAY}"
            deviceId = UUID.nameUUIDFromBytes(deviceInfo.toByteArray()).toString()
        }
        return deviceId
    }

    /**
     * 是否是平板应用
     * @param context 上下文对象
     */
    @JvmStatic
    fun isTablet(context: Context): Boolean {
        return ((context.resources.configuration.screenLayout
            and Configuration.SCREENLAYOUT_SIZE_MASK)
            >= Configuration.SCREENLAYOUT_SIZE_LARGE)
    }

}