package com.sg.common.context

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.File

/**
 * 是否拥有安装权限
 * @return 小于Android8.0的为默认拥有，否则根据方法判断获取
 */
fun Context.hasInstallApkPermission(): Boolean {
    return when {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O -> true
        else -> packageManager.canRequestPackageInstalls()
    }
}


/** 构建安装APK的设置界面Intent **/
@RequiresApi(Build.VERSION_CODES.O)
fun Context.buildInstallPermissionSettingIntent() =
    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
        .setData(Uri.parse("package:${packageName}"))

/**
 * 构建安装APK的Intent
 * @param apkFile apk文件
 */
fun Context.buildInstallApkIntent(
    apkFile: File,
    authority: String = "${packageName}.FileProvider"
): Intent {
    return Intent(Intent.ACTION_VIEW).apply {
        addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                    or Intent.FLAG_GRANT_READ_URI_PERMISSION
                    or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true)
        setDataAndType(
            when {
                Build.VERSION.SDK_INT < Build.VERSION_CODES.N ->
                    Uri.fromFile(apkFile)
                else -> FileProvider.getUriForFile(this@buildInstallApkIntent, authority, apkFile)
            },
            "application/vnd.android.package-archive"
        )
    }
}