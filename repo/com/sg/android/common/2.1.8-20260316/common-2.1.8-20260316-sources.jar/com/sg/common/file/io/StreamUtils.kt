package com.sg.common.file.io

import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * InputStream转换成文件对象，如果文件名已存在，则会删除原来的文件
 * @param fileName 文件路径
 */
fun InputStream.toFile(fileName: String): File {
    val outputFile = File(fileName)
    if (outputFile.exists())
        outputFile.delete()
    outputFile.parentFile?.mkdirs()
    val fos = FileOutputStream(outputFile)
    val byteArray = ByteArray(2048)
    var len = read(byteArray, 0, byteArray.size)
    while (len != -1) {
        fos.write(byteArray, 0, len)
        len = read(byteArray, 0, byteArray.size)
    }
    fos.flush()
    close()
    return outputFile
}