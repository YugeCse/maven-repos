package com.sg.common.widget.slidebar

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import androidx.annotation.DrawableRes
import com.sg.common.R
import com.sg.common.app.getDrawableById
import com.sg.common.base.replaceWith
import com.sg.common.view.dip2px

/** 字体缩放滑块组件 **/
class FontSizeSeekBar : View {

    fun interface OnSeekBarChangeListener {
        fun onChanged(position: Int)
    }

    private var viewWidth = 0f
    private var viewHeight = 0
    private var downX = 0f
    private var downY = 0f
    private var upX = 0f
    private var upY = 0f
    private var moveX = 0f
    private var moveY = 0f
    private var perWidth = 0f
    private var mPaint: Paint = Paint()
    private var mTextPaint: Paint = Paint()
    private var mTextSelectPaint: Paint = Paint()
    private var buttonPaint: Paint = Paint()
    private var thumb: Bitmap? = null
    private var hotArea = 100
    private var curSections = 2
    private var padding = 38f
    private var textMove = 0f
    private val color = 0x33000000
    private var textSize = 0f
    private var circleRadius = 0f
    private var sectionTitle = mutableListOf<String>()

    private var listener: OnSeekBarChangeListener? = null

    constructor(context: Context) : this(context, null)

    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)

    constructor(context: Context, attrs: AttributeSet?, style: Int)
        : super(context, attrs, style) {
        initialize(context, attrs)
    }

    private fun initialize(context: Context, attrs: AttributeSet? = null) {
        val ta = context.obtainStyledAttributes(attrs, R.styleable.FontSizeSeekBar)
        setFontSizeDescription(
            context.resources
                .getStringArray(R.array.FontSizeSeekBarDefaultDescriptions)
                .toList()
        )
        curSections = 0
        thumb = (((ta.getDrawable(R.styleable.FontSizeSeekBar_slideThumbIcon)
            ?: context.getDrawableById(R.mipmap.ic_slide_seek_thumb)) as BitmapDrawable)).bitmap
        padding = (thumb!!.width).toFloat() + 20.dip2px.toInt()
        textMove = (thumb!!.width).toFloat() + 8.dip2px.toInt()
        textSize =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 16f, resources.displayMetrics)
        circleRadius =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3f, resources.displayMetrics)
        mPaint = Paint(Paint.DITHER_FLAG).apply {
            isAntiAlias = true
            strokeWidth = 4f
            color = ta.getColor(R.styleable.FontSizeSeekBar_controlSpotLineColor, color)
        }
        mTextPaint = Paint(Paint.DITHER_FLAG).apply {
            isAntiAlias = true
            this.textSize = textSize
            color = ta.getColor(R.styleable.FontSizeSeekBar_defaultDescriptionTextColor, Color.LTGRAY)
        }
        mTextSelectPaint = Paint(Paint.DITHER_FLAG).apply {
            isAntiAlias = true
            this.textSize = textSize
            color = ta.getColor(R.styleable.FontSizeSeekBar_selectedDescriptionTextColor, Color.RED)
        }
        buttonPaint = Paint(Paint.DITHER_FLAG)
            .apply { isAntiAlias = true }
        ta.recycle()
    }

    /**
     * 设置当前的选中点
     * @param selection 点位
     */
    fun setCurSections(selection: Int) {
        this.curSections = selection
        invalidate()
    }

    /**
     * 设置锚点资源
     * @param id DrawableId
     */
    fun setThumbDrawableResource(@DrawableRes id: Int) {
        thumb = ((context.getDrawableById(id) as BitmapDrawable)).bitmap
        padding = (thumb!!.width).toFloat() + 20.dip2px.toInt()
        textMove = (thumb!!.width).toFloat() + 8.dip2px.toInt()
        invalidate() //刷新界面
    }

    fun setCircleRadius(radius: Float) {
        this.circleRadius = radius
        invalidate()
    }

    /**
     * 设置文本的颜色
     * @param color 颜色
     */
    fun setTextColor(color: Int) {
        mTextPaint.color = color
        invalidate()
    }

    /**
     * 设置文本的字体大小
     * @param size 字体大小，pixel单位
     */
    fun setTextSize(size: Float) {
        mTextPaint.textSize = size
        invalidate()
    }

    /**
     * 设置选中文本的颜色
     * @param color 颜色
     */
    fun setTextSelectColor(color: Int) {
        mTextSelectPaint.color = color
        invalidate()
    }

    /**
     * 设置选中文本的字体大小
     * @param size 字体大小，pixel单位
     */
    fun setTextSelectTextSize(size: Float) {
        mTextSelectPaint.textSize = size
        invalidate()
    }

    /**
     * 设置字体描述文本
     * @param descriptions 描述文本集合
     */
    fun setFontSizeDescription(descriptions: List<String>) {
        sectionTitle.replaceWith(descriptions)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        viewWidth = widthSize.toFloat()
        viewHeight = 90.dip2px.toInt()
        setMeasuredDimension(viewWidth.toInt(), viewHeight)
        viewWidth -= (padding).toInt()
        perWidth = viewWidth / (sectionTitle.size - 1)
        hotArea = (perWidth / 2).toInt()
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        mPaint.style = Paint.Style.FILL
        mPaint.alpha = 0
        canvas.drawRect(0f, 0f, measuredWidth.toFloat(), measuredHeight.toFloat(), mPaint)
        mPaint.alpha = 255
        val thumbWidth = thumb!!.width
        val spotOnWidth = 4
        val spotOnHeight = 40
        val startY = (viewHeight * 2 / 3).toFloat()
        canvas.drawLine(
            padding / 2,
            startY,
            (sectionTitle.size - 1) * perWidth + padding / 2,
            startY,
            mPaint
        )
        var section = 0
        while (section < sectionTitle.size) {
            val startX = section * perWidth + padding / 2
            canvas.drawLine(
                startX - spotOnWidth / 2,
                (startY - spotOnHeight / 2),
                startX - spotOnWidth / 2,
                startY + spotOnHeight / 2,
                mPaint
            )
            val rect = Rect()
            mTextPaint.getTextBounds(sectionTitle[section], 0, sectionTitle[section].length, rect)
            val drawPaint = if (curSections == section) mTextSelectPaint else mTextPaint
            canvas.drawText(
                sectionTitle[section],
                startX - rect.width() / 2,
                (viewHeight * 2 / 3 - textMove),
                drawPaint
            )
            section++
        }
        canvas.drawBitmap(
            thumb!!,
            (curSections * perWidth + padding / 2 - thumbWidth / 2),
            (viewHeight * 2 / 3 - thumbWidth / 2).toFloat(),
            buttonPaint
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        super.onTouchEvent(event)
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                responseTouch(downX, downY)
            }
            MotionEvent.ACTION_MOVE -> {
                moveX = event.x
                moveY = event.y
                responseTouch(moveX, moveY)
            }
            MotionEvent.ACTION_UP -> {
                upX = event.x
                upY = event.y
                responseTouch(upX, upY)
                listener?.onChanged(curSections)
            }
        }
        return true
    }

    private fun responseTouch(x: Float?, y: Float?) {
        if (x != null && y != null) {
            curSections = if (x <= viewWidth - padding / 2) {
                ((x + perWidth / 3) / perWidth).toInt()
            } else {
                sectionTitle.size - 1
            }
        }
        invalidate()
    }

    /** 设置或获取进度值 **/
    var progress: Int
        get() = curSections
        set(value) {
            curSections = value
            invalidate()
        }

    /** 获取或设置默认文本的颜色 **/
    var defaultTextColor: Int
        get() = mTextPaint.color
        set(value) {
            mTextPaint.color = value
            invalidate()
        }

    /** 设置选中文本的颜色 **/
    var selectedTextColor: Int
        get() = mTextSelectPaint.color
        set(value) {
            mTextSelectPaint.color = value
            invalidate()
        }

    fun setOnSeekBarChangeListener(listener: OnSeekBarChangeListener) {
        this.listener = listener
    }

}