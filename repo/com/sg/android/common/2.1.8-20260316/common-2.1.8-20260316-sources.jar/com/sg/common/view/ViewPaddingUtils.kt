package com.sg.common.view

import android.view.View

fun View.setPaddingHorizontal(value: Int) =
    apply { setPadding(value, paddingTop, value, paddingBottom) }

fun View.setPaddingVertical(value: Int) =
    apply { setPadding(paddingStart, value, paddingEnd, value) }

fun View.setPaddingSymmetric(horizontal: Int, vertical: Int) =
    apply { setPadding(horizontal, vertical, horizontal, vertical) }

fun View.setPaddingRelativeHorizontal(value: Int) =
    apply { setPaddingRelative(value, paddingTop, value, paddingBottom) }

fun View.setPaddingRelativeVertical(value: Int) =
    apply { setPaddingRelative(paddingStart, value, paddingEnd, value) }

fun View.setPaddingRelativeSymmetric(horizontal: Int, vertical: Int) =
    apply { setPaddingRelative(horizontal, vertical, horizontal, vertical) }