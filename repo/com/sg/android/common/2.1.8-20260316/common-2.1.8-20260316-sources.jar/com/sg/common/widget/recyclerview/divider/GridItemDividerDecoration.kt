package com.sg.common.widget.recyclerview.divider

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import java.lang.Exception

class GridItemDividerDecoration @JvmOverloads constructor(
    private val space: Int,
    private val spaceType: SpaceType = SpaceType.ALL
) : RecyclerView.ItemDecoration() {

    enum class SpaceType {
        ALL,
        TOP,
        BOTTOM,
        LEFT,
        RIGHT,
        VERTICAL,
        HORIZONTAL
    }

    private fun getSpanCount(parent: RecyclerView): Int {
        var spanCount = 0
        if (parent.layoutManager != null && (parent.layoutManager is GridLayoutManager || parent.layoutManager is StaggeredGridLayoutManager))
            spanCount = if (parent.layoutManager is GridLayoutManager)
                (parent.layoutManager as GridLayoutManager).spanCount
            else (parent.layoutManager as StaggeredGridLayoutManager).spanCount
        if (spanCount <= 0) throw Exception("错误：RecyclerView的SpanCount不能小于1")
        return spanCount
    }

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        val position = parent.getChildLayoutPosition(view)
        val totalCount = parent.adapter?.itemCount ?: 0
        if (totalCount == 0) return
        val spanCount = getSpanCount(parent)
        val totalRow = totalCount / spanCount + (if (totalCount % spanCount == 0) 0 else 1)
        val currentColumn = position % spanCount
        var top = space / 2
        var left = currentColumn * space / spanCount
        var right = space - (currentColumn + 1) * space / spanCount
        var bottom = space / 2
        if (is1stRow(position, spanCount)) {
            top = if (spaceType in arrayOf(
                    SpaceType.ALL,
                    SpaceType.TOP,
                    SpaceType.VERTICAL
                )
            ) space else 0
        }
        if (isLastRow(position, totalRow, spanCount)) {
            bottom = if (spaceType in arrayOf(
                    SpaceType.ALL,
                    SpaceType.BOTTOM,
                    SpaceType.VERTICAL
                )
            ) space else 0
        }
        if (is1stColumn(position, spanCount)) {
            left = if (spaceType in arrayOf(
                    SpaceType.ALL,
                    SpaceType.LEFT,
                    SpaceType.HORIZONTAL
                )
            ) space else 0
        }
        if (isLastColumn(position, spanCount)) {
            right = if (spaceType in arrayOf(
                    SpaceType.ALL,
                    SpaceType.RIGHT,
                    SpaceType.HORIZONTAL
                )
            ) space else 0
        }
        outRect.set(left, top, right, bottom)
    }

    private fun is1stRow(pos: Int, totalColumn: Int) = pos / totalColumn == 0

    private fun isLastRow(pos: Int, totalRow: Int, totalColumn: Int) =
        pos / totalColumn == totalRow - 1

    private fun is1stColumn(pos: Int, totalColumn: Int) = pos % totalColumn == 0

    private fun isLastColumn(pos: Int, totalColumn: Int) = pos % totalColumn == totalColumn - 1

}