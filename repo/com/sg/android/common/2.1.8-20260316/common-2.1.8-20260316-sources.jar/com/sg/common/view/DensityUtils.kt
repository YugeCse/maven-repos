@file: JvmName("DensityUtils")

package com.sg.common.view

import android.content.Context
import android.os.Build
import android.util.TypedValue
import androidx.annotation.DimenRes
import androidx.annotation.Dimension
import com.sg.common.context.ContextProvider

/**
 * dp转px
 * @param dpVal   dip值
 */
fun Context.convertDip2px(dpVal: Number): Number =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dpVal.toFloat(), resources.displayMetrics)

/** dp转px **/
val Number.dip2px: Number
    get() = ContextProvider.get().context?.convertDip2px(toFloat()) ?: 0f

/**
 * sp转px
 * @param spVal   sp值
 */
fun Context.convertSp2px(spVal: Number): Number =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, spVal.toFloat(), resources.displayMetrics)

/** sp转px **/
val Number.sp2px: Number
    get() = ContextProvider.get().context?.convertSp2px(toFloat()) ?: 0f

/**
 * px转dp
 *
 * @param pxVal   px值
 */
fun Context.convertPx2dip(pxVal: Number): Number {
    return if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
        pxVal.toFloat() / resources.displayMetrics.density
    else TypedValue.deriveDimension(TypedValue.COMPLEX_UNIT_DIP, pxVal.toFloat(), resources.displayMetrics)
}

/** px转dp **/
val Number.px2dip: Number
    get() = (ContextProvider.get().context?.convertPx2dip(toFloat()) ?: 0f)

/**
 * px转sp
 * @param pxVal px值
 */
@Suppress("DEPRECATION")
fun Context.convertPx2sp(pxVal: Number): Number {
    return if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
        pxVal.toFloat() / resources.displayMetrics.scaledDensity
    else TypedValue.deriveDimension(TypedValue.COMPLEX_UNIT_SP, pxVal.toFloat(), resources.displayMetrics)
}

/** px转sp **/
val Number.px2sp: Number
    get() = (ContextProvider.get().context?.convertPx2sp(toFloat()) ?: 0f).toFloat()

/** Dimen资源ID转换为Px单位数据 **/
@Dimension
fun Context.getPxDimensionById(@DimenRes id: Int) =
    resources.getDimension(id)

/** Dimen资源ID转换为Px单位数据 **/
@Dimension
fun Int.toPxDimension(): Float =
    ContextProvider.get().context?.getPxDimensionById(this) ?: 0f

/** Dimen资源ID转换为Px单位数据 **/
@Dimension
fun Context.getPxDimensionOffsetById(@DimenRes id: Int) =
    resources.getDimensionPixelOffset(id)

/** Dimen资源ID转换为Px单位数据 **/
@Dimension
fun Int.toPxDimensionOffset(): Int =
    ContextProvider.get().context?.getPxDimensionOffsetById(this) ?: 0

/** Dimen资源ID转换为Px单位数据 **/
@Dimension
fun Context.getPxDimensionSizeById(@DimenRes id: Int) =
    resources.getDimensionPixelSize(id)

/** Dimen资源ID转换为Px单位数据 **/
@Dimension
fun Int.toPxDimensionSize(): Int =
    ContextProvider.get().context?.getPxDimensionSizeById(this) ?: 0