package com.sg.common.file.io

import com.sg.common.BuildConfig
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.math.BigInteger
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


/** 获取文件的md5值 **/
fun File.getMD5HexString(): String? {
    var bi: BigInteger? = null
    try {
        var len: Int
        val buffer = ByteArray(8192)
        val md = MessageDigest.getInstance("MD5")
        val fis = FileInputStream(this)
        while (true) {
            len = fis.read(buffer)
            if (len == -1) break
            md.update(buffer, 0, len)
        }
        fis.close()
        val b = md.digest()
        bi = BigInteger(1, b)
    } catch (e: NoSuchAlgorithmException) {
        if (BuildConfig.DEBUG)
            e.printStackTrace()
    } catch (e: IOException) {
        if (BuildConfig.DEBUG)
            e.printStackTrace()
    }
    return bi?.toString(16)
}

/**
 * 比较文件的MD5结果值
 * @param md5 文件的md5值
 * @return 如果MD5值相等，那么就返回true
 */
fun File.compareMD5(md5: String?): Boolean {
    if (md5 == null) return false
    val fileMd5 = getMD5HexString()
    if (fileMd5.isNullOrEmpty()) return false
    return fileMd5 == md5
}