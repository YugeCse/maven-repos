@file:Suppress("DEPRECATION")

package com.sg.common.widget.adapter


import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.viewpager.widget.PagerAdapter
import androidx.fragment.app.FragmentPagerAdapter as FragmentPageAdapter

/**
 * Fragment的ViewPager的数据适配器
 * @param fm  FragmentManager实例
 * @param fragments fragments集合
 * @param titles 标题栏集合
 */
@Suppress("DEPRECATION")
open class FragmentPagerAdapter<T : Fragment>(
    fm: FragmentManager,
    private var fragments: MutableList<T>,
    private var titles: MutableList<String>? = null,
    behavior: Int = BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
) : FragmentPageAdapter(fm, behavior) {

    companion object {

        const val BEHAVIOR_SET_USER_VISIBLE_HINT =
            FragmentPageAdapter.BEHAVIOR_SET_USER_VISIBLE_HINT

        const val BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT =
            FragmentPageAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
    }

    override fun getItem(position: Int): Fragment = fragments[position]

    override fun getCount(): Int = fragments.size

    override fun getItemId(position: Int): Long = fragments[position].hashCode().toLong()

    override fun getItemPosition(`object`: Any): Int {
        val objIndex = fragments.indexOf(`object`)
        if (objIndex == -1) return PagerAdapter.POSITION_NONE
        return PagerAdapter.POSITION_UNCHANGED
    }

    override fun getPageTitle(position: Int): CharSequence? =
        when {
            !titles.isNullOrEmpty() || titles?.size != fragments.size ->
                titles?.get(position)
            else -> super.getPageTitle(position)
        }

}