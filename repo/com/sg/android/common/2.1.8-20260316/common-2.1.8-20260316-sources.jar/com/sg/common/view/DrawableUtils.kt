package com.sg.common.view

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream

///**
// * 提供默认图给模板
// * @param context 上下文对象
// * @param imageType 图片类型
// */
//fun setDefaultImageToInputStream(context: Context, imageType: String): InputStream? {
//    return (if (imageType.isNotEmpty() && imageType == "author")
//        AppCompatResources.getDrawable(context, R.drawable.default_avatar_article_page)
//    else AppCompatResources.getDrawable(context, R.drawable.image_indicator))?.drawable2InputStream()
//}

/** Drawable转换成InputStream **/
fun Drawable.drawable2InputStream() =
    drawable2Bitmap().bitmap2InputStream()

/** 将Bitmap转换成InputStream **/
fun Bitmap.bitmap2InputStream(): InputStream {
    val stream = ByteArrayOutputStream().use { baos ->
        compress(Bitmap.CompressFormat.JPEG, 100, baos)
        ByteArrayInputStream(baos.toByteArray())
    }
    if (!isRecycled) recycle()
    return stream
}

/** Drawable转换成Bitmap **/
fun Drawable.drawable2Bitmap(): Bitmap {
    @Suppress("DEPRECATION")
    val bitmap = Bitmap.createBitmap(
        intrinsicWidth,
        intrinsicHeight,
        if (opacity != PixelFormat.OPAQUE)
            Bitmap.Config.ARGB_8888 else Bitmap.Config.RGB_565
    )
    val canvas = Canvas(bitmap)
    setBounds(0, 0, intrinsicWidth, intrinsicHeight)
    draw(canvas)
    return bitmap
}