package com.sg.common.widget.swipeback

interface SwipeListener {
    fun onScroll(percent: Float, px: Int)
    fun onEdgeTouch()

    /**
     * Invoke when scroll percent over the threshold for the first time
     */
    fun onScrollToClose()
}