package com.sg.common.view

import android.graphics.Color
import androidx.annotation.ColorInt

/** 颜色相关辅助类 **/
object ColorUtils {

    /**
     * 是否是暗色的颜色
     * @param color 颜色int值
     */
    @JvmStatic
    fun isDarkColor(@ColorInt color: Int): Boolean {
        val y = ((299 * Color.red(color)
                + 587 * Color.green(color)
                + 114 * Color.blue(color)) / 1000).toDouble()
        return y < 128.0
    }

}