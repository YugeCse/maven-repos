package com.sg.common.widget.recyclerview.divider

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * recyclerview万能分割线
 */
class ListItemDividerDecoration : RecyclerView.ItemDecoration {

    private var mPaint: Paint? = null//如果需要用画笔手绘

    private var mDrawableDivider: Drawable? = null//如果需要绘制给定的drawable

    private var mPaintDividerLength = 2//分割线宽度或高度

    private var drawType: DrawType? = null//用画笔绘制颜色，还是绘制特定的drawable

    /**
     * 注意：列表的方向
     * LinearLayoutManager.VERTICAL或LinearLayoutManager.HORIZONTAL
     */
    private var mOrientation: Int = LinearLayoutManager.VERTICAL

    /**
     * 自定义分割线
     *
     * @param context
     * @param orientation 列表方向
     * @param drawableId  分割线图片
     */
    @JvmOverloads
    constructor(context: Context, orientation: Int, @DrawableRes drawableId: Int = 0) {
        if (orientation != LinearLayoutManager.VERTICAL && orientation != LinearLayoutManager.HORIZONTAL) {
            throw IllegalArgumentException("请输入正确的参数！")
        }
        mOrientation = orientation
        if (drawableId == 0) {
            //获取系统的样式
            val a = context.obtainStyledAttributes(ATTRS)
            mDrawableDivider = a.getDrawable(0)
            a.recycle()
        } else {
            mDrawableDivider = ContextCompat.getDrawable(context, drawableId)
        }
        //表明绘制drawable
        drawType = DrawType.USEDRAWABLE
    }

    /**
     * 自定义分割线
     * @param orientation   列表方向
     * @param dividerHeight 分割线高度
     * @param dividerColor  分割线颜色
     */
    @JvmOverloads
    constructor(orientation: Int = LinearLayoutManager.VERTICAL, dividerHeight: Int, dividerColor: Int = Color.TRANSPARENT) {
        if (orientation != LinearLayoutManager.VERTICAL && orientation != LinearLayoutManager.HORIZONTAL)
            throw IllegalArgumentException("请输入正确的参数！")
        mOrientation = orientation
        if (dividerHeight != -100) //分割线高度
            mPaintDividerLength = dividerHeight
        //创建特定画笔
        mPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        mPaint?.color = dividerColor
        mPaint?.style = Paint.Style.FILL
        //表明绘制用paint
        drawType = DrawType.USEPAINT
    }

    /**
     * 看图说话：get Item Offsets,获得item的偏移量。此方法用来控制item的偏移
     * @param outRect
     * @param view
     * @param parent
     * @param state
     */
    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)
        //列表的方向为横向，画分割线就是纵向的，需要确定的是child的右边偏移值 留出空间画分割线
        when (this.mOrientation) {
            LinearLayoutManager.HORIZONTAL -> when (drawType) {
                DrawType.USEPAINT -> outRect.set(0, 0, mPaintDividerLength, 0)
                DrawType.USEDRAWABLE -> outRect.set(0, 0, mDrawableDivider!!.intrinsicWidth, 0)
                else -> {}
            }
            LinearLayoutManager.VERTICAL -> when (drawType) {
                DrawType.USEPAINT -> outRect.set(0, 0, 0, mPaintDividerLength)
                DrawType.USEDRAWABLE -> outRect.set(0, 0, 0, mDrawableDivider!!.intrinsicHeight)
                else -> {}
            }
        }
    }

    /**
     * 绘制分割线
     * @param c
     * @param parent
     * @param state
     */
    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        super.onDraw(c, parent, state)
        if (mOrientation == LinearLayoutManager.VERTICAL) {
            //列表是纵向的，需要绘制横向的分割线
            drawHorizontal(c, parent)
        } else {
            //列表是横向的，需要绘制纵向的分割线
            drawVertical(c, parent)
        }
    }

    /**
     * 绘制横向 item 分割线。左、上、右都是可计算的，下需要获取给定的高度值
     * @param canvas
     * @param parent
     */
    private fun drawHorizontal(canvas: Canvas, parent: RecyclerView) {
        //左边：到父容器的left内间距位置值
        val left = parent.paddingLeft
        //右边：到父容器的right内间距位置值
        val right = parent.measuredWidth - parent.paddingRight
        val childSize = parent.childCount
        //循环绘制每条分割线
        for (i in 0 until childSize) {
            val child = parent.getChildAt(i)
            val layoutParams = child.layoutParams as RecyclerView.LayoutParams
            //上边：具体的某条分割线的左边以child的(bottom+bottomMargin)位置值
            val top = child.bottom + layoutParams.bottomMargin
            //下边：根据类型判断
            val bottom: Int
            when (drawType) {
                //构造方法声明使用画笔绘制
                DrawType.USEPAINT -> {
                    //下边：top加上指定的高度
                    bottom = top + mPaintDividerLength
                    mPaint?.let {
                        canvas.drawRect(
                            left.toFloat(),
                            top.toFloat(),
                            right.toFloat(),
                            bottom.toFloat(),
                            it
                        )
                    }
                }
                //构造方法声明使用drawable
                DrawType.USEDRAWABLE -> if (mDrawableDivider != null) {
                    //下边：top加上指定的高度
                    bottom = top + (mDrawableDivider?.intrinsicHeight ?: 0)
                    mDrawableDivider?.setBounds(left, top, right, bottom)
                    mDrawableDivider?.draw(canvas)
                }
                else -> {}
            }
        }
    }

    /**
     * 绘制纵向 item 分割线。上、下、左都是可计算的，右侧需要获取给定的宽度值
     * @param canvas
     * @param parent
     */
    private fun drawVertical(canvas: Canvas, parent: RecyclerView) {
        //上边：到父容器的top内间距位置值
        val top = parent.paddingTop
        //下边：到父容器的bottom内间距位置值
        val bottom = parent.measuredHeight - parent.paddingBottom
        val childSize = parent.childCount
        //循环绘制每条分割线
        for (i in 0 until childSize) {
            val child = parent.getChildAt(i)
            val layoutParams = child.layoutParams as RecyclerView.LayoutParams
            //左边：具体的某条分割线的左边以child的(right+rightMargin)位置值
            val left = child.right + layoutParams.rightMargin
            //右边：根据类型判断
            val right: Int
            when (drawType) {
                //构造方法声明使用画笔绘制
                DrawType.USEPAINT -> {
                    //右边：left加上指定的宽度
                    right = left + mPaintDividerLength
                    if (mPaint != null) {
                        canvas.drawRect(
                            left.toFloat(),
                            top.toFloat(),
                            right.toFloat(),
                            bottom.toFloat(),
                            mPaint!!
                        )
                    }
                }
                //构造方法声明使用drawable
                DrawType.USEDRAWABLE -> if (mDrawableDivider != null) {
                    //右边：left加上指定的宽度
                    right = left + (mDrawableDivider?.intrinsicWidth ?: 0)
                    mDrawableDivider?.setBounds(left, top, right, bottom)
                    mDrawableDivider?.draw(canvas)
                }
                else -> {}
            }
        }
    }

    //画特定的drawable
    private enum class DrawType(val type: Int) {
        USEPAINT(1), //用画笔画
        USEDRAWABLE(2)
    }

    companion object {
        //系统默认的分割线
        private val ATTRS = intArrayOf(android.R.attr.listDivider)
    }

}