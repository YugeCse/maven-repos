package com.sg.common.file.zip

import java.io.*
import java.util.zip.ZipInputStream


/** ZIP解压工具类 **/
object Zipper {

    /** 解压zip文件 **/
    @JvmStatic
    @Throws(Exception::class)
    fun unzip(source: File, destination: File) =
        unzip(source.absolutePath, destination.absolutePath)

    /**
     * 解压zip文件
     * @param source 源文件
     * @param destination 目标目录
     */
    @JvmStatic
    @Throws(Exception::class)
    fun unzip(source: String, destination: String) {
        // create root folder first
        createDirectory(destination)
        val zipStream = ZipInputStream(BufferedInputStream(FileInputStream(source)))
        while (true) {
            val entry = zipStream.nextEntry ?: break
            // new file destination after unzip
            val filePath = destination + File.separator + entry.name
            when {
                // if is directory then create folder
                entry.isDirectory ->
                    createDirectory(filePath)
                // else unzip file into destination
                else -> unzipFile(zipStream, filePath)
            }
            // close current index
            zipStream.closeEntry()
        }
        zipStream.close()
    }

    /** 创建文件夹 **/
    private fun createDirectory(path: String) = File(path).mkdirs()

    /** 解压文件 **/
    private fun unzipFile(zipStream: ZipInputStream, filePath: String) {
        val file = File(filePath)
        if (file.exists())
            file.delete()
        file.parentFile?.mkdirs()
        file.createNewFile()
        val outputStream = FileOutputStream(filePath)
        copyStream(zipStream, outputStream)
        outputStream.close()
    }

    /**
     * 复制数据流
     * @param inputStream 输入数据流
     * @param outputStream 输出数据流
     */
    private fun copyStream(inputStream: InputStream, outputStream: FileOutputStream) {
        val buffer = ByteArray(4096)
        while (true) {
            val stream = inputStream.read(buffer)
            if (stream == -1) break
            outputStream.write(buffer, 0, stream)
        }
    }

}