package com.sg.common.app

import com.sg.common.BuildConfig
import timber.log.Timber
import timber.log.Timber.*


/**
 * @Author: 曹秋淋
 * @Date: 2023/1/6
 * 统一日志输出类
 */
object LogUtils {

    private const val DefaultLogTAG = "CommonLog"

    /** 日志输出是否可用 **/
    private var logPrintEnable = BuildConfig.DEBUG

    /**
     * 设置debug是否可用
     * @param enabled 是否可用，默认情况下为debug模式下可用
     */
    fun setLogPrintEnabled(enabled: Boolean) {
        logPrintEnable = enabled
        if (logPrintEnable) Timber.plant(DebugTree())
    }

    /** 日志输出 **/
    private fun debugPrint(task: () -> Unit) {
        if (!logPrintEnable) return
        task.invoke() //执行内容输出
    }

    /**
     * info 级别日志输出
     * @param tag
     * @param msg 打印内容
     * @param formatArgs 日志参数
     */
    @JvmStatic
    fun log4i(
        tag: String = DefaultLogTAG,
        msg: String,
        vararg formatArgs: Any?
    ) = debugPrint { Timber.tag(tag).i(msg, *formatArgs) }

    /**
     * info 级别日志输出
     * @param tag
     * @param throwable 异常信息
     */
    @JvmStatic
    fun log4i(
        tag: String = DefaultLogTAG,
        throwable: Throwable
    ) = debugPrint { Timber.tag(tag).i(throwable) }

    /**
     * desc 级别日志输出
     * @param tag
     * @param msg 打印内容
     * @param formatArgs 日志参数
     */
    @JvmStatic
    fun log4d(
        tag: String = DefaultLogTAG,
        msg: String,
        vararg formatArgs: Any?
    ) = debugPrint { Timber.tag(tag).d(msg, *formatArgs) }

    /**
     * desc 级别日志输出
     * @param tag
     * @param throwable 异常信息
     */
    @JvmStatic
    fun log4d(
        tag: String = DefaultLogTAG,
        throwable: Throwable
    ) = debugPrint { Timber.tag(tag).d(throwable) }

    /**
     * waring 级别日志输出
     * @param tag
     * @param msg 打印内容
     * @param formatArgs 日志参数
     */
    @JvmStatic
    fun log4w(
        tag: String = DefaultLogTAG,
        msg: String?,
        vararg formatArgs: Any?
    ) = debugPrint { Timber.tag(tag).w(msg, *formatArgs) }

    /**
     * waring 级别日志输出
     * @param tag
     * @param throwable 打印内容
     */
    @JvmStatic
    fun log4w(
        tag: String = DefaultLogTAG,
        throwable: Throwable
    ) = debugPrint { Timber.tag(tag).w(throwable) }

    /**
     * error 级别日志输出
     * @param tag
     * @param msg 打印内容
     * @param formatArgs 日志参数
     */
    @JvmStatic
    fun log4e(
        tag: String = DefaultLogTAG,
        msg: String,
        vararg formatArgs: Any?
    ) = debugPrint { Timber.tag(tag).e(msg, *formatArgs) }

    /**
     * error 级别日志输出
     * @param tag
     * @param throwable 异常信息
     */
    @JvmStatic
    fun log4e(
        tag: String = DefaultLogTAG,
        throwable: Throwable
    ) = debugPrint { Timber.tag(tag).e(throwable) }
}