package com.sg.common.view

import android.app.Activity
import androidx.core.view.WindowInsetsControllerCompat


/** 页面切换动画信息 **/
typealias PageTransitionAnimationInfo = Pair<Int, Int>

/** 获取或设置页面进入时的动画 **/
val PageTransitionAnimationInfo.enterAnimationId get() = first

/** 获取或设置页面结束时的动画 **/
val PageTransitionAnimationInfo.exitAnimationId get() = second

/** 修改状态栏上文字图标的颜色 **/
fun Activity.setStatusBarIconDarkMode(isDark: Boolean) = apply {
    WindowInsetsControllerCompat(window, window.decorView)
        .apply { isAppearanceLightStatusBars = isDark }
}

/** 修改导航栏上文字图标的颜色 **/
fun Activity.setNavigationBarIconDarkMode(isDark: Boolean) = apply {
    WindowInsetsControllerCompat(window, window.decorView)
        .apply { isAppearanceLightNavigationBars = isDark }
}

/** 修改状态栏和导航栏上文字图标的颜色 **/
fun Activity.setSystemBarIconDarkMode(isDark: Boolean) = apply {
    WindowInsetsControllerCompat(window, window.decorView).apply {
        isAppearanceLightStatusBars = isDark
        isAppearanceLightNavigationBars = isDark
    }
}

/** 修改状态栏和导航栏上文字图标的颜色 **/
fun Activity.setSystemBarIconDarkMode(
    config: WindowInsetsControllerCompat.() -> Unit
) = apply { WindowInsetsControllerCompat(window, window.decorView).apply(config) }