@file:Suppress("DEPRECATION")

package com.sg.common.app

import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.result.ActivityResultLauncher
import androidx.fragment.app.Fragment

/** 分享功能辅助类 **/
object ShareUtils {

    /**
     * 分享文本
     * @param title 标题
     * @param text 文本内容
     */
    fun createShareTextIntent(
        title: String,
        text: String
    ): Intent = Intent(Intent.ACTION_SEND)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        .setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, text)
        .run { Intent.createChooser(this, title) }

    /**
     * 分享图片
     * @param title 标题
     * @param imageUri 图片资源路径
     * @param extraText 文本内容
     */
    fun createShareImageIntent(
        title: String,
        imageUri: Uri,
        extraText: String?,
    ): Intent = Intent(Intent.ACTION_SEND)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        .setType("image/*")
        .putExtra(Intent.EXTRA_STREAM, imageUri)
        .apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (!extraText.isNullOrEmpty())
                putExtra(Intent.EXTRA_TEXT, extraText)
        }
        .apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        .run { Intent.createChooser(this, title) }

    /**
     * 分享文本
     * @param context 上下文对象
     * @param title 标题
     * @param text 文本
     */
    @JvmStatic
    fun shareText(
        context: Context,
        title: String,
        text: String
    ) = try {
        context.startActivity(createShareTextIntent(title, text))
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareText]: $e")
    }

    /**
     * 分享文本
     * @param activity 上下文对象
     * @param title 标题
     * @param text 文本
     */
    @JvmStatic
    @JvmOverloads
    fun shareText(
        activity: Activity,
        title: String,
        text: String,
        reqCode: Int? = null,
    ) = try {
        val intent = createShareTextIntent(title, text)
        if (reqCode == null)
            activity.startActivity(intent)
        else activity.startActivityForResult(intent, reqCode)
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareText]: $e")
    }

    /**
     * 分享文本
     * @param fragment fragment對象
     * @param title 标题
     * @param text 文本
     */
    @JvmStatic
    fun shareText(
        fragment: Fragment,
        title: String,
        text: String
    ) = try {
        fragment.startActivity(createShareTextIntent(title, text))
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareText]: $e")
    }

    /**
     * 分享图片
     * @param context 上下文对象
     * @param title 标题
     * @param imageUri 图片的URI
     * @param extraText 附带的说明文字
     */
    @JvmStatic
    @JvmOverloads
    fun shareImage(
        context: Context,
        title: String,
        imageUri: Uri,
        extraText: String? = null,
    ) = try {
        context.startActivity(createShareImageIntent(title, imageUri, extraText))
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareImage]: $e")
    }

    /**
     * 分享图片
     * @param activity 上下文对象
     * @param title 标题
     * @param imageUri 图片的URI
     * @param extraText 附带的说明文字
     */
    @JvmStatic
    @JvmOverloads
    fun shareImage(
        activity: Activity,
        title: String,
        imageUri: Uri,
        extraText: String? = null,
        reqCode: Int? = null,
    ) = try {
        val intent = createShareImageIntent(title, imageUri, extraText)
        if (reqCode == null)
            activity.startActivity(intent)
        else activity.startActivityForResult(intent, reqCode)
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareImage]: $e")
    }

    /**
     * 分享图片
     * @param fragment fragment對象
     * @param title 标题
     * @param imageUri 图片的URI
     * @param extraText 附带的说明文字
     * @param reqCode 請求碼，默認置空
     */
    @JvmStatic
    @JvmOverloads
    fun shareImage(
        fragment: Fragment,
        title: String,
        imageUri: Uri,
        extraText: String? = null,
        reqCode: Int? = null,
    ) = try {
        val intent = createShareImageIntent(title, imageUri, extraText)
        if (reqCode == null)
            fragment.startActivity(intent)
        else fragment.startActivityForResult(intent, reqCode)
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareImage]: $e")
    }

    /**
     * 分享多张图片
     * @param context 上下文对象
     * @param title 标题
     * @param imageUris 图片的URI集合
     */
    @JvmStatic
    fun shareImages(
        context: Context,
        title: String,
        imageUris: ArrayList<Uri>
    ) = try {
        context.startActivity(
            Intent(Intent.ACTION_SEND_MULTIPLE)
                .setType("image/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris)
                .apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                .run { Intent.createChooser(this, title) }
                .apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
        )
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareImages]: $e")
    }

    /**
     * 分享图片
     * @param launcher 分享返回状态
     * @param title 标题
     * @param imageUri 图片的URI
     * @param extraText 附带的说明文字
     */
    fun shareImageWithResult(
        pendingIntent: PendingIntent,
        launcher: ActivityResultLauncher<Intent>,
        title: String,
        imageUri: Uri,
        extraText: String? = null
    ) = try {
        launcher.launch(
            Intent(Intent.ACTION_SEND)
                .setType("image/*")
                .putExtra(Intent.EXTRA_STREAM, imageUri)
                .apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    if (!extraText.isNullOrEmpty())
                        putExtra(Intent.EXTRA_TEXT, extraText)
                }
                .run { Intent.createChooser(this, title, pendingIntent.intentSender) }
                .apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
        )
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareImageWithResult]: $e")
    }

    /**
     * 分享文本
     * @param launcher 分享返回状态
     * @param title 标题
     * @param text 文本
     */
    fun shareTextWithResult(
        pendingIntent: PendingIntent,
        launcher: ActivityResultLauncher<Intent>,
        title: String,
        text: String
    ) = try {
        launcher.launch(
            Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, text)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .run { Intent.createChooser(this, title, pendingIntent.intentSender) }
        )
    } catch (e: Exception) {
        LogUtils.log4e("ShareUtils", "fun[shareTextWithResult]: $e")
    }

}