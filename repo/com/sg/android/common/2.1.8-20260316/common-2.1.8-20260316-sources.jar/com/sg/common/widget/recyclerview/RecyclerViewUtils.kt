package com.sg.common.widget.recyclerview

import android.graphics.Color
import android.util.TypedValue
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.sg.common.view.convertDip2px
import com.sg.common.widget.recyclerview.divider.GridItemDividerDecoration
import com.sg.common.widget.recyclerview.divider.ListItemDividerDecoration

/**
 * 设置RecyclerView的LinearLayoutManager
 * @param orientation 布局方向，默认使用[RecyclerView.VERTICAL]
 * @param verticalScrollable 垂直方向是否可滚动，默认使用系统提供
 * @param horizontalScrollable 横向是否可滚动，默认使用系统提供
 */
fun RecyclerView.linearLayout(
    @RecyclerView.Orientation orientation: Int = RecyclerView.VERTICAL,
    verticalScrollable: Boolean? = null,
    horizontalScrollable: Boolean? = null,
    reverseLayout: Boolean = false
) {
    layoutManager = object : LinearLayoutManager(context, orientation, reverseLayout) {
        override fun canScrollHorizontally(): Boolean = horizontalScrollable
            ?: super.canScrollHorizontally()

        override fun canScrollVertically(): Boolean = verticalScrollable
            ?: super.canScrollVertically()
    }
}

/**
 * 设置RecyclerView的GridLayoutManager
 * @param columnNum 列数
 * @param orientation 布局方向，默认使用[RecyclerView.HORIZONTAL]
 * @param verticalScrollable 垂直方向是否可滚动，默认使用系统提供
 * @param horizontalScrollable 横向是否可滚动，默认使用系统提供
 */
fun RecyclerView.gridLayout(
    columnNum: Int,
    @RecyclerView.Orientation orientation: Int = RecyclerView.VERTICAL,
    verticalScrollable: Boolean? = null,
    horizontalScrollable: Boolean? = null,
    reverseLayout: Boolean = false
) {
    layoutManager = object : GridLayoutManager(context, columnNum, orientation, reverseLayout) {
        override fun canScrollHorizontally(): Boolean = horizontalScrollable
            ?: super.canScrollHorizontally()

        override fun canScrollVertically(): Boolean = verticalScrollable
            ?: super.canScrollVertically()
    }
}

/**
 * 设置RecyclerView的StaggeredGridLayoutManager
 * @param columnNum 列数
 * @param orientation 布局方向，默认使用[RecyclerView.HORIZONTAL]
 * @param verticalScrollable 垂直方向是否可滚动，默认使用系统提供
 * @param horizontalScrollable 横向是否可滚动，默认使用系统提供
 */
fun RecyclerView.staggeredGridLayout(
    columnNum: Int,
    @RecyclerView.Orientation orientation: Int = RecyclerView.VERTICAL,
    verticalScrollable: Boolean? = null,
    horizontalScrollable: Boolean? = null
) {
    layoutManager = object : StaggeredGridLayoutManager(columnNum, orientation) {

        override fun canScrollHorizontally(): Boolean = horizontalScrollable
            ?: super.canScrollHorizontally()

        override fun canScrollVertically(): Boolean = verticalScrollable
            ?: super.canScrollVertically()
    }.apply {
        gapStrategy = StaggeredGridLayoutManager.GAP_HANDLING_NONE
    }
}

/**
 * 设置LinearLayoutManager的分割线
 * @param dividerColor 分割线颜色
 * @param dividerSize 分割线大小
 */
fun RecyclerView.addLinearItemDivider(
    orientation: Int = LinearLayoutManager.VERTICAL,
    dividerSize: Int,
    dividerSizeUnit: Int = TypedValue.COMPLEX_UNIT_DIP,
    dividerColor: Int = Color.TRANSPARENT
) {
    if (dividerSizeUnit !in arrayOf(TypedValue.COMPLEX_UNIT_DIP, TypedValue.COMPLEX_UNIT_PX))
        throw Exception("分割线单位错误，取值应该为：TypedValue.COMPLEX_UNIT_DIP或TypedValue.COMPLEX_UNIT_PX")
    addItemDecoration(
        ListItemDividerDecoration(
            orientation, when (dividerSizeUnit) {
                TypedValue.COMPLEX_UNIT_DIP ->
                    context.convertDip2px(dividerSize.toFloat()).toInt()
                else -> dividerSize
            }, dividerColor
        )
    )
}

fun RecyclerView.addVerticalItemDivider(
    dividerSize: Int,
    dividerSizeUnit: Int = TypedValue.COMPLEX_UNIT_DIP,
    dividerColor: Int = Color.TRANSPARENT
) = addLinearItemDivider(LinearLayoutManager.VERTICAL, dividerSize, dividerSizeUnit, dividerColor)

fun RecyclerView.addHorizontalItemDivider(
    dividerSize: Int,
    dividerSizeUnit: Int = TypedValue.COMPLEX_UNIT_DIP,
    dividerColor: Int = Color.TRANSPARENT
) = addLinearItemDivider(LinearLayoutManager.HORIZONTAL, dividerSize, dividerSizeUnit, dividerColor)

/** 设置GridLayoutManager的分割线 **/
fun RecyclerView.addGridItemDivider(
    dividerSize: Int,
    dividerSizeUnit: Int = TypedValue.COMPLEX_UNIT_DIP,
    dividerType: GridItemDividerDecoration.SpaceType = GridItemDividerDecoration.SpaceType.ALL
): GridItemDividerDecoration {
    if (dividerSizeUnit !in arrayOf(TypedValue.COMPLEX_UNIT_DIP, TypedValue.COMPLEX_UNIT_PX))
        throw Exception("分割线单位错误，取值应该为：TypedValue.COMPLEX_UNIT_DIP或TypedValue.COMPLEX_UNIT_PX")
    val itemDecoration = GridItemDividerDecoration(
        when (dividerSizeUnit) {
            TypedValue.COMPLEX_UNIT_DIP ->
                context.convertDip2px(dividerSize.toFloat()).toInt()
            else -> dividerSize
        }, dividerType
    )
    addItemDecoration(itemDecoration)
    return itemDecoration
}


/** 设置RecyclerView不支持变化动画 **/
fun RecyclerView.setNotSupportsChangeAnimations() {
    itemAnimator?.changeDuration = 0
    (itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
    itemAnimator = null
}
