package com.sg.common.widget.recyclerview.divider

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * 列表间隔线
 *
 * @param dividerHeight 间隔线高度，单位：Pixel
 * @param dividerColor 间隔线颜色
 */
class VerticalListItemDividerDecoration(
    private val dividerHeight: Float,
    private val dividerColor: Int = Color.TRANSPARENT
) :
    RecyclerView.ItemDecoration() {

    private var dividerPainter: Paint = Paint()

    init {
        dividerPainter.isAntiAlias = true
        dividerPainter.color = dividerColor
    }

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)
        outRect.bottom = dividerHeight.toInt()
    }

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        super.onDraw(c, parent, state)
        val left = parent.paddingLeft
        val right = parent.width - parent.paddingRight
        IntRange(0, parent.childCount - 1).forEach {
            val itemView = parent.getChildAt(it)
            val bottom = itemView.bottom + dividerHeight.toInt()
            c.drawRect(
                left.toFloat(),
                itemView.bottom.toFloat(),
                bottom.toFloat(),
                right.toFloat(),
                dividerPainter
            )
        }
    }

}