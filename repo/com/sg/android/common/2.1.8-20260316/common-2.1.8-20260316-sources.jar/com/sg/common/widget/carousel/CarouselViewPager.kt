package com.sg.common.widget.carousel

import android.content.Context
import android.util.AttributeSet
import androidx.viewpager.widget.ViewPager
import com.sg.common.R

class CarouselViewPager : ViewPager {

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val newHeightSpec = wrapChildHeight(widthMeasureSpec)
        super.onMeasure(widthMeasureSpec, newHeightSpec)
    }

    private fun wrapChildHeight(widthMeasureSpec: Int): Int {
        var height = 0
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            child.measure(
                widthMeasureSpec - paddingStart - paddingEnd + paddingTop + paddingBottom,
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            )
            val h = child.measuredHeight
            if (h > height) height = h
        }
        val topPadding = context.resources.getDimension(R.dimen.dp_0).toInt()
        return MeasureSpec.makeMeasureSpec(height + topPadding, MeasureSpec.EXACTLY)
    }
}
