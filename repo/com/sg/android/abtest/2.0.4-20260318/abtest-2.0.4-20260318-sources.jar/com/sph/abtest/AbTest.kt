package com.sph.abtest

import com.sph.abtest.api.AbTestApiRepo
import com.sph.abtest.data.AbTestActivateCallbackInfo
import com.sph.abtest.data.AbTestActivateReqInfo
import com.sph.abtest.data.AbTestConfigInfo
import com.sph.tracking.api.ApiCallback
import com.sph.tracking.api.SSIDReqConfigInfo
import com.sph.tracking.tracker.Tracking

/** ABTest主类 **/
object AbTest {

    /** SDK版本信息 **/
    const val SDK_VERSION = BuildConfig.SDK_VERSION

    /**
     * 配置数据,不为空的参数将被记录，与[Tracking.config]调用其一即可
     * @param dataTransportUrl 数据上报链接，必传
     * @param apiDomainForAbTest AbTester的接口域名地址，example: https://www.zaobao.com/
     * @param value 应用方法，配置数据中的dataReportUrl和apiDomainForAbTester会被前面的参数覆盖
     */
    @JvmStatic
    @Throws(IllegalArgumentException::class)
    fun config(
        dataTransportUrl: String,
        apiDomainForAbTest: String,
        value: AbTestConfigInfo.() -> Unit
    ) {
        if (dataTransportUrl.trim().isEmpty()
            || !dataTransportUrl.matches("^https?://.*".toRegex())
        )
            throw IllegalArgumentException("参数[dataReportUrl]不能为空且必须以http[s]开头")
        if (apiDomainForAbTest.trim().isEmpty()
            || !apiDomainForAbTest.matches("^https?://.*".toRegex())
        )
            throw IllegalArgumentException("参数[apiDomainForAbTester]不能为空且必须以http[s]开头")
        val configInfo = AbTestConfigInfo(
            dataTransportUrl = dataTransportUrl,
            apiDomainForAbTest = apiDomainForAbTest
        ).apply(value)
        Tracking.config(dataTransportUrl = dataTransportUrl, value = configInfo)
    }

    /**
     * 获取SSID参数
     * @param apiUrl 请求链接地址
     * @param queryParams 查询参数
     * @param postParams POST参数
     * @param callback 回调方法
     */
    @JvmStatic
    fun getSSID(
        apiUrl: String,
        queryParams: Map<String, Any?> = mapOf(),
        postParams: SSIDReqConfigInfo.() -> Unit = {},
        callback: (ApiCallback<String>) -> Unit
    ) = Tracking.getSSID(
        apiUrl = apiUrl,
        queryParams = queryParams,
        postParams = postParams,
        callback = callback
    )

    /**
     * 获取ABTest分流信息
     * @param apiUrl API分流接口地址
     * @param params 参数信息
     * @param callback 回调方法
     */
    @JvmStatic
    fun getActivateData(
        apiUrl: String,
        params: AbTestActivateReqInfo.() -> Unit,
        callback: (ApiCallback<AbTestActivateCallbackInfo>) -> Unit
    ) = AbTestApiRepo.getABTestActivateData(apiUrl, params, callback)

    /**
     * 启用日志集中上传，与[Tracking.startDataTransport]调用其一即可
     * @param perUploadMaxCount - 每次上传的最大数据条数,默认：12
     **/
    @JvmStatic
    fun startDataTransport(perUploadMaxCount: Int = 12) =
        Tracking.startDataTransport(perUploadMaxCount = perUploadMaxCount)

    /** 关闭日志集中上传，与[Tracking.stopDataTransport]调用其一即可 **/
    @JvmStatic
    fun stopDataTransport() = Tracking.stopDataTransport()

    /**
     * 设置日志打印是否可用，与[Tracking.setLogPrintEnabled]是一个方法
     * @param value 日志是否可用
     */
    @JvmStatic
    fun logPrintEnabled(value: Boolean) = Tracking.setLogPrintEnabled(value)

}