package com.sph.abtest.api

import com.google.gson.Gson
import com.sph.abtest.data.AbTestActivateCallbackInfo
import com.sph.abtest.data.AbTestActivateReqInfo
import com.sph.tracking.api.ApiCallback
import com.sph.tracking.api.HttpApi
import com.sph.tracking.api.HttpApiResponseInfo
import com.sph.tracking.api.isSuccessful
import com.sph.tracking.utils.app.SharedPrefs
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody

/** ABTestApi仓库 **/
internal object AbTestApiRepo {

    /**
     * 获取ABTest分流信息
     * @param apiUrl API分流接口获取
     * @param params 参数信息
     * @param callback 回调方法
     * @return 返回分流数据结果或者返回失败
     */
    @JvmStatic
    fun getABTestActivateData(
        apiUrl: String,
        params: AbTestActivateReqInfo.() -> Unit,
        callback: (ApiCallback<AbTestActivateCallbackInfo>) -> Unit
    ): Call = HttpApi.singleton().postAsync<HttpApiResponseInfo<AbTestActivateCallbackInfo>>(
        url = apiUrl,
        queryParams = mapOf(
            "ak" to SharedPrefs.trackingId,
            "sk" to SharedPrefs.apiSecretKey
        ),
        requestBody = Gson()
            .toJson(
                AbTestActivateReqInfo()
                    .apply(params).toMap()
            )
            .toRequestBody("application/json".toMediaTypeOrNull())
    ) { result ->
        callback.invoke(
            when (result) {
                is ApiCallback.Success -> when {
                    result.isSuccessful &&
                            result.dataResult?.isSuccessful == true ->
                        ApiCallback.Success(
                            result.code,
                            result.dataResult?.message,
                            result.dataResult?.data
                        )

                    else -> ApiCallback.Fail(
                        result.code, result.dataResult?.message
                            ?: result.message
                    )
                }

                else -> ApiCallback.Fail(result.code, result.message)
            }
        )
    }

}