package com.sph.abtest.data

import com.sph.tracking.tracker.TrackingConfigInfo

/**
 * AbTest配置信息
 * @param logPrint 是否可以打印日志
 * @param trackingId 追踪ID
 * @param deviceId 设备唯一ID
 * @param gaId GAId
 * @param ssId SSID，从服务器换取的ID
 * @param userId 登录用户的ID
 * @param templateVersion 应用模板ID
 * @param dataTransportUrl 数据上报接口
 * @param apiDomainForAbTest ABTest获取分流接口的网址链接域名，例如：http://www.zaobao.com
 */
data class AbTestConfigInfo(
    override var logPrint: Boolean? = null,
    override var trackingId: String? = null,
    override var secretKey: String? = null,
    override var deviceId: String? = null,
    override var gaId: String? = null,
    override var ssId: String? = null,
    override var userId: String? = null,
    override var templateVersion: String? = null,
    override var dataTransportUrl: String,
    var apiDomainForAbTest: String
) : TrackingConfigInfo(
    logPrint = logPrint,
    trackingId = trackingId,
    secretKey = secretKey,
    deviceId = deviceId,
    gaId = gaId,
    ssId = ssId,
    userId = userId,
    templateVersion = templateVersion,
    dataTransportUrl = dataTransportUrl)