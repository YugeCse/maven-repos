package com.sph.abtest.data

import com.google.gson.annotations.SerializedName

/**
 * ABTestActivate信息
 * @param variantKey 实验参数key
 * @param decisionId 分流ID，APP传SSID
 * @param attributes 用户属性，map(key-value)
 */
data class AbTestActivateReqInfo(
    @field: SerializedName("variant_key")
    var variantKey: String? = null,
    @field: SerializedName("decision_id")
    var decisionId: String? = null,
    @field: SerializedName("attributes")
    var attributes: LinkedHashMap<String, Any?>? = null
) {

    fun toMap(): LinkedHashMap<String, Any?> {
        return LinkedHashMap<String, Any?>().apply {
            put("variant_key", variantKey)
            put("decision_id", decisionId)
            put("attributes", attributes)
        }
    }

}
