package com.sph.abtest.data

/**
 * 分流数据类型
 * @param value 数据类型取值，来自服务器
 */
enum class AbTestActiveDataType(val value: Array<kotlin.String>) {

    /** Char类型 **/
    Char(value = arrayOf("char")),

    /** Boolean类型 **/
    Boolean(value = arrayOf("boolean", "bool")),

    /** Long类型 **/
    Long(value = arrayOf("long", "int", "short")),

    /** Double类型 **/
    Double(value = arrayOf("double", "float")),

    /** 字符串类型 **/
    String(value = arrayOf("string")),

    /** XML类型 **/
    Xml(value = arrayOf("xml")),

    /** JSON类型 **/
    Json(value = arrayOf("json")),

    /** 未知类型 **/
    Unknown(value = arrayOf("unknown", ""));

    companion object {

        /** 转换为分流数据类型，查看 [AbTestActiveDataType] **/
        @JvmStatic
        fun kotlin.String.toAbTestActiveDataType() =
            entries.firstOrNull { it.value.contains(lowercase()) } ?: Unknown

    }

}