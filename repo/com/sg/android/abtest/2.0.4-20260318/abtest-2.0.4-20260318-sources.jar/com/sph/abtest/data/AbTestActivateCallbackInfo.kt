package com.sph.abtest.data

import com.google.gson.annotations.SerializedName
import com.sph.abtest.data.AbTestActiveDataType.Companion.toAbTestActiveDataType

/**
 * ABTestActivate返回信息
 * @param vid 实验参数key
 * @param type 分流ID，APP传SSID
 * @param value 用户属性，map(key-value)
 */
data class AbTestActivateCallbackInfo(
    @field: SerializedName("vid")
    var vid: String? = null,
    @field: SerializedName("type")
    var type: String? = null,
    @field: SerializedName("val")
    var value: Any? = null
) {

    /** 获取分流数据类型 **/
    val activeValueType: AbTestActiveDataType
        get() = type?.toAbTestActiveDataType() ?: AbTestActiveDataType.Unknown

}