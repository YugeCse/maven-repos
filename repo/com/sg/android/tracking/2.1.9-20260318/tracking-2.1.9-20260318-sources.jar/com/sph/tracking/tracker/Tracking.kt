package com.sph.tracking.tracker

import com.google.gson.Gson
import com.sph.tracking.BuildConfig
import com.sph.tracking.api.ApiCallback
import com.sph.tracking.api.HttpApiRepo
import com.sph.tracking.api.SSIDReqConfigInfo
import com.sph.tracking.crash.GlobalCrashHandler
import com.sph.tracking.crash.GlobalCrashLogHandler
import com.sph.tracking.data.db.query.TrackingLogQuery
import com.sph.tracking.data.db.table.TrackingLogInfo
import com.sph.tracking.data.tracking.EventInfo
import com.sph.tracking.data.tracking.EventType
import com.sph.tracking.data.tracking.ParamsInfo
import com.sph.tracking.data.tracking.params.AppOpenParamsInfo
import com.sph.tracking.data.tracking.params.AppUninstallParamsInfo
import com.sph.tracking.data.tracking.params.AppUpgradeParamsInfo
import com.sph.tracking.data.tracking.params.AppUsageDurationParamsInfo
import com.sph.tracking.data.tracking.params.ExceptionParamsInfo
import com.sph.tracking.data.tracking.params.PageTimingParamsInfo
import com.sph.tracking.data.tracking.params.ScreenViewParamsInfo
import com.sph.tracking.data.tracking.params.SearchParamsInfo
import com.sph.tracking.data.tracking.params.ShareParamsInfo
import com.sph.tracking.provider.ContextProvider
import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.log.LogUtils
import com.sph.tracking.utils.other.SessionGenerator
import okhttp3.Interceptor
import java.net.Proxy

/**
 * 埋点分析主类
 * @param trackingId 埋点追踪ID
 */
class Tracking private constructor(private val trackingId: String) {

    /** API网络请求代理 **/
    internal var apiProxy: Proxy? = Proxy.NO_PROXY

    /** 埋点数据上报对象 **/
    private val trackingDataTransporter by lazy {
        TrackingDataTransporter.singleton()
    }

    /** 设置网络请求中的Interceptor集合 **/
    val interceptors = mutableListOf<Interceptor>()

    /** 设置网络请求中的Interceptor集合: 网络请求的情况下生效 **/
    val networkInterceptors = mutableListOf<Interceptor>()

    init {
        LogUtils.log4i(
            tag = "TrackingAnalyze",
            formatArgs = arrayOf(SDK_VERSION),
            msg = "TrackingAnalyze SDK Initialize! SDK VERSION = V%s"
        )
    }

    /**
     * 添加事件信息的埋点
     * @param eventName 事件名称，取值：[EventType.value]或者其他自定义
     * @param paramsInfo 事件参数
     */
    fun <T : ParamsInfo> trackEvent(eventName: String, paramsInfo: T) =
        trackEvents(listOf(EventInfo(name = eventName, params = paramsInfo)))

    /**
     * 添加事件信息的埋点
     * @param eventName 事件名称，取值：[EventType.value]或者其他自定义
     * @param paramsInfo 事件参数, 使用默认**无参构造函数**创建对象并赋值
     */
    inline fun <reified T : ParamsInfo> trackEvent(
        eventName: String,
        paramsInfo: T.() -> Unit
    ) = trackEvent(
        eventName = eventName,
        paramsInfo = T::class.java.getConstructor()
            .newInstance()
            .apply(paramsInfo)
    )

    /**
     * 添加事件信息的埋点
     * @param eventType 事件类型[EventType]
     * @param paramsInfo 事件参数
     */
    fun <T : ParamsInfo> trackEvent(eventType: EventType, paramsInfo: T) =
        trackEvent(EventInfo(name = eventType.value, params = paramsInfo))

    /**
     * 添加事件信息的埋点
     * @param eventType 事件类型[EventType]
     * @param paramsInfo 事件参数, 使用默认**无参构造函数**创建对象并赋值
     */
    inline fun <reified T : ParamsInfo> trackEvent(
        eventType: EventType,
        paramsInfo: T.() -> Unit
    ) = trackEvent(
        eventName = eventType.value,
        paramsInfo = T::class.java.getConstructor()
            .newInstance()
            .apply(paramsInfo)
    )

    /**
     * 添加事件信息的埋点
     * @param event 事件信息
     */
    fun <T : ParamsInfo> trackEvent(event: EventInfo<T>): Long? {
        val result = when (event.params) {
            null -> null
            else -> addTrackingLogs(event.apply {
                params?.sessionId = SessionGenerator.generateSessionId()
            })?.firstOrNull()
        }
        if (trackingDataTransporter.isSatisfyCountRequired)
            trackingDataTransporter.submitUploadTask()
        return result
    }

    /**
     * 添加事件信息的埋点
     * @param events 事件集合
     */
    fun <T : ParamsInfo> trackEvents(events: List<EventInfo<T>>): List<Long>? {
        val submitEvents = events.filter { v -> v.params != null }
            .map { v ->
                v.apply {
                    params?.apply {
                        sessionId = SessionGenerator.generateSessionId()
                    }
                }
            }
            .toTypedArray()
        val result = if (submitEvents.isEmpty()) return null else addTrackingLogs(*submitEvents)
        if (trackingDataTransporter.isSatisfyCountRequired)
            trackingDataTransporter.submitUploadTask()
        return result
    }

    /**
     * 埋点应用首次打开
     * @param paramsInfo 参数信息
     */
    fun trackingAppOpen(paramsInfo: AppOpenParamsInfo.() -> Unit) =
        trackEvent(eventType = EventType.AppOpen, paramsInfo = paramsInfo)

    /**
     * 埋点应用卸载
     * @param paramsInfo 参数信息
     */
    fun trackingAppUninstall(paramsInfo: AppUninstallParamsInfo.() -> Unit) =
        trackEvent(EventType.AppUninstall, AppUninstallParamsInfo().apply(paramsInfo))

    /**
     * 埋点应用更新
     * @param paramsInfo 参数信息
     */
    fun trackingAppUpgrade(paramsInfo: AppUpgradeParamsInfo.() -> Unit) =
        trackEvent(EventType.AppUpgrade, AppUpgradeParamsInfo().apply(paramsInfo))

    /**
     * 埋点应用使用时长
     * @param paramsInfo 参数信息
     */
    fun trackingAppUsageTimestamp(paramsInfo: AppUsageDurationParamsInfo.() -> Unit) =
        trackEvent(EventType.AppUsageTimestamp, AppUsageDurationParamsInfo().apply(paramsInfo))

    /**
     * 添加页面信息的埋点
     * @param paramsInfo 页面参数
     */
    fun trackScreenView(paramsInfo: ScreenViewParamsInfo.() -> Unit): Long? {
        if (!SharedPrefs.isTrackingPage) return null
        return trackEvent(EventType.ScreenView, ScreenViewParamsInfo().apply(paramsInfo))
    }

    /**
     * 埋点关键字搜索
     * @param paramsInfo 参数信息
     */
    fun trackingSearch(paramsInfo: SearchParamsInfo.() -> Unit) =
        trackEvent(EventType.Search, SearchParamsInfo().apply(paramsInfo))

    /**
     * 添加分享信息的埋点
     * @param paramsInfo 分享参数
     */
    fun trackShare(paramsInfo: ShareParamsInfo.() -> Unit): Long? {
        if (!SharedPrefs.isTrackingSocial) return null
        return trackEvent(EventType.Share, ShareParamsInfo().apply(paramsInfo))
    }

    /**
     * 添加页面停留时长的埋点
     * @param paramsInfo 异常参数
     */
    fun trackPageTiming(paramsInfo: PageTimingParamsInfo.() -> Unit) =
        trackEvent(EventType.PageTiming, PageTimingParamsInfo().apply(paramsInfo))

    /**
     * 添加异常信息的埋点
     * @param paramsInfo 异常参数
     */
    fun trackException(paramsInfo: ExceptionParamsInfo.() -> Unit): Long? {
        if (!SharedPrefs.isTrackingException) return null
        return trackEvent(EventType.Exception, ExceptionParamsInfo().apply(paramsInfo))
    }

    /**
     * 记录一条日志,与TrackingId关联
     * @param info 埋点数据
     */
    private fun <T : ParamsInfo> addTrackingLogs(vararg info: EventInfo<T>): List<Long>? {
        if (info.isEmpty()) return null
        return TrackingLogQuery.addTrackingLogs(*info)
    }

    /** 获取所有的埋点记录信息 **/
    val allTrackingLogs: List<TrackingLogInfo> get() = TrackingLogQuery.all

    /** 获取所有的埋点记录信息的数量 **/
    val allTrackingLogsCount: Int get() = TrackingLogQuery.allCount

    /** 删除所有的埋点日志记录 **/
    fun deleteAllTrackingLogs() = TrackingLogQuery.deleteAll()

    /**
     * 根据日志ID删除数据库中缓存的日志记录，不区分trackingId
     * @param infoList 日志记录集合
     */
    fun deleteTrackingLogs(infoList: List<TrackingLogInfo>) = TrackingLogQuery.delete(infoList)

    companion object {

        /** SDK版本号 **/
        const val SDK_VERSION = BuildConfig.SDK_VERSION

        /** SDK-API版本号 **/
        const val API_VERSION = BuildConfig.API_VERSION

        /**
         * 配置埋点数据,不为空的参数将被记录
         * @param dataTransportUrl 数据上报链接
         * @param value 应用方法，必传; 其中的dataReportUrl会被前面的传参覆盖
         */
        @JvmStatic
        fun config(dataTransportUrl: String, value: TrackingConfigInfo) {
            value.dataTransportUrl = dataTransportUrl
            config(dataTransportUrl = dataTransportUrl) {
                logPrint = value.logPrint
                trackingId = value.trackingId
                secretKey = value.secretKey
                deviceId = value.deviceId
                gaId = value.gaId
                ssId = value.ssId
                userId = value.userId
                channelName = value.channelName
                templateVersion = value.templateVersion
                this.dataTransportUrl = value.dataTransportUrl
            }
        }


        /**
         * 配置埋点数据,不为空的参数将被记录
         * @param dataTransportUrl 数据上报链接
         * @param value 应用方法，必传；其中的dataReportUrl会被前面的传参覆盖
         */
        @JvmStatic
        fun config(dataTransportUrl: String, value: TrackingConfigInfo.() -> Unit) {
            val configInfo =
                TrackingConfigInfo(dataTransportUrl = dataTransportUrl).apply(value)
            if (!configInfo.trackingId.isNullOrEmpty())
                SharedPrefs.trackingId = configInfo.trackingId
            if (!configInfo.secretKey.isNullOrEmpty())
                SharedPrefs.apiSecretKey = configInfo.secretKey
            if (!configInfo.deviceId.isNullOrEmpty())
                SharedPrefs.deviceId = configInfo.deviceId
            if (!configInfo.gaId.isNullOrEmpty())
                SharedPrefs.gaId = configInfo.gaId
            if (!configInfo.ssId.isNullOrEmpty())
                SharedPrefs.ssId = configInfo.ssId
            if (!configInfo.userId.isNullOrEmpty())
                SharedPrefs.userId = configInfo.userId
            if (!configInfo.channelName.isNullOrEmpty())
                SharedPrefs.channelName = configInfo.channelName
            if (!configInfo.templateVersion.isNullOrEmpty())
                SharedPrefs.templateVersion = configInfo.templateVersion
            if (dataTransportUrl.isNotEmpty())
                SharedPrefs.dataReportUrl = dataTransportUrl
            if (configInfo.logPrint != null)
                SharedPrefs.logPrintEnabled = configInfo.logPrint
            setLogPrintEnabled(SharedPrefs.logPrintEnabled ?: BuildConfig.DEBUG) //配置是否可以打印日志
            LogUtils.log4i(
                tag = "TrackingAnalyze",
                msg = "配置埋点参数：${Gson().toJson(configInfo)}"
            )
        }

        /**
         * 配置埋点开关，如果为NULL则不配置
         * @param isTrackingPage 是否收集ScreenView信息
         * @param isTrackingEvent 是否收集事件信息
         * @param isTrackingTiming 是否收集计时信息
         * @param isTrackingSocial 是否收集社交信息
         * @param isTrackingException 是否收集异常信息
         */
        @JvmStatic
        fun configSwitches(
            isTrackingPage: Boolean? = null,
            isTrackingEvent: Boolean? = null,
            isTrackingTiming: Boolean? = null,
            isTrackingSocial: Boolean? = null,
            isTrackingException: Boolean? = null
        ) {
            if (isTrackingPage != null)
                SharedPrefs.isTrackingPage = isTrackingPage
            if (isTrackingEvent != null)
                SharedPrefs.isTrackingEvent = isTrackingEvent
            if (isTrackingTiming != null)
                SharedPrefs.isTrackingTiming = isTrackingTiming
            if (isTrackingSocial != null)
                SharedPrefs.isTrackingSocial = isTrackingSocial
            if (isTrackingException != null)
                SharedPrefs.isTrackingException = isTrackingException
            LogUtils.log4i("TrackingAnalyze", "配置开关参数")
        }

        private val instance: Tracking? by lazy {
            if (SharedPrefs.trackingId.isNullOrEmpty()) {
                LogUtils.log4e(
                    "Tracking::instance",
                    "请调用[TrackingAnalyze.configTracking]先为TrackingId赋值"
                )
                return@lazy null
            }
            SharedPrefs.trackingId?.let { Tracking(it) }
        }

        /** 获取TrackingAnalyze的一个单例对象 **/
        @JvmStatic
        fun singleton(): Tracking? = instance

        /**
         * 设置API网络请求代理
         * @param proxy 代理设置信息
         */
        @JvmStatic
        fun setApiProxy(proxy: Proxy) {
            instance?.apiProxy = proxy
            LogUtils.log4i("Tracking::setApiProxy", "建议在配置完基础信息后调用！")
        }

        /**
         * 为网络请求设置interceptor
         * @param interceptors 网络请求的Interceptor集合
         */
        @JvmStatic
        fun setInterceptorForHttp(interceptors: List<Interceptor>) {
            interceptors.forEach { interceptor ->
                if (instance?.interceptors
                        ?.contains(interceptor) != true
                ) {
                    instance?.interceptors?.add(interceptor)
                }
            }
        }

        /**
         * 为网络请求设置interceptor
         * @param networkInterceptors 网络请求的Interceptor集合
         */
        @JvmStatic
        fun setNetworkInterceptorForHttp(networkInterceptors: List<Interceptor>) {
            networkInterceptors.forEach { interceptor ->
                if (instance?.networkInterceptors
                        ?.contains(interceptor) != true
                ) {
                    instance?.networkInterceptors?.add(interceptor)
                }
            }
        }

        /**
         * 从接口获取SSID
         * @param apiUrl 接口完整路径
         * @param queryParams 查询参数
         * @param postParams POST参数
         * @param callback 回调方法
         */
        @JvmStatic
        fun getSSID(
            apiUrl: String,
            queryParams: Map<String, Any?> = mapOf(),
            postParams: SSIDReqConfigInfo.() -> Unit = {},
            callback: (ApiCallback<String>) -> Unit
        ) = HttpApiRepo.getSSID(apiUrl, queryParams, postParams, callback)

        /** 启动全局异常抓取 **/
        @JvmStatic
        fun startGlobalCrashCatcher() =
            GlobalCrashHandler.singleton().start(ContextProvider.provideContext())

        /**
         * 启动发送本地崩溃日志
         * @param apiBaseURL 上报错误日志的BaseURL
         */
        fun reportCrashLogs(apiBaseURL: String) {
            GlobalCrashLogHandler.singleton.uploadCrashLogs(
                baseUrl = apiBaseURL,
                context = ContextProvider.provideContext(),
            )
        }

        /** 是否是上报错误埋点的URL **/
        fun isReportCrashApiUrl(url: String): Boolean =
            url.contains(GlobalCrashLogHandler.CRASH_REPORT_API_PATH)

        /** 设置当前Crash的页面名称 **/
        fun setCrashScreenName(name: String) =
            GlobalCrashHandler.singleton().setCurrentScreenName(name)

        /**
         * 启用埋点日志集中上传
         * @param perUploadMaxCount 每次上传的最大数据条数,默认：12
         * @param isDesc 是否使用倒序查询，默认：false
         */
        @JvmStatic
        fun startDataTransport(perUploadMaxCount: Int = 12, isDesc: Boolean = false) =
            TrackingDataTransporter.singleton()
                .start(perUploadMaxCount = perUploadMaxCount, isDesc = isDesc)

        /** 关闭埋点日志集中上传 **/
        @JvmStatic
        fun stopDataTransport() = TrackingDataTransporter.singleton().shutdown()

        /** 设置是否可以打印日志 **/
        @JvmStatic
        fun setLogPrintEnabled(value: Boolean) {
            LogUtils.logPrintEnabled = value
        }

    }

}