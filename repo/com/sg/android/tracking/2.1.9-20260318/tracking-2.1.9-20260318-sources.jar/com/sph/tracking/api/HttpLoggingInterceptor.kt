package com.sph.tracking.api

import com.sph.tracking.utils.log.LogUtils
import okhttp3.Interceptor
import okhttp3.OkHttpClient

/** Http日志Interceptor **/
internal object HttpLoggingInterceptor {


    /** 应用API网络日志Interceptor，需要项目引用Okhttp-Logging库 **/
    fun OkHttpClient.Builder.applyHttpLoggingInterceptor() {
        try {
            val clazz: Class<*>? =
                Class.forName("okhttp3.logging.HttpLoggingInterceptor")
            if (clazz == null) {
                LogUtils.log4i("tracking::HttpLoggingInterceptor", "项目未引入OkHttp日志库：HttpLoggingInterceptor")
                return
            }
            val loggingInterceptorInstance = clazz.getDeclaredConstructor().newInstance()
            val addInterceptorMethod =
                javaClass.getMethod("addInterceptor", Interceptor::class.java)
            addInterceptorMethod.invoke(this, loggingInterceptorInstance)
            val levelEnum =
                Class.forName("okhttp3.logging.HttpLoggingInterceptor\$Level")
            val bodyField = levelEnum.getDeclaredField("BODY")
            clazz.getMethod(
                "setLevel",
                Class.forName("okhttp3.logging.HttpLoggingInterceptor\$Level")
            ).invoke(loggingInterceptorInstance, bodyField[null])
        } catch (e: Exception) {
            LogUtils.log4e("HttpApiManager", "applyHttpLoggingInterceptor: ${e.message}")
        }
    }

}