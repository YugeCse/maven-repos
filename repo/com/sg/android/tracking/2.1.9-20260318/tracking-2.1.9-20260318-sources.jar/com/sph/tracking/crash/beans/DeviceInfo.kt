package com.sph.tracking.crash.beans

import com.google.gson.annotations.SerializedName

data class DeviceInfo(
    @field: SerializedName("deviceId")
    val deviceId: String = "",
    @field: SerializedName("mode")
    val mode: String = "",
    @field: SerializedName("resolution")
    val resolution: String = "",
    @field: SerializedName("orientation")
    val orientation: String = "",
    @field: SerializedName("osName")
    val osName: String = "",
    @field: SerializedName("osVersion")
    val osVersion: String = "",
)