package com.sph.tracking.provider

import android.annotation.SuppressLint
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import com.sph.tracking.utils.log.LogUtils

/** Context提供类 **/
internal class ContextProvider : ContentProvider() {

    companion object {

        @SuppressLint("StaticFieldLeak")
        private lateinit var mContext: Context

        @JvmStatic
        fun provideContext(): Context = mContext

    }

    override fun onCreate(): Boolean {
        if (context != null) {
            mContext = context!!
            LogUtils.log4i("ContextProvider", "提供了Context对象")
        } else {
            LogUtils.log4e("ContextProvider", "无法提供Context对象")
        }
        return true
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null

    override fun getType(uri: Uri): String? = null

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

}