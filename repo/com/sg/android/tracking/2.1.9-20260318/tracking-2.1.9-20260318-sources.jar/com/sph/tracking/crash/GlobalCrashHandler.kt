package com.sph.tracking.crash

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.google.gson.Gson
import com.sph.tracking.crash.beans.DeviceInfo
import com.sph.tracking.crash.beans.ErrorReportInfo
import com.sph.tracking.crash.beans.PlatformInfo
import com.sph.tracking.crash.beans.StateInfo
import com.sph.tracking.data.tracking.ParamsDefaults
import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.app.getOrientationDescription
import com.sph.tracking.utils.app.getScreenRealSizeText
import com.sph.tracking.utils.log.LogUtils
import kotlinx.coroutines.*
import java.io.*
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.*

/** 全局异常闪退抓取类 **/
internal class GlobalCrashHandler : Thread.UncaughtExceptionHandler {

    private lateinit var mContextRef: WeakReference<Context>

    private var mOriginalHandler: Thread.UncaughtExceptionHandler? = null

    /** 发生错误时的ScreenName数据 **/
    private var _crashScreenName: String = ""

    private var onGlobalCrashReceivedListener: OnGlobalCrashReceivedListener? = null

    /**
     * 设置当前的屏幕名称
     * @param name 屏幕名称
     */
    fun setCurrentScreenName(name: String) {
        _crashScreenName = name
    }

    /** 设置全局错误异常接收监听器 **/
    fun setOnGlobalCrashReceivedListener(listener: OnGlobalCrashReceivedListener) {
        this.onGlobalCrashReceivedListener = listener
    }

    /**
     * 初始化方法
     * @param context 上下文对象
     */
    fun start(context: Context) {
        mContextRef = WeakReference(context)
        mOriginalHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler(this)
    }

    override fun uncaughtException(thread: Thread, ex: Throwable) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ex.printStackTrace()
                saveCrash2File(_crashScreenName, ex)
                mOriginalHandler?.uncaughtException(thread, ex)
            } catch (e: Exception) {
                LogUtils.log4e(TAG, e)
            }
        }
        this.onGlobalCrashReceivedListener?.onGlobalCrashReceived(ex)
    }

    /**
     * 存储crash信息到文件
     * @param ex 异常信息
     */
    @Throws(IOException::class)
    private fun saveCrash2File(screenName: String, ex: Throwable) {
        val writer: Writer = StringWriter()
        val printWriter = PrintWriter(writer)
        ex.printStackTrace(printWriter)
        var cause = ex.cause // 返回此异常的原因（尝试加载类时发生错误引发的异常；否则返回 null）
        while (cause != null) {
            cause.printStackTrace(printWriter)
            cause = cause.cause
        }
        val result = writer.toString()
        printWriter.close()
        mContextRef.get()?.let { context ->
            val info = collectLog(
                screenName = screenName,
                stackTrace = result,
                log = "",
                eventType = "Crash"
            ) ?: return
            saveLogs2File(context, info)
        }
    }

     /**
      * 存储JS错误到文件
      * @param log 错误日志
      */
     fun saveJsError2File(screenName: String, log: String) {
         val saveError = fun() {
             try {
                 val context = mContextRef.get() ?: return
                 val errInfo = collectLog(
                     screenName = screenName,
                     stackTrace = "",
                     log = log,
                     eventType = "JSError"
                 ) ?: return
                 saveLogs2File(
                     info = errInfo,
                     context = context,
                 )
             } catch (e: Exception) {
                 LogUtils.log4e(TAG, e)
             }
         }
         CoroutineScope(Dispatchers.IO).launch { saveError() }
     }

    /**
     * 保存日志到文件
     * @param context 上下文对象
     * @param info 错误信息
     */
    private fun saveLogs2File(context: Context, info: ErrorReportInfo) {
        try {
            val formatter = SimpleDateFormat("MM.dd@HH.mm", Locale.CHINA)
            val dir = getDiskCrashDir(context)
            dir.mkdirs() //创建Crash目录
            val filePath = dir.absolutePath + File.separator + "${formatter.format(Date())}.log"
            val fos = FileOutputStream(filePath)
            fos.write(Gson().toJson(info).toByteArray())
            fos.close()
        } catch (e: Exception) {
            LogUtils.log4e(TAG, e)
        }
    }

    /** 收集日志 **/
    private fun collectLog(
        screenName: String,
        stackTrace: String,
        log: String,
        eventType: String
    ): ErrorReportInfo? {
        val context = mContextRef.get() ?: return null
        val resolution = context.getScreenRealSizeText()
        val orientation = context.getOrientationDescription()
        val device = DeviceInfo(
            mode = Build.MODEL,
            resolution = resolution,
            deviceId = SharedPrefs.deviceId ?: "",
            orientation = orientation,
            osName = "Android",
            osVersion = Build.VERSION.RELEASE
        )
        val platform = PlatformInfo(
            bundleId = context.packageName,
            platform = "Android",
            channel = "default",
            version = ParamsDefaults.appVersion ?: ""
        )
        val state = StateInfo(
            cpuUsage = getCpuInfo(),
            freeMem = getAvailableMemory(context)
        )
        return ErrorReportInfo(
            eventType = eventType,
            device = device,
            platform = platform,
            state = state,
            screen = screenName,
            stackTrace = stackTrace,
            log = log,
            logTime = System.currentTimeMillis()
        )
    }

    /** 获取可用的内存信息 **/
    private fun getAvailableMemory(context: Context): String {
        val mi: ActivityManager.MemoryInfo = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
            .getMemoryInfo(mi)
        return "${mi.availMem / (1024 * 1024)}M"
    }

    /** 获取CPU信息 **/
    private fun getCpuInfo(): String {
        var result = "N/A"
        try {
            val fr = FileReader("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
            val br = BufferedReader(fr)
            result = br.readLine().trim()
            br.close()
        } catch (e: Exception) {
            LogUtils.log4e(TAG, e)
        }
        return result
    }

    companion object {

        private const val TAG = "CrashHandler"

        private const val FILE_NAME = "crash"

        private val instance by lazy { GlobalCrashHandler() }

        @JvmStatic
        fun singleton() = instance

        @JvmStatic
        fun getDiskCrashDir(context: Context): File {
            val cachePath = when {
                context.externalCacheDir != null ->
                    context.externalCacheDir?.path
                context.cacheDir != null -> context.cacheDir?.path
                else -> context.filesDir?.path
            }
            return File(cachePath + File.separator + FILE_NAME)
        }
    }
}