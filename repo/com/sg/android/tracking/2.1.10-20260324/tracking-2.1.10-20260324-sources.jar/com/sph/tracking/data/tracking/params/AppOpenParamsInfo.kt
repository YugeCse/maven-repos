package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 打开应用参数设置
 * @since 2024.07.18 15:30
 **/
open class AppOpenParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 打开应用时间戳 **/
        const val KEY_FIRST_OPEN_TIME = "first_open_version"

        /** KEY - 是否第一次打开 **/
        const val KEY_FIRST_OPEN = "first_open"

        /** KEY - 是否热/冷启动 **/
        const val KEY_IS_RELAUNCH = "relaunch"

    }

    /** 获取或设置应用打开时的时间戳【上传名称为：first_open_version】 **/
    open var firstOpenTime: Long?
        set(value) = set(KEY_FIRST_OPEN_TIME, value)
        get() {
            val result = get(KEY_FIRST_OPEN_TIME)
            return if (result is Long) result
            else result?.toString()?.toLongOrNull()
        }

    /**  获取或设置是否是第一次打开【上传名称为：first_open】 **/
    open var firstOpen: Boolean?
        set(value) = set(KEY_FIRST_OPEN, value)
        get() {
            val result = get(KEY_FIRST_OPEN)
            return if (result is Boolean) result
            else result?.toString()?.toBooleanStrictOrNull()
        }

    /** 获取或设置是否是热/冷启动【上传名称为：relaunch】 **/
    open var isRelaunch: Boolean?
        set(value) = set(KEY_IS_RELAUNCH, value)
        get() {
            val result = get(KEY_IS_RELAUNCH)
            return if (result is Boolean) result
            else result?.toString()?.toBooleanStrictOrNull()
        }

}