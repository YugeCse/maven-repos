package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 异常上报参数
 * @since 2024.07.18 15:30
 **/
open class ExceptionParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 是否严重 **/
        const val KEY_EX_FATAL = "ex_fatal"

        /** KEY - 报错时间 **/
        const val KEY_EX_TIMESTAMP = "ex_timestamp"

        /** KEY - 错误信息 **/
        const val KEY_EX_DESCRIPTION = "ex_description"

    }

    /** 是否严重 【上传字段名：ex_fatal】**/
    open var exFatal: Boolean?
        set(value) = set(KEY_EX_FATAL, value)
        get() {
            val result = get(KEY_EX_FATAL)
            return if (result is Boolean) result
            else result?.toString()?.toBooleanStrictOrNull()
        }

    /** 报错时间 【上传字段名：ex_timestamp】**/
    open var exTimestamp: Long?
        set(value) = set(KEY_EX_TIMESTAMP, value)
        get() {
            val result = get(KEY_EX_TIMESTAMP)
            return if (result is Long) result
            else result?.toString()?.toLongOrNull()
        }

    /** 错误信息 【上传字段名：ex_description】**/
    open var exDescription: String?
        set(value) = set(KEY_EX_DESCRIPTION, value)
        get() = get(KEY_EX_DESCRIPTION)?.toString()

}
