package com.sph.tracking.data.db

import android.annotation.SuppressLint
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.sph.tracking.data.db.table.TrackingLogInfo
import com.sph.tracking.provider.ContextProvider
import com.sph.tracking.utils.log.LogUtils

/**
 * SQLite辅助类
 * @param context 上下文对象
 */
internal class SQLiteHelper private constructor(
    private val context: Context
) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {

        val TAG: String = SQLiteHelper::class.java.simpleName

        /** 数据库版本 **/
        const val DB_VERSION = 1

        /** 数据库名称 **/
        const val DB_NAME = "tracking_records"

        /** SQLiteHelper实例 **/
        @SuppressLint("StaticFieldLeak")
        private var instance: SQLiteHelper? = null

        /** 获取单例对象 **/
        @JvmStatic
        fun singleton(): SQLiteHelper? {
            if (instance == null) {
                synchronized(SQLiteHelper::class.java) {
                    if (instance == null) {
                        ContextProvider.provideContext()
                            ?.let { instance = SQLiteHelper(it) }
                        LogUtils.log4i(TAG, "创建数据库实例：SQLiteHelper")
                    }
                }
            }
            return instance
        }

    }

    override fun onCreate(db: SQLiteDatabase?) {
        runCatching {
            val sqlString = TrackingLogInfo.createTable(db)
            LogUtils.log4i(TAG, "创建数据表: \n%s", sqlString)
        }.onFailure { e ->
            LogUtils.log4e(TAG, "创建数据表失败：%s", e)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        LogUtils.log4i(TAG, "数据表升级：%d => %d", oldVersion, newVersion)
    }

}