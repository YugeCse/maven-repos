package com.sph.tracking.crash.beans

import com.google.gson.annotations.SerializedName

/**
 * 错误上报信息实体类
 * @param id 错误ID
 * @param screen 屏幕名称
 * @param eventType 错误类型
 * @param stackTrace 错误堆栈信息
 * @param log 错误日志
 * @param logTime 错误日志时间
 * @param gaId Google Analytics ID
 * @param device 设备信息
 * @param platform 平台信息
 * @param state 状态信息
 */
data class ErrorReportInfo(
    @field: SerializedName("id")
    val id: String = "",
    @field: SerializedName("screen")
    val screen: String = "",
    @field: SerializedName("eventType")
    val eventType: String = "Crash",
    @field: SerializedName("stackTrace")
    val stackTrace: String = "",
    @field: SerializedName("log")
    val log: String = "",
    @field: SerializedName("logTime")
    val logTime: Long,
    @field: SerializedName("gaId")
    val gaId: String = "",
    @field: SerializedName("device")
    val device: DeviceInfo = DeviceInfo(),
    @field: SerializedName("platform")
    val platform: PlatformInfo = PlatformInfo(),
    @field: SerializedName("state")
    val state: StateInfo = StateInfo()
)