package com.sph.tracking.crash

/** 全局异常接收监听类 **/
fun interface OnGlobalCrashReceivedListener {

    /**
     * 响应监听到的错误异常
     * @param throwable 抛出的异常信息
     */
    fun onGlobalCrashReceived(throwable: Throwable?)

}