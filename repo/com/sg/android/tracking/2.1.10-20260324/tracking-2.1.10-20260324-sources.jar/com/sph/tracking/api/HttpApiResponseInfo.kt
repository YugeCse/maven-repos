package com.sph.tracking.api

import com.google.gson.annotations.SerializedName

/**
 * 网络API返回接口框架定义
 * @param code 结果码
 * @param message 结果信息
 * @param data 数据实体
 */
data class HttpApiResponseInfo<T>(
    @field: SerializedName("code")
    var code: String? = null,
    @field: SerializedName("message")
    var message: String? = null,
    @field: SerializedName("data")
    var data: T? = null
)

/** 通过Code判断请求是否成功，200～299判断为成功 **/
val HttpApiResponseInfo<*>.isSuccessful
    get() = code?.matches("^\\d+$".toRegex()) == true && code!!.toInt() in 200..299
