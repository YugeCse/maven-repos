//package com.sph.tracking.crash
//
//import android.content.Context
//import com.sph.tracking.tracker.Tracking
//import com.sph.tracking.utils.log.LogUtils
//import java.io.PrintWriter
//import java.io.StringWriter
//import java.io.Writer
//import java.lang.ref.WeakReference
//import java.util.Date
//
///** 全局异常闪退抓取类 **/
//internal class GlobalCrashCatcher : Thread.UncaughtExceptionHandler {
//
//    companion object {
//
//        private const val TAG = "CrashHandler"
//
//        private val instance by lazy { GlobalCrashCatcher() }
//
//        @JvmStatic
//        fun singleton() = instance
//
//    }
//
//    private lateinit var mContextRef: WeakReference<Context>
//
//    private var mOriginalHandler: Thread.UncaughtExceptionHandler? = null
//
//    /**
//     * 初始化方法
//     * @param context 上下文对象
//     */
//    fun start(context: Context) {
//        mContextRef = WeakReference(context)
//        mOriginalHandler = Thread.getDefaultUncaughtExceptionHandler()
//        Thread.setDefaultUncaughtExceptionHandler(this)
//    }
//
//    override fun uncaughtException(thread: Thread, ex: Throwable) {
//        try {
//            saveCrashToLocal(ex)
//            ex.printStackTrace()
//            mOriginalHandler?.uncaughtException(thread, ex)
//        } catch (e: Exception) {
//            LogUtils.log4e(TAG, e)
//        }
//    }
//
//    /**
//     * 存储crash信息到本地数据库
//     * @param ex 异常信息
//     */
//    private fun saveCrashToLocal(ex: Throwable) {
//        val writer: Writer = StringWriter()
//        val printWriter = PrintWriter(writer)
//        ex.printStackTrace(printWriter)
//        var cause = ex.cause // 返回此异常的原因（尝试加载类时发生错误引发的异常；否则返回 null）
//        while (cause != null) {
//            cause.printStackTrace(printWriter)
//            cause = cause.cause
//        }
//        val result = writer.toString()
//        printWriter.close()
//        Tracking.singleton().trackException {
//            exFatal = true
//            exDescription = result
//            exTimestamp = Date().time
//        }
//    }
//
////    /** 获取CPU信息 **/
////    private fun getCpuInfo(): String {
////        var result = "N/A"
////        try {
////            val fr = FileReader("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
////            val br = BufferedReader(fr)
////            result = br.readLine().trim()
////            br.close()
////        } catch (e: Exception) {
////            LogUtils.log4e(TAG, e)
////        }
////        return result
////    }
////
////    /** 获取可用的内存信息 **/
////    private fun getAvailableMemory(context: Context): String {
////        val mi: ActivityManager.MemoryInfo = ActivityManager.MemoryInfo()
////        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
////            .getMemoryInfo(mi)
////        return "${mi.availMem / (1024 * 1024)}M"
////    }
//
//}