package com.sph.tracking.utils.app

import android.annotation.SuppressLint
import android.os.Build
import com.sph.tracking.utils.log.LogUtils


/** 系统辅助类 **/
internal object SystemUtils {

    /** 获取设备的OS名称 **/
    @JvmStatic
    fun getOsName(): String = if (isHarmonyOs()) "Harmony" else "Android"

    /** 获取设备的OS版本 **/
    @JvmStatic
    fun getOsVersion(): String = if (isHarmonyOs()) getHarmonyVersion() else Build.VERSION.RELEASE

    /**
     * 获取是否为鸿蒙系统
     * @return true为鸿蒙系统
     */
    @JvmStatic
    fun isHarmonyOs(): Boolean = try {
        val buildExClass: Class<*>? = Class.forName("com.huawei.system.BuildEx")
        val osBrand = buildExClass?.getMethod("getOsBrand")?.invoke(null)
        "Harmony".equals(osBrand?.toString() ?: "", ignoreCase = true)
    } catch (x: Throwable) {
        LogUtils.log4e("SystemUtils", "isHarmonyOs(false): ${x.toString()}")
        false
    }

    /**
     * 获取鸿蒙系统版本号
     * @return 版本号
     */
    @SuppressLint("PrivateApi")
    fun getHarmonyVersion(): String {
        try {
            val spClz = Class.forName("android.os.SystemProperties")
            val method = spClz.getDeclaredMethod("get", String::class.java)
            val value = method.invoke(spClz, "hw_sc.build.platform.version") as? String
            return if (value.isNullOrEmpty()) "" else value
        } catch (e: Throwable) {
            LogUtils.log4e("SystemUtils", "getHarmonyVersion[ex]: ${e.toString()}")
        }
        return ""
    }

    /**
     * 获得鸿蒙系统版本号（含小版本号，实际上同Android的android.os.Build.DISPLAY）
     * @return 版本号
     */
    @JvmStatic
    fun getHarmonyDisplayVersion(): String = Build.DISPLAY

}