package com.sph.tracking.data.db.table

import android.database.sqlite.SQLiteDatabase
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import java.util.Date

/**
 * 埋点日志信息
 * @param id 数据ID
 * @param logContent 日志内容，这里装载的是Event的JSON对象
 * @param createTime 创建事件
 * @param updateTime 更新事件
 */
data class TrackingLogInfo(
    @field: SerializedName(COLUMN_ID)
    var id: Long = 0L,
    @field: SerializedName(COLUMN_LOG_CONTENT)
    var logContent: String = "",
    @field: SerializedName(COLUMN_CREATE_TIME)
    var createTime: Long = Date().time,
    @field: SerializedName(COLUMN_UPDATE_TIME)
    var updateTime: Long = createTime
) {

    override fun toString(): String = Gson().toJson(this)

    companion object {

        /** 表名：tb_tracking_info **/
        const val TB_NAME = "tb_tracking_info"

        /** 字段：id-INTEGER **/
        const val COLUMN_ID = "id"

        /** 字段：log_content-TEXT **/
        const val COLUMN_LOG_CONTENT = "log_content"

        /** 字段：create_time-INTEGER **/
        const val COLUMN_CREATE_TIME = "create_time"

        /** 字段：update_time-INTEGER **/
        const val COLUMN_UPDATE_TIME = "update_time"

        /**
         * 创建数据库表
         * @param db 数据库DB对象
         * @return 返回数据库建表语句
         */
        @JvmStatic
        fun createTable(db: SQLiteDatabase?): String {
            val sqlString = "CREATE TABLE IF NOT EXISTS $TB_NAME(" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_LOG_CONTENT TEXT," +
                "$COLUMN_CREATE_TIME INTEGER DEFAULT 0," +
                "$COLUMN_UPDATE_TIME INTEGER DEFAULT 0" +
                ");"
            return sqlString.apply { db?.execSQL(sqlString) }
        }

    }

}