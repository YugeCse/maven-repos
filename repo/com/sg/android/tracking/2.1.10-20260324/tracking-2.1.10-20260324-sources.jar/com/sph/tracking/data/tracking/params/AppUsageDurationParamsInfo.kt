package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 应用使用时长参数信息
 * @since 2024.07.18 15:30
 **/
open class AppUsageDurationParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 应用使用时长时间戳 单位毫秒 **/
        const val KEY_APP_USAGE_TIMESTAMP = "app_usage_timestamp"

    }

    /** 应用使用时长时间戳 单位毫秒 【上传名称为：app_usage_timestamp】 **/
    open var appUsageTimestamp: Long?
        set(value) = set(KEY_APP_USAGE_TIMESTAMP, value)
        get() {
            val result = get(KEY_APP_USAGE_TIMESTAMP)
            return if (result is Long) result
            else result?.toString()?.toLongOrNull()
        }

}
