package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 分享参数信息
 * @since 2024.07.18 15:30
 */
open class ShareParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 分享方式 */
        const val KEY_SHARE_METHOD = "share_method"

        /** KEY - 分享类型 */
        const val KEY_SHARE_CONTENT_TYPE = "share_content_type"

        /** KEY - 分享内容 */
        const val KEY_SHARE_CONTENT = "share_content"

        /** KEY - 分享数据ID */
        const val KEY_SHARE_ITEM_ID = "share_item_id"

    }

    override fun getDataBundle(): Map<String, Any?> {
        val map = super.getDataBundle().toMutableMap()
        map[KEY_SHARE_METHOD] = shareMethod
        return map
    }

    /** 分享方式【上传名称为：share_method】, wechat, qq, system；默认：使用系统分享 */
    open var shareMethod: String?
        set(value) = set(KEY_SHARE_METHOD, value)
        get() = get(KEY_SHARE_METHOD)?.toString() ?: "system"

    /** 分享类型【上传名称为：share_content_type】，image, text, image_text，url */
    open var shareContentType: String?
        set(value) = set(KEY_SHARE_CONTENT_TYPE, value)
        get() = get(KEY_SHARE_CONTENT_TYPE)?.toString()

    /** 分享内容【上传名称为：share_item_id】，link, text and so on. */
    open var shareContent: String?
        set(value) = set(KEY_SHARE_CONTENT, value)
        get() = get(KEY_SHARE_CONTENT)?.toString()

    /** 分享数据ID. */
    open var shareItemId: String?
        set(value) = set(KEY_SHARE_ITEM_ID, value)
        get() = get(KEY_SHARE_ITEM_ID)?.toString()

}
