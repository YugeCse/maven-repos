package com.sph.tracking.data.tracking

import com.google.gson.GsonBuilder
import com.google.gson.annotations.SerializedName
import java.util.Date

/**
 * 上报事件实体类
 * @param name 事件名称，查看[EventType]或自定义事件名称
 * @param localTimeMs 事件记录时的时间，默认：当前时间戳
 * @param params 事件参数，包含基础信息、应用信息、事件信息、异常信息、社交信息等
 */
data class EventInfo<T : ParamsInfo>(
    @field:SerializedName("name")
    var name: String? = null,
    @field: SerializedName("local_time_ms")
    var localTimeMs: Long? = Date().time,
    @field: SerializedName("params")
    var params: T? = null
) {

    override fun toString(): String {
        return GsonBuilder()
            .disableHtmlEscaping()
            .create()
            .toJson(
                mapOf(
                    "name" to name,
                    "local_time_ms" to localTimeMs,
                    "params" to params?.getDataBundle(),
                )
            )
    }

}