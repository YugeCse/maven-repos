package com.sph.tracking.crash

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.google.gson.Gson
import com.sph.tracking.crash.beans.DeviceInfo
import com.sph.tracking.crash.beans.ErrorReportInfo
import com.sph.tracking.crash.beans.PlatformInfo
import com.sph.tracking.crash.beans.StateInfo
import com.sph.tracking.data.tracking.ParamsDefaults
import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.app.getOrientationDescription
import com.sph.tracking.utils.app.getScreenRealSizeText
import com.sph.tracking.utils.log.LogUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.FileReader
import java.io.IOException
import java.io.PrintWriter
import java.io.StringWriter
import java.io.Writer
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 全局异常闪退抓取类 **/
internal class GlobalCrashHandler : Thread.UncaughtExceptionHandler {

    companion object {

        /** 日志字符串 **/
        private const val TAG = "CrashHandler"

        /** 文件名称 **/
        private const val FILE_NAME = "crash"

        /** 获取实例 **/
        private val instance by lazy { GlobalCrashHandler() }

        /** 获取单例对象 **/
        @JvmStatic
        fun singleton() = instance

        /**
         * 获取Crash存储的磁盘目录
         * @param context 上下文对象
         */
        @JvmStatic
        fun getDiskCrashDir(context: Context): File {
            val cachePath = when {
                context.externalCacheDir != null ->
                    context.externalCacheDir?.path

                context.cacheDir != null -> context.cacheDir?.path
                else -> context.filesDir?.path
            }
            return File(cachePath + File.separator + FILE_NAME)
        }
    }

    /** context弱应用对象 **/
    private var mContextRef: WeakReference<Context>? = null

    /** 原始异常处理对象 **/
    private var mOriginalHandler: Thread.UncaughtExceptionHandler? = null

    /** 发生错误时的ScreenName数据 **/
    private var _crashScreenName: String = ""

    /** 全局异常接收监听 **/
    private var onGlobalCrashReceivedListener: OnGlobalCrashReceivedListener? = null

    /**
     * 设置当前的屏幕名称
     * @param name 屏幕名称
     */
    fun setCurrentScreenName(name: String) {
        _crashScreenName = name
    }

    /**
     * 设置全局错误异常接收监听器
     * @param listener 监听器
     */
    fun setOnGlobalCrashReceivedListener(listener: OnGlobalCrashReceivedListener) {
        this.onGlobalCrashReceivedListener = listener
    }

    /**
     * 初始化方法
     * @param context 上下文对象
     */
    fun start(context: Context) {
        mContextRef = WeakReference(context)
        mOriginalHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler(this)
    }

    override fun uncaughtException(thread: Thread, ex: Throwable) {
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                ex.printStackTrace()
                saveCrash2File(_crashScreenName, ex)
                mOriginalHandler?.uncaughtException(thread, ex)
            }.onFailure { e -> LogUtils.log4e(TAG, "uncaughtException: ${e.toString()}") }
        }
        this.onGlobalCrashReceivedListener?.onGlobalCrashReceived(ex)
    }

    /**
     * 存储crash信息到文件
     * @param screenName 屏幕名称，页面名称
     * @param ex 异常信息
     */
    @Throws(IOException::class)
    private fun saveCrash2File(screenName: String, ex: Throwable) {
        val writer: Writer = StringWriter()
        val printWriter = PrintWriter(writer)
        ex.printStackTrace(printWriter)
        var cause = ex.cause // 返回此异常的原因（尝试加载类时发生错误引发的异常；否则返回 null）
        while (cause != null) {
            cause.printStackTrace(printWriter)
            cause = cause.cause
        }
        val result = writer.toString()
        printWriter.close()
        mContextRef?.get()?.let { context ->
            val info = collectLog(
                screenName = screenName,
                stackTrace = result,
                log = "",
                eventType = "Crash"
            ) ?: return
            saveLogs2File(context, info)
        } ?: LogUtils.log4e(TAG, "saveCrash2File: mContextRef is null")
    }

    /**
     * 存储JS错误到文件
     * @param screenName 屏幕名称，页面名称
     * @param log 错误日志
     */
    fun saveJsError2File(screenName: String, log: String) {
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val context = mContextRef?.get()
                    ?: return@runCatching
                val errInfo = collectLog(
                    screenName = screenName,
                    stackTrace = "",
                    log = log,
                    eventType = "JSError"
                ) ?: return@runCatching
                saveLogs2File(context = context, info = errInfo)
            }.onFailure { e -> LogUtils.log4e(TAG, "saveJsError2File: ${e.toString()}") }
        }
    }

    /**
     * 保存日志到文件
     * @param context 上下文对象
     * @param info 错误信息
     */
    private fun saveLogs2File(context: Context, info: ErrorReportInfo) {
        runCatching {
            val formatter = SimpleDateFormat("MM.dd@HH.mm", Locale.CHINA)
            val dir = getDiskCrashDir(context)
            dir.mkdirs() //创建Crash目录
            val filePath = "${dir.absolutePath}${File.separator}${formatter.format(Date())}.log"
            val fos = FileOutputStream(filePath)
            fos.write(Gson().toJson(info).toByteArray())
            fos.close()
        }.onFailure { e -> LogUtils.log4e(TAG, Throwable("saveLogs2File: ${e.toString()}")) }
    }

    /**
     * 收集日志
     * @param screenName 屏幕名称
     * @param stackTrace 堆栈信息
     * @param log 日志信息
     */
    private fun collectLog(
        screenName: String,
        stackTrace: String,
        log: String,
        eventType: String
    ): ErrorReportInfo? {
        val context = mContextRef?.get() ?: return null
        val resolution = context.getScreenRealSizeText()
        val orientation = context.getOrientationDescription()
        val device = DeviceInfo(
            mode = Build.MODEL,
            resolution = resolution,
            deviceId = SharedPrefs.deviceId ?: "",
            orientation = orientation,
            osName = "Android",
            osVersion = Build.VERSION.RELEASE
        )
        val platform = PlatformInfo(
            bundleId = context.packageName,
            platform = "Android",
            channel = "default",
            version = ParamsDefaults.appVersion ?: ""
        )
        val state = StateInfo(
            cpuUsage = getCpuInfo(),
            freeMem = getAvailableMemory(context)
        )
        return ErrorReportInfo(
            eventType = eventType,
            device = device,
            platform = platform,
            state = state,
            screen = screenName,
            stackTrace = stackTrace,
            log = log,
            logTime = System.currentTimeMillis()
        )
    }

    /**
     * 获取可用的内存信息
     * @param context 上下文对象
     */
    private fun getAvailableMemory(context: Context): String {
        val mi: ActivityManager.MemoryInfo = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
            .getMemoryInfo(mi)
        return "${mi.availMem / (1024 * 1024)}M"
    }

    /** 获取CPU信息 **/
    private fun getCpuInfo(): String {
        var result = "N/A"
        runCatching {
            val fr = FileReader("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
            val br = BufferedReader(fr)
            result = br.readLine().trim()
            br.close()
        }.onFailure { e -> LogUtils.log4e(TAG, e) }
        return result
    }
}