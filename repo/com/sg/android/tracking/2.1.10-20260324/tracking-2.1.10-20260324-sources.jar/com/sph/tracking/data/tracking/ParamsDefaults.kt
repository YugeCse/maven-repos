package com.sph.tracking.data.tracking

import android.content.res.Configuration
import android.os.Build
import com.sph.tracking.provider.ContextProvider
import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.app.SystemUtils
import com.sph.tracking.utils.app.getAppName
import com.sph.tracking.utils.app.getScreenRealSizeText
import com.sph.tracking.utils.app.getVersionName

/** 埋点参数默认值，用于给IParamsInfo中的字段赋值 **/
object ParamsDefaults {

    /** 获取GA_ID **/
    val gaId: String? get() = SharedPrefs.gaId

    /** 获取SSId **/
    val ssId: String? get() = SharedPrefs.ssId

    /** 应用渠道名称 **/
    val appChannelName: String? get() = SharedPrefs.channelName

    /** 获取OsName **/
    val osName: String get() = SystemUtils.getOsName()

    /** 获取OsVersion **/
    val osVersion: String get() = SystemUtils.getOsVersion()

    /** 获取品牌型号 **/
    val deviceModel: String get() = "${Build.BRAND} ${Build.MODEL}"

    /** 获取设备分辨率 **/
    val resolution: String? get() = ContextProvider.provideContext()?.getScreenRealSizeText()

    /** 获取应用名称 **/
    val appName: String? get() = ContextProvider.provideContext()?.getAppName()

    /** 获取应用包名 **/
    val packageName: String? get() = ContextProvider.provideContext()?.packageName

    /** 获取应用版本名称 **/
    val appVersion: String? get() = ContextProvider.provideContext()?.getVersionName()

    /** 获取应用模板版本 **/
    val templateVersion: String? get() = SharedPrefs.templateVersion

    /** 是否是平板的判断 **/
    private var _isTablet: Boolean? = null

    /** 设备类型, 返回：Tablet or Mobile **/
    val deviceType: String
        get() {
            if (_isTablet == null) {
                val context = ContextProvider.provideContext()
                    ?: return "Mobile"
                _isTablet = (((context.resources.configuration.screenLayout
                        and Configuration.SCREENLAYOUT_SIZE_MASK)
                        >= Configuration.SCREENLAYOUT_SIZE_LARGE))
            }
            return if (_isTablet == true) "Tablet" else "Mobile"
        }

    /** 设备品牌 **/
    val deviceBrand: String get() = Build.BRAND

    /** 设备制造商 **/
    val deviceFamily: String get() = Build.MANUFACTURER

}