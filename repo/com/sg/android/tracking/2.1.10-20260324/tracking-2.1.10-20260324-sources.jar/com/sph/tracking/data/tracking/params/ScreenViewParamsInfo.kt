package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 屏幕信息参数
 * @since 2024.07.18 15:30
 */
open class ScreenViewParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 页面名称 **/
        const val KEY_PAGE_NAME = "page_name"

        /** KEY - 页面关系类名，文章ID等 **/
        const val KEY_PAGE_CLASS_NAME = "screen_id"

    }

    /** 页面名称 【上传参数名为：page_name】 **/
    open var pageName: String?
        set(value) = set(KEY_PAGE_NAME, value)
        get() = get(KEY_PAGE_NAME)?.toString()

    /** 页面关系类名，文章ID等 【上传参数名为：screen_id】 **/
    open var pageClassName: String?
        set(value) = set(KEY_PAGE_CLASS_NAME, value)
        get() = get(KEY_PAGE_CLASS_NAME)?.toString()

}
