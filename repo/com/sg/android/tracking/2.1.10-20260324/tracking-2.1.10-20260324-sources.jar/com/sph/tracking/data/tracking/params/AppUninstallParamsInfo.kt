package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 应用卸载参数信息
 * @since 2024.07.18 15:30
 **/
open class AppUninstallParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 应用卸载时的时间戳 **/
        const val KEY_APP_UNINSTALL_TIMESTAMP = "app_remove_timestamp"

    }

    /** 获取或设置应用卸载时的时间戳【上传名称为：app_remove_timestamp】**/
    open var appUninstallTimestamp: Long?
        set(value) = set(KEY_APP_UNINSTALL_TIMESTAMP, value)
        get() {
            val result = get(KEY_APP_UNINSTALL_TIMESTAMP)
            return if (result is Long) result
            else result?.toString()?.toLongOrNull()
        }

}
