package com.sph.tracking.data.db.query

import android.content.ContentValues
import com.google.gson.Gson
import com.sph.tracking.data.db.SQLiteHelper
import com.sph.tracking.data.db.table.TrackingLogInfo
import com.sph.tracking.data.tracking.EventInfo
import com.sph.tracking.data.tracking.ParamsInfo
import com.sph.tracking.utils.log.LogUtils
import java.util.Date

/** 埋点日期查询类 **/
internal object TrackingLogQuery {

    /** 获取数据库对象 **/
    private val database by lazy {
        SQLiteHelper.singleton()?.writableDatabase
    }

    /**
     * 添加埋点日志
     * @param log 日志对象
     * @return 新增后的日志ID，如果执行失败，返回-1
     */
    @JvmStatic
    fun addTrackingLogs(log: TrackingLogInfo): Long {
        val currentTimeMillis = when {
            log.createTime == 0L || log.createTime <= 0L ->
                Date().time

            else -> log.createTime
        }
        return database?.insert(
            TrackingLogInfo.TB_NAME,
            null,
            ContentValues().apply {
                put(TrackingLogInfo.COLUMN_LOG_CONTENT, log.logContent)
                put(TrackingLogInfo.COLUMN_CREATE_TIME, currentTimeMillis)
                put(TrackingLogInfo.COLUMN_UPDATE_TIME, currentTimeMillis)
            }
        )?.apply here@{
            if (LogUtils.logPrintEnabled) {
                val logText = Gson().toJson(log.apply {
                    id = this@here
                    createTime = currentTimeMillis
                    updateTime = currentTimeMillis
                })
                LogUtils.log4i(tag = "TrackingLogQuery", msg = "添加埋点日志：\n$logText")
            }
        } ?: -1
    }

    /**
     * 添加埋点日志
     * @param logContent 日志内容
     */
    @JvmStatic
    fun addTrackingLogs(vararg logContent: String = arrayOf("")): List<Long> {
        return logContent.map { log ->
            addTrackingLogs(TrackingLogInfo(logContent = log))
        }.toList()
    }

    /**
     * 添加埋点日志
     * @param logs 日志内容对象
     */
    @JvmStatic
    fun <T : ParamsInfo> addTrackingLogs(vararg logs: EventInfo<T>): List<Long> =
        addTrackingLogs(*logs.map { it.toString() }.toTypedArray())

    /**  获取所有的埋点日志数据 **/
    val all: List<TrackingLogInfo>
        get() {
            val logs = mutableListOf<TrackingLogInfo>()
            val querySQLText = "SELECT * FROM ${TrackingLogInfo.TB_NAME}"
            val cursor = database?.rawQuery(querySQLText, null)
            if (cursor?.moveToFirst() == true) {
                do {
                    val idIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_ID)
                    val logContentIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_LOG_CONTENT)
                    val createTimeIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_CREATE_TIME)
                    val updateTimeIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_UPDATE_TIME)
                    logs.add(
                        TrackingLogInfo(
                            id = cursor.getLong(idIndex),
                            logContent = cursor.getString(logContentIndex),
                            createTime = cursor.getLong(createTimeIndex),
                            updateTime = cursor.getLong(updateTimeIndex)
                        )
                    )
                } while (cursor.moveToNext())
            }
            cursor?.close()
            return logs
        }

    /**
     * 查询埋点日志数据
     * @param limitCount 限制每次查询的长度，默认为12
     * @param isDesc 是否使用倒序方式查询，默认：false
     * @param excludeIds 不包含的数据ID集合，默认：空集合
     */
    fun queryTrackingLogs(
        limitCount: Int = 12,
        isDesc: Boolean = false,
        excludeIds: List<Long> = emptyList()
    ): List<TrackingLogInfo> {
        val logs = mutableListOf<TrackingLogInfo>()
        val notInQueryText = when {
            excludeIds.isEmpty() -> ""
            else -> " WHERE ${TrackingLogInfo.COLUMN_ID} NOT IN (${excludeIds.joinToString(",")})"
        }
        val querySQLText = "SELECT * FROM ${TrackingLogInfo.TB_NAME} $notInQueryText" +
                "ORDER BY ${TrackingLogInfo.COLUMN_CREATE_TIME} ${if (isDesc) "DESC" else "ASC"} " +
                "LIMIT $limitCount OFFSET 0"
        val cursor = database?.rawQuery(querySQLText, null)
        if (cursor?.moveToFirst() == true) {
            do {
                val idIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_ID)
                val logContentIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_LOG_CONTENT)
                val createTimeIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_CREATE_TIME)
                val updateTimeIndex = cursor.getColumnIndex(TrackingLogInfo.COLUMN_UPDATE_TIME)
                logs.add(
                    TrackingLogInfo(
                        id = cursor.getLong(idIndex),
                        logContent = cursor.getString(logContentIndex),
                        createTime = cursor.getLong(createTimeIndex),
                        updateTime = cursor.getLong(updateTimeIndex)
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor?.close()
        return logs
    }

    /**  获取所有的埋点日志数据总数 **/
    val allCount: Int
        get() {
            var count = 0
            val querySQLText = "SELECT COUNT(*) FROM ${TrackingLogInfo.TB_NAME}"
            val cursor = database?.rawQuery(querySQLText, null)
            if (cursor?.moveToFirst() == true)
                count = cursor.getInt(0)
            cursor?.close()
            return count
        }

    /**
     * 根据日志ID删除数据集合
     * @param logs 日志数据集合
     * @return 受影响的行数
     */
    @JvmStatic
    fun delete(logs: Collection<TrackingLogInfo>): Int {
        val ids = logs.map { it.id }.toList()
        if (ids.isEmpty()) return 0
        return deleteByIds(ids)
    }

    /**
     * 根据日志ID删除数据
     * @param ids 日志ID数据集合
     * @return 受影响的行数，如果执行失败，返回0
     */
    @JvmStatic
    fun deleteByIds(ids: Collection<Long>): Int {
        if (ids.isEmpty()) return 0
        val queryQ = IntRange(0, ids.size - 1).joinToString { "?" }
        val result = database?.delete(
            TrackingLogInfo.TB_NAME,
            "${TrackingLogInfo.COLUMN_ID} in ($queryQ)",
            ids.map { it.toString() }.toTypedArray()
        )
        LogUtils.log4i(
            tag = "TrackingLogQuery",
            msg = "DELETE FROM %s WHERE %s in (%s)",
            formatArgs = arrayOf(
                TrackingLogInfo.TB_NAME,
                TrackingLogInfo.COLUMN_ID,
                ids.joinToString()
            )
        )
        return result ?: 0
    }

    /**
     * 删除所有日志数据
     * @return 受影响的行数，如果执行失败，返回0
     **/
    @JvmStatic
    fun deleteAll(): Int {
        val count = database
            ?.delete(TrackingLogInfo.TB_NAME, null, null)
        LogUtils.log4i("TrackingLogQuery", "删除所有埋点日志：count = $count")
        return count ?: 0
    }

}