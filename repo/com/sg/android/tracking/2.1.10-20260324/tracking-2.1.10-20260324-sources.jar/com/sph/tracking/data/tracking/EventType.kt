package com.sph.tracking.data.tracking


/**
 * 上报类型枚举
 * @param value 类型取值，EventName
 */
enum class EventType(val value: String) {

    /** 应用打开 **/
    AppOpen("app_open"),

    /** 应用卸载 **/
    AppUninstall("app_remove"),

    /** 应用升级 **/
    AppUpgrade("app_update"),

    /** 应用使用时长 **/
    AppUsageTimestamp("app_usage_duration"),

    /**
     * 页面/屏幕浏览
     * + `page_name` - 页面名称
     * + `screen_id` - 网页地址，安卓类名，ios类名
     */
    ScreenView("screen_view"),

    /**
     * 搜索
     * + `search_term` - 搜索关键字
     */
    Search("search"),

    /**
     * 分享
     * + share_method - 分享方式：wechat, facebook or system
     * + share_content_type - 分享类型，图片，文字。。。
     * + share_item_id - 分享的内容，文章ID等
     */
    Share("share"),

    /**
     * 异常信息
     * + `ex_fatal` - 是否严重
     * + `ex_timestamp` - 发生时间戳
     * + `ex_desc` - 错误描述
     */
    Exception("exception"),

    /**
     * 页面停留时长
     * + `page_timing` - 时间戳
     */
    PageTiming("duration");

    override fun toString(): String = value

}