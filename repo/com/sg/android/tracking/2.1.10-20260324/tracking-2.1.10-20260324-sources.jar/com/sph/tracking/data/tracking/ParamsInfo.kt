package com.sph.tracking.data.tracking

import android.os.Build
import androidx.annotation.RequiresApi
import com.google.gson.GsonBuilder

/**
 * 埋点基础参数信息，继承该类需要重写该类所有字段的声明
 * @since 2024.07.18 14:20
 **/
abstract class ParamsInfo {

    private val gson by lazy {
        GsonBuilder()
            .serializeNulls()
            .disableHtmlEscaping()
            .create()
    }

    /** 数据包，提供埋点的数据集 **/
    private val data: MutableMap<String, Any?> = mutableMapOf()

    /**
     * 设置数据, 会覆盖原有键的值
     * @param key 键
     * @param value 值
     */
    fun set(key: String, value: Any?) {
        data[key] = value
    }

    /**
     * 获取数据
     * @param key 键
     * @return 值
     */
    fun get(key: String): Any? = data[key]

    /**
     * 设置数据集合, 会覆盖原有键的值
     * @param value 键值对列表
     */
    fun set(value: Map<String, Any?>) = set(value.toList())

    /**
     * 设置数据集合, 会覆盖原有键的值
     * @param values 键值对列表
     */
    fun set(values: List<Pair<String, Any?>>) {
        values.forEach { set(it.first, it.second) }
    }

    /**
     * 设置数据集合, 会覆盖原有键的值
     * @param values 键值对列表
     */
    fun set(vararg values: Pair<String, Any?>) = set(values.toList())

    /**
     * 删除数据
     * @param key 键
     */
    fun remove(key: String) = data.remove(key)

    /**
     * 删除数据
     * @param key 键
     * @param value 值
     */
    @RequiresApi(Build.VERSION_CODES.N)
    fun remove(key: String, value: Any?) = data.remove(key, value)

    /** 清理数据 **/
    fun clear() = data.clear()

    /** 获取数据包, 此中判断的if逻辑为有默认参数的对象 **/
    open fun getDataBundle(): Map<String, Any?> {
        if (!data.containsKey(KEY_GA_ID))
            set(KEY_GA_ID, gaId)
        if (!data.containsKey(KEY_OS_NAME))
            set(KEY_OS_NAME, osName)
        if (!data.containsKey(KEY_OS_VERSION))
            set(KEY_OS_VERSION, osVersion)
        if (!data.containsKey(KEY_DEVICE_MODEL))
            set(KEY_DEVICE_MODEL, deviceModel)
        if (!data.containsKey(KEY_RESOLUTION))
            set(KEY_RESOLUTION, resolution)
        if (!data.containsKey(KEY_APP_NAME))
            set(KEY_APP_NAME, appName)
        if (!data.containsKey(KEY_PACKAGE_NAME))
            set(KEY_PACKAGE_NAME, packageName)
        if (!data.containsKey(KEY_APP_VERSION))
            set(KEY_APP_VERSION, appVersion)
        if (!data.containsKey(KEY_TEMPLATE_VERSION))
            set(KEY_TEMPLATE_VERSION, templateVersion)
        if (!data.containsKey(KEY_CHANNEL))
            set(KEY_CHANNEL, channelName)
        if (!data.containsKey(KEY_DEVICE_BRAND))
            set(KEY_DEVICE_BRAND, deviceBrand)
        if (!data.containsKey(KEY_DEVICE_FAMILY))
            set(KEY_DEVICE_FAMILY, deviceFamily)
        if (!data.containsKey(KEY_IS_MOBILE))
            set(KEY_IS_MOBILE, isMobile)
        return data
    }

    /** 数据转换成JSON字符串(实现调用的[getDataBundle]的返回结果转JSON的) **/
    fun data2Json(): String = gson.toJson(getDataBundle())

    /** 设置或获取场景ID【上传名称为：scene_id】 **/
    var sceneId: String?
        set(value) = set(KEY_SCENE_ID, value)
        get() = get(KEY_SCENE_ID)?.toString()

    /** 设置或获取session_id【上传名称为：session_id】, 本地指纹+时间戳生成 **/
    var sessionId: String?
        set(value) = set(KEY_SESSION_ID, value)
        get() = get(KEY_SESSION_ID)?.toString()

    /** 设置或获取GA_ID【上传名称为：ga_id】, default value from [ParamsDefaults.gaId] **/
    var gaId: String?
        set(value) = set(KEY_GA_ID, value)
        get() = get(KEY_GA_ID)?.toString() ?: ParamsDefaults.gaId

    /** 设置或获取来源【上传名称为：referrer】 **/
    var referrer: String?
        set(value) = set(KEY_REFERRER, value)
        get() = get(KEY_REFERRER)?.toString()

    /** 设置或获取地址位置信息【上传名称为：geoid】 **/
    var geoId: String?
        set(value) = set(KEY_GEO_ID, value)
        get() = get(KEY_GEO_ID)?.toString()

    /** 设置或获取设备系统名称【上传名称为：os_name】, default value from [ParamsDefaults.osName] **/
    var osName: String?
        set(value) = set(KEY_OS_NAME, value)
        get() = get(KEY_OS_NAME)?.toString() ?: ParamsDefaults.osName

    /** 设置或获取设备系统版本【上传名称为：os_version】, default value from [ParamsDefaults.osVersion] **/
    var osVersion: String?
        set(value) = set(KEY_OS_VERSION, value)
        get() = get(KEY_OS_VERSION)?.toString() ?: ParamsDefaults.osVersion

    /** 设置或获取设备品牌【上传名称为：device_model】, default value from [ParamsDefaults.deviceModel] **/
    var deviceModel: String?
        set(value) = set(KEY_DEVICE_MODEL, value)
        get() = get(KEY_DEVICE_MODEL)?.toString() ?: ParamsDefaults.deviceModel

    /** 设置或获取分辨率 ?x?【上传名称为：resolution】, default value from [ParamsDefaults.resolution] **/
    var resolution: String?
        set(value) = set(KEY_RESOLUTION, value)
        get() = get(KEY_RESOLUTION)?.toString() ?: ParamsDefaults.resolution

    /** 设置或获取应用名称【上传名称为：app_name】, default value from [ParamsDefaults.appName] **/
    var appName: String?
        set(value) = set(KEY_APP_NAME, value)
        get() = get(KEY_APP_NAME)?.toString() ?: ParamsDefaults.appName

    /** 设置或获取应用包名【上传名称为：package_name】, default value from [ParamsDefaults.packageName] **/
    var packageName: String?
        set(value) = set(KEY_PACKAGE_NAME, value)
        get() = get(KEY_PACKAGE_NAME)?.toString() ?: ParamsDefaults.packageName

    /** 设置或获取应用版本【上传名称为：app_version】, default value from [ParamsDefaults.appVersion] **/
    var appVersion: String?
        set(value) = set(KEY_APP_VERSION, value)
        get() = get(KEY_APP_VERSION)?.toString() ?: ParamsDefaults.appVersion

    /** 设置或获取模板版本【上传名称为：template_version】, default value from [ParamsDefaults.templateVersion] **/
    var templateVersion: String?
        set(value) = set(KEY_TEMPLATE_VERSION, value)
        get() = get(KEY_TEMPLATE_VERSION)?.toString() ?: ParamsDefaults.templateVersion

    /**
     * 设置或获取itemUrl【上传名称为：item_url】, (非必填)如果当前页面是在App详情页，
     * 则该页面的所有事件应该上报参数url，该字段为接口返回字段
     **/
    var itemUrl: String?
        set(value) = set(KEY_ITEM_URL, value)
        get() = get(KEY_ITEM_URL)?.toString()

    /**
     * 设置或获取sectionName【上传名称为：section_name】,(非必填)如果当前页面在非App详情页，
     * 则该页面的所有事件应该上报参数section_name。
     * 例如：首页::观点::中国政情
     **/
    var sectionName: String?
        set(value) = set(KEY_SECTION_NAME, value)
        get() = get(KEY_SECTION_NAME)?.toString()

    /** 设置或获取name【上传名称为：name】,从meta中取值，如果没有则不传 **/
    var name: String?
        set(value) = set(KEY_NAME, value)
        get() = get(KEY_NAME)?.toString()

    /**
     * 设置或获取应用渠道名称【上传名称为：channel】，默认为：Default
     * @since 2024.07.18 11:20
     **/
    var channelName: String?
        set(value) = set(KEY_CHANNEL, value)
        get() = get(KEY_CHANNEL)?.toString() ?: ParamsDefaults.appChannelName

    /**
     * 获取或设置设备品牌
     * @since 2025.02.21 09:30
     */
    var deviceBrand: String?
        set(value) = set(KEY_DEVICE_BRAND, value)
        get() = get(KEY_DEVICE_BRAND)?.toString() ?: ParamsDefaults.deviceBrand

    /**
     * 获取或设置设备品牌
     * @since 2025.02.21 09:30
     */
    var deviceFamily: String?
        set(value) = set(KEY_DEVICE_FAMILY, value)
        get() = get(KEY_DEVICE_FAMILY)?.toString() ?: ParamsDefaults.deviceFamily

    /**
     * 获取或设置设备是平板还是手机
     * @since 2025.02.21 09:30
     */
    var isMobile: String?
        set(value) = set(KEY_IS_MOBILE, value)
        get() = get(KEY_IS_MOBILE)?.toString() ?: ParamsDefaults.deviceType

    companion object {

        /** KEY - 场景ID **/
        const val KEY_SCENE_ID = "scene_id"

        /** KEY - session_id **/
        const val KEY_SESSION_ID = "session_id"

        /** KEY - GA_ID **/
        const val KEY_GA_ID = "ga_id"

        /** KEY - 来源 **/
        const val KEY_REFERRER = "referrer"

        /** KEY - 地址位置信息 **/
        const val KEY_GEO_ID = "geoid"

        /** KEY - 设备系统名称 **/
        const val KEY_OS_NAME = "os_name"

        /** KEY - 设备系统版本 **/
        const val KEY_OS_VERSION = "os_version"

        /** KEY - 设备品牌 **/
        const val KEY_DEVICE_MODEL = "device_model"

        /** KEY - 屏幕尺寸 **/
        const val KEY_RESOLUTION = "resolution"

        /** KEY - 应用名称 **/
        const val KEY_APP_NAME = "app_name"

        /** KEY - 应用包名 **/
        const val KEY_PACKAGE_NAME = "package_name"

        /** KEY - 应用版本号 **/
        const val KEY_APP_VERSION = "app_version"

        /** KEY - 模板版本号 **/
        const val KEY_TEMPLATE_VERSION = "template_version"

        /** KEY - itemUrl **/
        const val KEY_ITEM_URL = "item_url"

        /** KEY - sectionName **/
        const val KEY_SECTION_NAME = "section_name"

        /** KEY - 数据名称 **/
        const val KEY_NAME = "name"

        /** KEY - 应用渠道名称 **/
        const val KEY_CHANNEL = "channel"

        /** KEY - 设备品牌 **/
        const val KEY_DEVICE_BRAND = "device_brand"

        /** KEY - 设备制造商 **/
        const val KEY_DEVICE_FAMILY = "device_family"

        /** KEY - 是否是手机，取值：Mobile or Tablet **/
        const val KEY_IS_MOBILE = "is_mobile"

        /**
         * 基础信息收集对象
         * @param value 赋值方法块
         */
        @JvmStatic
        fun base(value: ParamsInfo.() -> Unit = {}): ParamsInfo =
            (object : ParamsInfo() {}).apply(value)

    }

}