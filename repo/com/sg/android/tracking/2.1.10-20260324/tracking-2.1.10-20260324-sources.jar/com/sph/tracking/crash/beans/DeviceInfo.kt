package com.sph.tracking.crash.beans

import com.google.gson.annotations.SerializedName

/**
 * 设备信息实体类
 * @param deviceId 设备ID
 * @param mode 设备模式
 * @param resolution 设备分辨率
 * @param orientation 设备方向
 * @param osName 操作系统名称
 * @param osVersion 操作系统版本
 */
data class DeviceInfo(
    @field:SerializedName("deviceId")
    val deviceId: String = "",
    @field:SerializedName("mode")
    val mode: String = "",
    @field:SerializedName("resolution")
    val resolution: String = "",
    @field:SerializedName("orientation")
    val orientation: String = "",
    @field:SerializedName("osName")
    val osName: String = "",
    @field:SerializedName("osVersion")
    val osVersion: String = "",
)