package com.sph.tracking.data.tracking

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.sph.tracking.tracker.Tracking
import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.log.LogUtils
import org.json.JSONArray
import org.json.JSONObject

/**
 * 埋点信息上报实体类
 * @param trackingId 跟踪ID,项目ID-常量，有默认值：[SharedPrefs.trackingId]
 * @param secretKey API密匙，有默认值：[SharedPrefs.apiSecretKey]
 * @param sdkVersion SDK版本，有默认值：3.0.0 //[Tracking.SDK_VERSION]
 * @param apiVersion API版本，有默认值：[Tracking.API_VERSION]
 * @param clientId 设备ID/用户ID，有默认值：[SharedPrefs.deviceId]
 * @param ssId 从网络上换取的ID，有默认值：[SharedPrefs.ssId]
 * @param userId 用户ID，适用于登录系统，有默认值：[SharedPrefs.userId]
 * @param events 事件信息集合，通常情况下只有一个对象
 */
data class TrackingReportInfo(
    @field: SerializedName("tracking_id")
    var trackingId: String? = SharedPrefs.trackingId,
    @field: SerializedName("secret_key")
    var secretKey: String? = SharedPrefs.apiSecretKey,
    @field: SerializedName("version")
    var sdkVersion: String? = "3.0.0",// Tracking.SDK_VERSION,
    @field: SerializedName("api_version")
    var apiVersion: String? = Tracking.API_VERSION,
    @field: SerializedName("client_id")
    var clientId: String? = SharedPrefs.deviceId,
    @field: SerializedName("ssid")
    var ssId: String? = SharedPrefs.ssId,
    @field: SerializedName("user_id")
    var userId: String? = SharedPrefs.userId,
    @field: SerializedName("events")
    var events: List<EventInfo<*>>? = null,
) {
    /**
     * 转换成JSON字符串
     * @param eventJSON 事件JSON字符串
     */
    fun toJSONString(eventJSON: String?): String {
        return try {
            JSONObject(toString()).apply {
                remove("events")
                if (!eventJSON.isNullOrEmpty()
                    && eventJSON.startsWith("[")
                    && eventJSON.endsWith("]")
                ) put("events", JSONArray(eventJSON))
            }.toString()
        } catch (e: Exception) {
            LogUtils.log4e("TrackingReportInfo", "toJSONString, Error: $e")
            ""
        }
    }

    override fun toString(): String = Gson().toJson(this)

}