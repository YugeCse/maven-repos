package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 搜索关键字参数信息
 * @since 2024.07.18 15:27
 */
open class SearchParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 搜索内容 **/
        const val KEY_SEARCH_TERM = "search_term"

    }

    /** 搜索关键字【上传名为：search_term】**/
    open var searchTerm: String?
        set(value) = set(KEY_SEARCH_TERM, value)
        get() = get(KEY_SEARCH_TERM)?.toString()

}
