package com.sph.tracking.api

import android.net.Uri
import androidx.core.net.toUri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.sph.tracking.api.HttpLoggingInterceptor.applyHttpLoggingInterceptor
import com.sph.tracking.tracker.Tracking
import com.sph.tracking.utils.log.LogUtils
import okhttp3.Call
import okhttp3.Callback
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.Proxy
import java.security.KeyStore
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * 网络API请求类
 * @param proxy 代理设置信息，默认：无
 */
class HttpApi private constructor(private var proxy: Proxy? = Proxy.NO_PROXY) {

    companion object {

        private val instance by lazy { HttpApi() }

        /** 获取网络API单例对象 **/
        @JvmStatic
        fun singleton() = instance

        /** 创建一个新的HttpApi对象 **/
        @JvmStatic
        fun newHttpApi(proxy: Proxy? = Proxy.NO_PROXY) = HttpApi(proxy)

    }

    /** 获取OkHttpClient对象 **/
    var okHttpClient: OkHttpClient
        private set

    init {
        val (trustManager, sslSocketFactory) = try {
            val trustManagers =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
                    .apply {
                        @Suppress("CAST_NEVER_SUCCEEDS")
                        init(null as KeyStore?)
                    }.trustManagers
            if (trustManagers.size != 1 || trustManagers[0] !is X509TrustManager)
                throw IllegalStateException(
                    "Unexpected default trust managers: ${trustManagers.contentToString()}"
                )
            val trustManager = trustManagers.first() as X509TrustManager
            val sslSocketFactory = SSLContext.getInstance("TLS")
                .apply { init(null, arrayOf(trustManager), null) }
                .socketFactory
            trustManager to sslSocketFactory
        } catch (e: Exception) {
            LogUtils.log4e("HttpApi", e)
            Pair(null, null)
        }
        okHttpClient = OkHttpClient.Builder().apply {
            callTimeout(15, TimeUnit.SECONDS)
            // connectTimeout(10, TimeUnit.SECONDS)
            // readTimeout(10, TimeUnit.SECONDS)
            // writeTimeout(15, TimeUnit.SECONDS)
            run { //处理tracking配置的相关参数的设置
                if (LogUtils.logPrintEnabled)
                    applyHttpLoggingInterceptor() //应用Okhttp日志打印的Interceptor
                Tracking.singleton().let { tracking ->
                    if (tracking.apiProxy != null) {
                        this.proxy(tracking.apiProxy) //设置代理信息
                    } else this.proxy(proxy)
                    if (tracking.interceptors.isNotEmpty()) {
                        tracking.interceptors
                            .forEach { interceptor -> addInterceptor(interceptor) }
                    }
                    if (tracking.networkInterceptors.isNotEmpty()) {
                        tracking.networkInterceptors
                            .forEach { interceptor -> addNetworkInterceptor(interceptor) }
                    }
                }
            }
            if (sslSocketFactory != null && trustManager != null)
                sslSocketFactory(sslSocketFactory, trustManager)
            connectionPool(ConnectionPool(6, 2, TimeUnit.MINUTES))
        }.build()
    }

    /**
     * 构建新的HTTP链接
     * @param url 链接URL
     * @param queryParams Query参数
     */
    private fun newHttpUrl(url: String, queryParams: Map<String, Any?> = emptyMap()): String {
        if (queryParams.isEmpty()) return url
        return url.toUri()
            .buildUpon()
            .apply {
                queryParams.forEach { item ->
                    val encodedValue = item.value?.toString()
                        ?.run { Uri.encode(this) }
                    appendQueryParameter(item.key, encodedValue)
                }
            }.build().toString()
    }

    /**
     * 构建新的POST请求
     * @param url 请求链接
     * @param headers 请求头数据
     * @param queryParams Query参数
     * @param requestBody Request数据包
     */
    fun newPostRequest(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        requestBody: RequestBody? = ByteArray(0).toRequestBody()
    ): Request {
        val newUrl = newHttpUrl(url, queryParams)
        return Request.Builder()
            .url(newUrl)
            .post(requestBody ?: ByteArray(0).toRequestBody())
            .apply {
                if (headers.isNotEmpty()) {
                    headers.forEach { item ->
                        header(item.key, item.value?.toString() ?: "")
                    }
                }
            }
            .build()
    }

    /**
     * 发送POST同步请求
     * @param url 请求链接
     * @param requestBody 请求体
     * @param headers 请求的头部数据
     */
    inline fun <reified T : Any> post(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        requestBody: RequestBody? = ByteArray(0).toRequestBody()
    ): ApiCallback<out T> {
        try {
            val httpRequest = newPostRequest(url, headers, queryParams, requestBody)
            val response = okHttpClient.newCall(httpRequest).execute()
            val statusCode = response.code.toString()
            val statusText = response.message
            return if (response.isSuccessful) {
                var outputData: String? = null
                val responseBody = response.body
                responseBody.byteStream().apply {
                    outputData = bufferedReader().readText()
                }.close()
                responseBody.close()
                val outputObject = when (outputData?.trim().isNullOrEmpty()) {
                    true -> null
                    else -> Gson().fromJson<T>(outputData, object : TypeToken<T>() {}.type)
                }
                ApiCallback.Success(
                    code = statusCode,
                    message = statusText,
                    dataResult = outputObject
                )
            } else ApiCallback.Fail(statusCode, statusText)
        } catch (e: Exception) {
            LogUtils.log4e("HttpApi", e)
            return ApiCallback.Fail(null, e.message)
        }
    }

    /**
     * 发送POST异步请求
     * @param url 请求链接
     * @param requestBody 请求体
     * @param headers 请求的头部数据
     */
    inline fun <reified T : Any> postAsync(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        requestBody: RequestBody? = ByteArray(0).toRequestBody(),
        crossinline callback: (ApiCallback<T>) -> Unit = {}
    ): Call {
        val httpRequest = newPostRequest(url, headers, queryParams, requestBody)
        return okHttpClient.newCall(httpRequest).apply {
            enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    callback.invoke(ApiCallback.Fail(null, e.message))
                }

                override fun onResponse(call: Call, response: Response) {
                    val statusCode = response.code.toString()
                    val statusText = response.message
                    if (response.isSuccessful) {
                        var outputData: String? = null
                        val responseBody = response.body
                        responseBody.byteStream().apply {
                            outputData = bufferedReader().readText()
                        }.close()
                        responseBody.close()
                        val outputObject = when (outputData?.trim().isNullOrEmpty()) {
                            true -> null
                            else -> Gson().fromJson<T>(outputData, object : TypeToken<T>() {}.type)
                        }
                        callback.invoke(
                            ApiCallback.Success(
                                code = statusCode,
                                message = statusText,
                                dataResult = outputObject
                            )
                        )
                    } else callback.invoke(ApiCallback.Fail(statusCode, statusText))
                }
            })
        }
    }

}