package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 页面停留时长参数信息
 * @since 2024.07.18 15:30
 */
open class PageTimingParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 页面停留时长 **/
        const val KEY_STAY = "stay"

        /** KEY - 是否是热/冷启动 **/
        const val KEY_IS_RELAUNCH = "relaunch"

        /** KEY - 停留页面的名称 **/
        const val KEY_PAGE_NAME = "page_name"

        /** KEY - 安卓页面类名 **/
        const val KEY_SCREEN_ID = "screen_id"

    }

    /** 页面停留时长 【上传名称为：stay】**/
    open var pageTiming: Long?
        set(value) = set(KEY_STAY, value)
        get() {
            val result = get(KEY_STAY)
            return if (result is Long) result
            else result?.toString()?.toLongOrNull()
        }

    /** 是否是热/冷启动 【上传名称为：relaunch】**/
    open var isRelaunch: Boolean?
        set(value) = set(KEY_IS_RELAUNCH, value)
        get() {
            val result = get(KEY_IS_RELAUNCH)
            return if (result is Boolean) result
            else result?.toString()?.toBooleanStrictOrNull()
        }

    /** 停留页面的名称 【上传名称为：page_name】**/
    open var pageName: String?
        set(value) = set(KEY_PAGE_NAME, value)
        get() = get(KEY_PAGE_NAME)?.toString()

    /** 安卓页面类名 【上传名称为：screen_id】**/
    open var screenId: String?
        set(value) = set(KEY_SCREEN_ID, value)
        get() = get(KEY_SCREEN_ID)?.toString()

}
