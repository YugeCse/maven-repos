package com.sph.tracking.utils.crypto

import com.sph.tracking.utils.log.LogUtils
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


/** 对字符串进行MD5编码处理 **/
fun String.md5Encode(): String? {
    try {
        // Create MD5 Hash
        val digest = MessageDigest.getInstance("MD5")
        digest.update(toByteArray())
        val messageDigest = digest.digest()
        // Create Hex String
        val hexString = StringBuilder()
        for (aMessageDigest in messageDigest) {
            var h = Integer.toHexString(0xFF and aMessageDigest.toInt())
            while (h.length < 2) h = "0$h"
            hexString.append(h)
        }
        return hexString.toString()
    } catch (e: NoSuchAlgorithmException) {
        LogUtils.log4e("String.md5Encode()", e)
        return null
    }
}