package com.sph.tracking.tracker

/**
 * 埋点配置信息
 * @param logPrint 是否可以打印日志
 * @param trackingId 追踪ID
 * @param secretKey API安全KEY
 * @param deviceId 设备唯一ID
 * @param gaId GAId
 * @param ssId SSID，从服务器换取的ID
 * @param userId 登录用户的ID
 * @param templateVersion 应用模板ID
 * @param dataTransportUrl 数据上报接口
 * @param channelName 应用渠道名称
 */
open class TrackingConfigInfo(
    open var logPrint: Boolean? = null,
    open var trackingId: String? = null,
    open var secretKey: String? = null,
    open var deviceId: String? = null,
    open var gaId: String? = null,
    open var ssId: String? = null,
    open var userId: String? = null,
    open var channelName: String? = null,
    open var templateVersion: String? = null,
    open var dataTransportUrl: String
)
