package com.sph.tracking.crash.beans

import com.google.gson.annotations.SerializedName

/**
 * 平台信息实体类
 * @param bundleId 应用包名
 * @param platform 平台名称
 * @param channel 渠道
 * @param version 应用版本
 * @param templateVersion 模板版本
 */
data class PlatformInfo(
    @field: SerializedName("bundleId")
    val bundleId: String = "",

    @field: SerializedName("platform")
    val platform: String = "android",

    @field: SerializedName("channel")
    val channel: String = "",

    @field: SerializedName("version")
    val version: String = "",

    @field: SerializedName("templateVersion")
    val templateVersion: String = "",
)