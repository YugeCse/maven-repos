package com.sph.tracking.crash.beans

import com.google.gson.annotations.SerializedName

/**
 * 状态信息实体类
 * @param freeMem 可用内存
 * @param cpuUsage CPU使用率
 * @param storage 存储空间
 * @param batteryState 电池状态
 */
data class StateInfo(
    @field: SerializedName("freeMem")
    val freeMem: String = "",
    @field: SerializedName("cpuUsage")
    val cpuUsage: String = "",
    @field: SerializedName("storage")
    val storage: String = "",
    @field: SerializedName("batteryState")
    val batteryState: String = "",
)