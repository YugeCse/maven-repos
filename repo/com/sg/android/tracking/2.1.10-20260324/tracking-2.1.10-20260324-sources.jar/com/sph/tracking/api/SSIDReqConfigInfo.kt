package com.sph.tracking.api

import android.os.Build
import androidx.annotation.ChecksSdkIntAtLeast
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName

/**
 * SSID请求配置参数信息
 * @param deviceId 设备ID
 * @param osName OS名称 - android
 * @param osVersion OS版本 - [Build.VERSION.SDK_INT]
 * @param deviceModel 设备型号 - [Build.MODEL]
 * @param deviceBrand 设备品牌 - [Build.BRAND]
 * @param platform 平台名称 - android
 * @param accessToken 访问令牌, 当用户登录了后，会重新调用获取ssid接口，传递token，获取新的ssid
 */
data class SSIDReqConfigInfo(
    @field:SerializedName("deviceId")
    var deviceId: String? = null,

    @field:SerializedName("osName")
    var osName: String? = "android",

    @field:SerializedName("osVersion")
    @ChecksSdkIntAtLeast(extension = 0)
    var osVersion: Int? = Build.VERSION.SDK_INT,

    @field:SerializedName("deviceModel")
    var deviceModel: String? = Build.MODEL,

    @field:SerializedName("deviceBrand")
    var deviceBrand: String? = Build.BRAND,

    @field:SerializedName("platform")
    var platform: String? = "android",

    @field:SerializedName("accessToken")
    var accessToken: String? = null
) {

    override fun toString(): String = Gson().toJson(this)

}
