package com.sph.tracking.tracker

import androidx.annotation.IntRange
import com.sph.tracking.api.ApiCallback
import com.sph.tracking.api.HttpApiRepo
import com.sph.tracking.data.db.query.TrackingLogQuery
import com.sph.tracking.data.db.table.TrackingLogInfo
import com.sph.tracking.data.tracking.TrackingReportInfo
import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.log.LogUtils
import okhttp3.Call
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.ThreadPoolExecutor

/** 埋点日志上报处理 **/
internal class TrackingDataTransporter private constructor() {

    companion object {

        /** 任务线程最大数量为3 **/
        const val TASK_THREAD_MAX_COUNT = 3

        /** 任务执行最大数量为6 **/
        const val TASK_EXEC_MAX_COUNT = 6

        /** 任务初次 - 延迟时间 - 10s **/
        const val INITIAL_DELAY_SECONDS = 10L

        /** 任务执行间隔时间 - 10s **/
        const val TASK_EXEC_INTERVAL_SECONDS = 10L

        /** 任务上传的每次最大数量为30, 允许范围为：12..30 **/
        const val TASK_PER_UPLOAD_MAX_COUNT = 30

        private val instance by lazy { TrackingDataTransporter() }

        @JvmStatic
        fun singleton() = instance

    }

    /** 每次上传的最大数据条数 **/
    private var perUploadMaxCount: Int = 30

    /** 是否使用倒序查询上传的数据 **/
    private var isDescQueryData: Boolean = false

    /** 正在上传的数据ID集合 **/
    private var nowUploadingDataIds = ConcurrentLinkedQueue<Long>()

    /** 任务定时器 **/
    private var taskTimer: Timer? = null

    /** 任务线程池 **/
    private var executor: ExecutorService? = null

    /** 上传API请求缓存池 **/
    private var uploadRequesters: MutableList<Call?> = mutableListOf()

    /**
     * 开始任务
     * @param perUploadMaxCount 每次上传的最大数据条数,默认：20，如果任务不在范围12..30中则默认为30
     * @param isDesc 是否使用倒序查询，默认：false
     */
    fun start(@IntRange(12, 30) perUploadMaxCount: Int = 20, isDesc: Boolean = false) {
        this.isDescQueryData = isDesc //记录是否使用倒序查询
        if (this.perUploadMaxCount !in 12..TASK_PER_UPLOAD_MAX_COUNT)
            this.perUploadMaxCount = TASK_PER_UPLOAD_MAX_COUNT
        else this.perUploadMaxCount = perUploadMaxCount
        if (executor == null)
            executor = Executors.newFixedThreadPool(TASK_THREAD_MAX_COUNT)
        startTaskTimer() //启动任务定时器
        LogUtils.log4i(
            tag = "TrackingUploader",
            msg = "设置任务每次上传数：$perUploadMaxCount, 倒序查询：$isDesc"
        )
    }

    /** 获取是否满足配置要求 **/
    private val isSatisfyConfigRequired: Boolean
        get() {
            val dataReportUrl = SharedPrefs.dataReportUrl
            if (dataReportUrl.isNullOrEmpty()
                || !dataReportUrl.matches("^https?://.*".toRegex())
            ) {
                LogUtils.log4e("TrackingUploader", "未配置数据上报接口：dataReportUrl !")
                return false
            }
            if (SharedPrefs.ssId.isNullOrEmpty()) {
                LogUtils.log4e("TrackingUploader", "未配置数据上报参数ssId !")
                return false
            }
            return true
        }

    /** 是否满足基本配置要求 **/
    private val isSatisfyBaseRequired: Boolean
        get() = isSatisfyConfigRequired && executor != null && taskTimer != null

    /** 是否满足数量要求(前提是满足基本要求): 等待上传数量 >= [perUploadMaxCount] **/
    val isSatisfyCountRequired: Boolean
        get() {
            if (!isSatisfyBaseRequired) return false
            val waitingTaskCount = when {
                executor != null &&
                        executor is ThreadPoolExecutor ->
                    (executor as ThreadPoolExecutor).queue.size
                else -> TASK_EXEC_MAX_COUNT
            }
            // LogUtils.log4i("TrackingUploader", "等待任务数量：$waitingTaskCount")
            return waitingTaskCount < TASK_EXEC_MAX_COUNT &&
                    TrackingLogQuery.queryTrackingLogs(
                        isDesc = this.isDescQueryData,
                        limitCount = perUploadMaxCount,
                        excludeIds = nowUploadingDataIds.toList()
                    ).size >= perUploadMaxCount
        }

    /** 提交一个上传任务，如果不满足要求，则不能提交任务 **/
    fun submitUploadTask(): Future<*>? {
        try {
            if (!isSatisfyBaseRequired) return null
            return executor?.submit {
                uploadTrackingLogs(
                    isDesc = isDescQueryData,
                    perUploadMaxCount = perUploadMaxCount
                )
            }
        } catch (e: Exception) {
            LogUtils.log4e("TrackingUploader", e.toString())
            return null
        }
    }

    /** 关闭线程任务池 **/
    fun shutdown() {
        try {
            releaseTaskTimer() //取消任务定时器
            cancelUploadRequester() //取消上传API请求
            if (executor?.isShutdown != true)
                executor?.shutdown()
            executor = null
        } catch (e: Exception) {
            LogUtils.log4e("TrackingUploader", e.toString())
        }
    }

    /** 取消上传API请求 **/
    private fun cancelUploadRequester() {
        try {
            uploadRequesters.forEach { requester ->
                if (requester?.isCanceled() != true) {
                    requester?.cancel()
                }
            }
            uploadRequesters.clear() //清空定时任务数据请求缓存池
        } catch (e: Exception) {
            LogUtils.log4e("TrackingUploader", e.toString())
        }
    }

    /**
     * 发送埋点日志到服务器
     * @param perUploadMaxCount 每次上传的最大条数，默认20
     * @param isDesc 是否使用倒序方式，默认：false
     */
    private fun uploadTrackingLogs(perUploadMaxCount: Int = 20, isDesc: Boolean = false) {
        try {
            if (!isSatisfyConfigRequired) return //未满足必要配置则不上传
            val logIds = mutableListOf<Long>()
            val logs = mutableListOf<TrackingLogInfo>()
            synchronized(this) {
                logs.addAll(
                    TrackingLogQuery.queryTrackingLogs(
                        isDesc = isDesc,
                        limitCount = perUploadMaxCount,
                        excludeIds = nowUploadingDataIds.toList()
                    )
                )
                logIds.addAll(logs.map { it.id }.toList())
                if (logs.isEmpty()) return //当未获取到日志时，不应上传日志
                nowUploadingDataIds.addAll(logIds) //记录正在上传的数据ID集合
                LogUtils.log4i("TrackingUploader", "正在上传数据...${logIds.joinToString(",")}")
            }
            val trackingEventJsonData =
                "[".plus(logs.joinToString(",") { v -> v.logContent }).plus("]")
            val trackingReportJsonData = TrackingReportInfo()
                .toJSONString(eventJSON = trackingEventJsonData)
            LogUtils.log4i("TrackingUploader", "-------------- 埋点任务上报中 --------------")
            var requester: Call? = null
            requester = HttpApiRepo.reportTrackingRecords(
                requestUrl = SharedPrefs.dataReportUrl!!,
                recordsJsonData = trackingReportJsonData
            ) { callback ->
                uploadRequesters.remove(requester)
                if (callback is ApiCallback.Success)
                    TrackingLogQuery.delete(logs)
                nowUploadingDataIds.removeAll(logIds.toSet()) //删除所有上传中的数据ID
                LogUtils.log4i(
                    "TrackingUploader",
                    "数据从任务中删除...${logIds.joinToString(",")}"
                )
                LogUtils.log4i(
                    tag = "GlobalCrashLogHandler",
                    msg = "==> 埋点日志上报结果: code = %s; message = %s",
                    formatArgs = arrayOf(callback.code, callback.message)
                )
                LogUtils.log4i(
                    "TrackingUploader",
                    "-------------- 埋点任务上报完成 --------------"
                )
            }
            uploadRequesters.add(requester) //添加数据请求任务的对象
        } catch (e: Exception) {
            LogUtils.log4e("GlobalCrashLogHandler", e)
        }
    }

    /** 启动任务定时器 **/
    private fun startTaskTimer() {
        releaseTaskTimer()
        taskTimer = Timer("TrackingDataTransporterTimer")
        taskTimer?.schedule(object : TimerTask() {
            override fun run() {
                submitUploadTask() //提交一个上传任务
            }
        }, INITIAL_DELAY_SECONDS * 1000, TASK_EXEC_INTERVAL_SECONDS * 1000)
    }

    /** 结束任务定时器 **/
    private fun releaseTaskTimer() {
        if (taskTimer != null)
            taskTimer?.cancel()
        taskTimer = null
    }

}