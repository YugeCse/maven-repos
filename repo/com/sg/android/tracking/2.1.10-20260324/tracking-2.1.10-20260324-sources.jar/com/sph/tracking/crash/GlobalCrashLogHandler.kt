package com.sph.tracking.crash

import android.content.Context
import com.google.gson.Gson
import com.sph.tracking.api.ApiCallback
import com.sph.tracking.api.HttpApi
import com.sph.tracking.crash.beans.ErrorReportInfo
import com.sph.tracking.utils.log.LogUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileReader

/** Crash日志上报处理 **/
internal class GlobalCrashLogHandler private constructor() {

    companion object {

        /** 获取GlobalCrashLogHandler单例对象 **/
        val singleton by lazy { GlobalCrashLogHandler() }

        /** 错误上报的API-PATH **/
        const val CRASH_REPORT_API_PATH = "/appapi/apm-m/collect/event"

    }

    /** 当前上传任务对象 **/
    private var uploadErrorJob: Call? = null

    /**
     * 错误日志上报
     * @param baseUrl 错误上报的BaseURL
     * @param error 错误数据
     * @param callback 回调方法
     */
    private fun trackErrorEvent(
        baseUrl: String,
        error: List<ErrorReportInfo>,
        callback: (ApiCallback<Any>) -> Unit = {}
    ): Call {
        return HttpApi.singleton().postAsync<Any>(
            url = "${baseUrl}${CRASH_REPORT_API_PATH}",
            requestBody = Gson().toJson(error)
                .toRequestBody("application/json".toMediaTypeOrNull()),
            callback = callback
        )
    }

    /**
     * 启动发送本地崩溃日志
     * @param context 上下文对象
     * @param baseUrl 接口请求的BaseURL
     */
    fun uploadCrashLogs(context: Context, baseUrl: String) {
        runCatching {
            CoroutineScope(Dispatchers.IO).launch {
                runCatching {
                    if (uploadErrorJob != null) {
                        uploadErrorJob?.cancel()
                        uploadErrorJob = null
                    }
                    val rootDir = GlobalCrashHandler.getDiskCrashDir(context)
                    val errorLogs = readCrashLogs(rootDir)
                    if (errorLogs.isNotEmpty()) {
                        uploadErrorJob = trackErrorEvent(baseUrl, errorLogs) {
                            if (it is ApiCallback.Success)
                                cleanLogs(rootDir)
                            LogUtils.log4d(
                                "GlobalCrashLogHandler",
                                "崩溃日志上报结果：${it.code}+${it.message}"
                            )
                        }
                    } else LogUtils.log4i("GlobalCrashLogHandler", "没有崩溃日志！")
                }.onFailure { e -> LogUtils.log4e("GlobalCrashLogHandler", e) }
            } // 协程中执行上传任务
        }.onFailure { e ->
            LogUtils.log4i("GlobalCrashLogHandler", "崩溃日志上报失败！错误：${e.toString()}")
        }
    }

    /** 读取Crash日志 **/
    private fun readCrashLogs(root: File): List<ErrorReportInfo> {
        return root.listFiles()
            ?.mapNotNull { file -> readFile(file) }
            ?.toList()
            ?: emptyList()
    }

    /** 读取文件 **/
    private fun readFile(file: File): ErrorReportInfo? {
        val strBufferedReader = FileReader(file)
        val logs = strBufferedReader.readText()
        strBufferedReader.close()
        return Gson().fromJson(logs, ErrorReportInfo::class.java)
    }

    /** 清空日志 **/
    private fun cleanLogs(root: File) = root.listFiles()?.forEach { file -> file.delete() }

}