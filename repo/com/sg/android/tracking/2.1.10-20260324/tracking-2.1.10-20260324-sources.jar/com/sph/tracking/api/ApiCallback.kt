package com.sph.tracking.api

import com.google.gson.annotations.SerializedName

/** 回调对象类 **/
sealed interface ApiCallback<T> {

    /** 状态码 **/
    var code: String?

    /** 状态消息 **/
    var message: String?

    /**
     * 成功
     * @param code 状态码
     * @param message 状态消息
     * @param dataResult 返回数据
     */
    data class Success<T>(
        @field:SerializedName("code")
        override var code: String?,
        @field:SerializedName("message")
        override var message: String? = null,
        @field:SerializedName("data")
        var dataResult: T? = null
    ) : ApiCallback<T>

    /**
     * 失败
     * @param code 错误码
     * @param message 错误消息
     */
    data class Fail<T : Any>(
        @field:SerializedName("code")
        override var code: String?,
        @field:SerializedName("message")
        override var message: String? = null
    ) : ApiCallback<T>

}

/** 通过Code判断请求是否成功，200～299判断为成功 **/
val ApiCallback<*>.isSuccessful
    get() = code?.matches("^\\d+$".toRegex()) == true && code!!.toInt() in 200..299