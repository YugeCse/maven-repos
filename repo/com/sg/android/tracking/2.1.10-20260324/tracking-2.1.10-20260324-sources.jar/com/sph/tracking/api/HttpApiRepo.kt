package com.sph.tracking.api

import com.sph.tracking.utils.app.SharedPrefs
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody

/** 网络API仓库 **/
internal object HttpApiRepo {

    /**
     * 上报埋点记录
     * @param requestUrl 请求链接
     * @param recordsJsonData 埋点记录数据Json
     */
    @JvmStatic
    fun reportTrackingRecords(
        requestUrl: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        recordsJsonData: String,
        callback: (ApiCallback<Any>) -> Unit = {}
    ) = HttpApi.singleton().postAsync(
        url = requestUrl,
        headers = headers,
        queryParams = queryParams,
        requestBody = recordsJsonData.toRequestBody("application/json".toMediaTypeOrNull()),
        callback = callback
    )


    /**
     * **获取SSID信息**
     * + 1.当本地缓存ssid为空时需要调用；
     * + 2.当用户登录后，需要重新调用；
     * + 3.用户退出登录(手动退出/token失效退出)，无需调用；
     *
     * @param apiUrl 完整路径
     * @param queryParams 查询参数
     * @param postParams POST参数
     * @param callback 结果回调方法
     * @return 返回带有SSID的字符串结果，或者返回失败
     */
    @JvmStatic
    fun getSSID(
        apiUrl: String,
        queryParams: Map<String, Any?> = mapOf(),
        postParams: SSIDReqConfigInfo.() -> Unit = {},
        callback: (ApiCallback<String>) -> Unit
    ) = HttpApi.singleton().postAsync<HttpApiResponseInfo<LinkedHashMap<String, Any?>>>(
        url = apiUrl,
        queryParams = mutableMapOf<String, Any?>().apply {
            putAll(queryParams)
            putAll(mapOf("ak" to SharedPrefs.trackingId, "sk" to SharedPrefs.apiSecretKey))
        },
        requestBody = SSIDReqConfigInfo(deviceId = SharedPrefs.deviceId)
            .apply(postParams)
            .toString()
            .toRequestBody("application/json".toMediaTypeOrNull())) { result ->
        callback.invoke(when (result) {
            is ApiCallback.Success -> when {
                result.isSuccessful && result.dataResult?.isSuccessful == true -> {
                    val ssid = result.dataResult
                        ?.data
                        ?.getOrElse("ssid") { "" }
                        ?.toString()
                    ApiCallback.Success(result.code, result.dataResult?.message, ssid)
                }
                else -> ApiCallback.Fail(result.code, result.dataResult?.message
                    ?: result.message)
            }
            else -> ApiCallback.Fail(result.code, result.message)
        })
    }

}