package com.sph.tracking.utils.app

import android.content.Context
import android.content.res.Configuration.ORIENTATION_LANDSCAPE
import android.content.res.Configuration.ORIENTATION_PORTRAIT
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import androidx.core.hardware.display.DisplayManagerCompat
import com.sph.tracking.utils.log.LogUtils


/** 获取应用名称 **/
internal fun Context.getAppName(): String =
    applicationInfo.loadLabel(packageManager).toString()

/**
 * 获取屏幕真实尺寸大小
 * @return width x height, 如：1080x1920
 */
@Suppress("DEPRECATION")
internal fun Context.getScreenRealSizeText(): String {
    val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val outMetrics = DisplayMetrics()
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R)
        wm.defaultDisplay.getRealMetrics(outMetrics)
    else DisplayManagerCompat.getInstance(this)
        .getDisplay(Display.DEFAULT_DISPLAY)
        ?.getRealMetrics(outMetrics)
    return "${outMetrics.widthPixels}x${outMetrics.heightPixels}"
}

/** 获取应用版本号 **/
internal fun Context.getVersionName(): String? {
    return try {
        packageManager.getPackageInfo(packageName, 0).versionName
    } catch (e: Exception) {
        LogUtils.log4e("Context.getVersionName", e)
        null
    }
}

/** 获取屏幕方向 **/
internal fun Context.getOrientationDescription(): String {
    return when (resources.configuration.orientation) {
        ORIENTATION_LANDSCAPE -> "Landscape"
        ORIENTATION_PORTRAIT -> "Portrait"
        else -> null
    } ?: "Portrait"
}