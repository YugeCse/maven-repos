package com.sph.tracking.data.tracking.params

import com.sph.tracking.data.tracking.ParamsInfo

/**
 * 应用升级参数信息
 * @since 2024.07.18 15:30
 **/
open class AppUpgradeParamsInfo : ParamsInfo() {

    companion object {

        /** KEY - 获取或设置前一个应用版本 **/
        const val KEY_APP_PREVIOUS_VERSION = "app_previous_version"

        /** KEY - 获取或设置应用升级后的版本 **/
        const val KEY_APP_UPDATE_VERSION = "app_update_version"

    }

    /** 获取或设置前一个应用版本【上传名称为：app_previous_version】 **/
    open var appPreviousVersion: String?
        set(value) = set(KEY_APP_PREVIOUS_VERSION, value)
        get() = get(KEY_APP_PREVIOUS_VERSION)?.toString()

    /** 获取或设置应用升级后的版本【上传名称为：app_update_version】 **/
    open var appUpdateVersion: String?
        set(value) = set(KEY_APP_UPDATE_VERSION, value)
        get() = get(KEY_APP_UPDATE_VERSION)?.toString()

}
