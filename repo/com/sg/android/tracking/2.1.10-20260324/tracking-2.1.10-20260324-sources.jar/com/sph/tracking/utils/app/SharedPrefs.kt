package com.sph.tracking.utils.app

import android.content.Context
import androidx.core.content.edit
import com.sph.tracking.BuildConfig
import com.sph.tracking.provider.ContextProvider

/** 本地信息配置对象 **/
object SharedPrefs {

    /** SharedPreferences对象 **/
    private val sharedPrefs by lazy {
        ContextProvider.provideContext()
            ?.getSharedPreferences("__tracking_config", Context.MODE_PRIVATE)
    }

    /**
     * 获取Boolean值
     * @param key 键
     * @param default 默认值
     */
    fun getBoolean(
        key: String,
        default: Boolean
    ): Boolean? = sharedPrefs?.getBoolean(key, default)

    /**
     * 设置Boolean值
     * @param key 键
     * @param value 值
     */
    fun setBoolean(key: String, value: Boolean) {
        sharedPrefs?.edit(true) { putBoolean(key, value) }
    }

    /**
     * 获取String值
     * @param key 键
     * @param default 默认值
     */
    fun getString(
        key: String,
        default: String? = null
    ): String? = sharedPrefs?.getString(key, default)

    /**
     * 设置String值
     * @param key 键
     * @param value 值
     */
    fun setString(key: String, value: String?) {
        sharedPrefs?.edit(true) { putString(key, value) }
    }

    /** 获取或设置打印日志是否可用 **/
    var logPrintEnabled: Boolean?
        set(value) {
            setBoolean("log_print_enabled", value ?: BuildConfig.DEBUG)
        }
        get() = getBoolean("log_print_enabled", BuildConfig.DEBUG)

    /** 获取或设置TrackingID **/
    var trackingId: String?
        set(value) = setString("tracking_id", value)
        get() = getString("tracking_id")

    /** 获取或设置设备ID **/
    var deviceId: String?
        set(value) = setString("device_id", value)
        get() = getString("device_id", "")

    /** 获取或设置应用渠道名称 **/
    var channelName: String?
        set(value) = setString("channel_name", value)
        get() = getString("channel_name", "Default")

    /** 获取或设置GA_ID **/
    var gaId: String?
        set(value) = setString("ga_id", value)
        get() = getString("ga_id", "")

    /** 获取或设置SS_ID **/
    var ssId: String?
        set(value) = setString("ss_id", value)
        get() = getString("ss_id", "")

    /** 获取或设置用户ID **/
    var userId: String?
        set(value) = setString("user_id", value)
        get() = getString("user_id", "")

    /** 获取或设置SessionID **/
    var sessionId: String?
        set(value) = setString("session_id", value)
        get() = getString("session_id", "")

    /** 获取或设置模板版本 **/
    var templateVersion: String?
        set(value) = setString("template_version", value)
        get() = getString("template_version")

    /** 获取或设置API密匙 **/
    var apiSecretKey: String?
        set(value) = setString("api_secret_key", value)
        get() = getString("api_secret_key")

    /** 获取或设置是否埋点页面 **/
    var isTrackingPage: Boolean
        set(value) = setBoolean("is_tracking_page", value)
        get() = getBoolean("is_tracking_page", true) ?: true

    /** 获取或设置是否埋点事件 **/
    var isTrackingEvent: Boolean
        set(value) = setBoolean("is_tracking_event", value)
        get() = getBoolean("is_tracking_event", true) ?: true

    /** 获取或设置是否埋点计时 **/
    var isTrackingTiming: Boolean
        set(value) = setBoolean("is_tracking_timing", value)
        get() = getBoolean("is_tracking_timing", true) ?: true

    /** 获取或设置是否埋点社交信息 **/
    var isTrackingSocial: Boolean
        set(value) = setBoolean("is_tracking_social", value)
        get() = getBoolean("is_tracking_social", true) ?: true

    /** 获取或设置是否埋点异常 **/
    var isTrackingException: Boolean
        set(value) = setBoolean("is_tracking_exception", value)
        get() = getBoolean("is_tracking_exception", true) ?: true

    /** 设置或获取埋点上传接口链接 **/
    var dataReportUrl: String?
        set(value) = setString("data_report_url", value)
        get() = getString("data_report_url")

}