package com.sph.tracking.utils.other

import com.sph.tracking.utils.app.SharedPrefs
import com.sph.tracking.utils.crypto.md5Encode
import java.util.Date

/** Session生成类 **/
object SessionGenerator {

    /**
     * 生成MD5加密过的SessionId
     * @param deviceId 设备唯一ID
     * @param timeMillis 时间戳
     */
    @JvmStatic
    fun generateSessionId(
        deviceId: String? = SharedPrefs.deviceId,
        timeMillis: Long = Date().time
    ): String? = ((deviceId ?: "") + timeMillis.toString()).md5Encode()

}