package com.sg.vote.view

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastForEachIndexed
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.sg.common.theme.LocalColorPallet
import com.sg.common.theme.LocalDimens
import com.sg.common.theme.LocalUiUseDarkTheme
import com.sg.common.theme.TypographyScaleType
import com.sg.common.theme.TypographyScaleType.Companion.calculateForNewsList
import com.sg.common.theme.TypographyType
import com.sg.common.theme.utils.convertPx2dip
import com.sg.vote.R
import com.sg.vote.VotePollSdk
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.beans.VoteQuestionInfo
import com.sg.vote.data.beans.VoteSettingInfo
import com.sg.vote.data.beans.getVoteLimitDescriptionText
import com.sg.vote.data.extras.PollState
import com.sg.vote.data.view.LocalVoteCardViewConfig
import com.sg.vote.utils.DeviceUtils
import com.sg.vote.utils.applyTestTag
import com.sg.vote.utils.dipToPixel
import com.sg.vote.utils.pixelToDip
import com.sg.vote.utils.singleClickable
import com.sg.vote.view.options.InternalVoteOptionGridItemView
import com.sg.vote.view.options.InternalVoteOptionListItemView
import com.sg.vote.view.other.CardDividerView
import com.sg.vote.view.preview.DefaultPreview
import com.sg.vote.view.zaobao.ZbText
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 投票卡片视图
 * @param modifier Modifier
 * @param event 投票卡片视图事件管理类
 * @param data 投票信息(可能包含投票结果信息)*/
@Composable
internal fun InternalVotePollView(
    modifier: Modifier = Modifier,
    data: VoteDataInfo? = null,
    event: VotePollViewEventHandler = remember { object : VotePollViewEventHandler() {} }
) = Column(
    modifier = Modifier
        .applyTestTag("internal_vote_poll_view")
        .then(modifier)
        .fillMaxWidth()
        .background(LocalColorPallet.current.backgroundPrimary)
) {
    val context = LocalContext.current
    val isInEditMode = LocalInspectionMode.current
    val config = LocalVoteCardViewConfig.current
    val borderInfo = remember(config) { config.pollCardViewBorder }
    val typographyScaleType = remember(config) { config.typographyScaleType }
    val useSimpleCNText = remember(config) { config.useSimpleCN } //是否使用简体中文
    var enforceRefreshKeyForGridLayout by remember { mutableStateOf<String?>(null) }

    /** 投票按钮执行次数，没有执行过投票，就不展示投票结果信息; 偶数次才能投票，否则只能是继续投票点击后返回投票状态 **/
    var execVoteButtonCount by rememberSaveable { mutableIntStateOf(0) }
    CardDividerView(
        borderConfig = borderInfo?.top,
        paddingHorizontal = config.pollCardHorizontalPadding
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(LocalColorPallet.current.backgroundPrimary)
            .padding(
                // vertical = LocalDimens.current.dp16,
                horizontal = config.pollCardHorizontalPadding
            ),
        horizontalAlignment = Alignment.Start
    ) {
        ZbText(
            modifier = Modifier.applyTestTag("vote_poll_view_title"),
            text = stringResource(R.string.app_user_vote_poll_title),
            color = when {
                !LocalUiUseDarkTheme.current ->
                    LocalColorPallet.current.textEmphasis

                else -> LocalColorPallet.current.linkEmphasisDefault
            },
            type = TypographyType.Header2,
            scaleType = with(typographyScaleType) { calculateForNewsList }
        )
        val voteTitleInteractionSource = remember { MutableInteractionSource() }
        val isVoteTitleHover by voteTitleInteractionSource.collectIsPressedAsState()
        val voteQuestionTitle = remember(useSimpleCNText, data?.item?.name) {
            val funIcu = VotePollSdk.simpleCN2TraditionalCN
            if (!useSimpleCNText && funIcu != null) {
                funIcu.invoke(data?.item?.name ?: "")
            } else data?.item?.name ?: ""
        }
        ZbText(
            modifier = Modifier
                .applyTestTag("tv_vote_title")
                .padding(top = LocalDimens.current.dp16)
                .run {
                    if (data?.item?.link.isNullOrEmpty()) this
                    else singleClickable(
                        useLocalIndication = false,
                        interactionSource = voteTitleInteractionSource
                    ) { event.onVoteTitleClick(data, data.item.link) }
                },
            text = voteQuestionTitle,
            color = when {
                !isVoteTitleHover ->
                    LocalColorPallet.current.textEmphasis

                else -> LocalColorPallet.current.linkInComponentBrandSecondary
            },
            type = TypographyType.Header4,
            scaleType = with(typographyScaleType) { calculateForNewsList }
        )
        if (data?.showTime == true) { //如果需要显示活动时间的话
            ZbText(
                modifier = Modifier
                    .applyTestTag("tv_vote_event_time")
                    .padding(top = LocalDimens.current.dp5),
                text = stringResource(
                    R.string.app_user_vote_poll_activity_time,
                    (data.activityTime ?: "")
                ),
                color = LocalColorPallet.current.textPrimary,
                type = TypographyType.Body2,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
        }
        if (data?.setting?.showImages != true) {
            HorizontalDivider(
                thickness = LocalDimens.current.dp1,
                color = LocalColorPallet.current.dividerPrimary,
                modifier = Modifier.padding(top = LocalDimens.current.dp16)
            )
        }
        val voteLinkText = remember(useSimpleCNText, data?.linkText) {
            val funIcu = VotePollSdk.simpleCN2TraditionalCN
            if (!useSimpleCNText && funIcu != null) {
                funIcu.invoke(data?.linkText ?: "")
            } else data?.linkText ?: ""
        }
        if (voteLinkText.isNotEmpty() && !data?.linkUrl.isNullOrEmpty()) {
            ZbText(
                modifier = Modifier
                    .applyTestTag("tv_vote_sub_title")
                    .padding(top = LocalDimens.current.dp16)
                    .run {
                        if (data.linkUrl.isEmpty()) this
                        else singleClickable { event.onVoteExtLinkClick(data, data.linkUrl) }
                    },
                text = voteLinkText,
                color = LocalColorPallet.current.linkInComponentBrandSecondary,
                type = TypographyType.Label8,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
        }
        var isMarkVoteResult by rememberSaveable { mutableStateOf(false) }
        var userSelectIndex by rememberSaveable(data?.id) { mutableStateOf<Int?>(null) }
        val (voteTipMessage, pollState) = remember(data, isInEditMode) {
            var newVoteData = data?.copy() //复制一份投票数据
            if (!isInEditMode) {
                val voteRecord = VotePollSdk.getVoteRecords(
                    ssid = VotePollSdk.customUserId,
                    voteId = data?.item?.voteId
                )
                voteRecord?.voteCount?.let { userVoteCount ->
                    if (userVoteCount > (data?.item?.userCount ?: 0)) {
                        newVoteData =
                            newVoteData?.copy(item = newVoteData.item?.copy(userCount = userVoteCount))
                    }
                }
            }
            newVoteData?.getVoteLimitDescriptionText(context)
                ?: Pair("", PollState.ContinueVote)
        }
        LaunchedEffect(execVoteButtonCount) {
            if (execVoteButtonCount % 2 != 0)
                return@LaunchedEffect
            userSelectIndex = null //还原投票状态，设置未选中状态
        }
        if (data?.setting?.showImages != true) { // 如果不展示图片，则只展示文本
            Column(
                modifier = Modifier
                    .applyTestTag("v_vote_list_item_views")
                    .padding(top = LocalDimens.current.dp2)
                    .fillMaxWidth()
            ) {
                data?.item?.answers?.fastForEachIndexed { index, item ->
                    InternalVoteOptionListItemView(
                        modifier = Modifier.padding(top = LocalDimens.current.dp16),
                        data = item,
                        voteTotalCount = data.item.itemTotal?.toLong() ?: 0L,
                        isMarkVoteResult = isMarkVoteResult,
                        showResult = (data.setting?.showResult == true) &&
                                (execVoteButtonCount % 2 != 0 || pollState is PollState.LimitVote),
                        // assertUrlPrefix = data.assetsPrefix,
                        onClick = when {
                            (data.isVotePollEnded ||
                                    (!data.isVotePollEnded &&
                                            !data.isVotePollStarted &&
                                            !data.hasVoteButton)
                                    || execVoteButtonCount % 2 != 0) ||
                                    pollState is PollState.LimitVote -> null

                            else -> fun() {
                                if (index != userSelectIndex && userSelectIndex != null)
                                    isMarkVoteResult = false
                                userSelectIndex = index  //赋值新的选中项
                            }
                        },
                        isSelected = userSelectIndex == index && !data.isVotePollEnded,
                    )
                }
            }
        } else Column(
            modifier = Modifier
                .padding(top = LocalDimens.current.dp20)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            var voteItemCardHeight by rememberSaveable(typographyScaleType) {
                mutableStateOf<Int?>(null)
            }
            LaunchedEffect(execVoteButtonCount) {
                if (execVoteButtonCount % 2 == 0)
                    voteItemCardHeight = null
            }
            ExpandedGridView(
                modifier = Modifier
                    .applyTestTag("v_vote_grid_item_views")
                    .fillMaxWidth(),
                enforceRefreshKey = enforceRefreshKeyForGridLayout,
                typographyScaleType = typographyScaleType,
                inputDataSource = data.item?.answers ?: emptyList(),
            ) { dataIndex, itemData ->
                InternalVoteOptionGridItemView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .onSizeChanged { size ->
                            var tagetVoteItemCardSizeHeight = voteItemCardHeight
                            if (execVoteButtonCount % 2 == 0)
                                tagetVoteItemCardSizeHeight = 0
                            if (tagetVoteItemCardSizeHeight == null ||
                                tagetVoteItemCardSizeHeight == 0
                            ) voteItemCardHeight = size.height
                            else {
                                val requiredHeight = tagetVoteItemCardSizeHeight
                                if (size.height > requiredHeight)
                                    voteItemCardHeight = size.height
                            }
                        }
                        .defaultMinSize(minHeight = pixelToDip(voteItemCardHeight ?: 0)),
                    data = itemData,
                    voteTotalCount = data.item?.itemTotal?.toLong() ?: 0L,
                    showResult = (data.setting.showResult == true) &&
                            (execVoteButtonCount % 2 != 0 || pollState is PollState.LimitVote),
                    showImage = data.setting.showImages,
                    showText = data.setting.showAnswerTitle == true,
                    isMarkVoteResult = isMarkVoteResult,
                    assertUrlPrefix = data.assetsPrefix,
                    onClick = when {
                        (data.isVotePollEnded ||
                                (!data.isVotePollEnded &&
                                        data.started != true &&
                                        !data.hasVoteButton) ||
                                execVoteButtonCount % 2 != 0) ||
                                pollState is PollState.LimitVote -> null

                        else -> fun() {
                            if (dataIndex != userSelectIndex && userSelectIndex != null)
                                isMarkVoteResult = false
                            userSelectIndex = dataIndex //重新赋值用户选中的索引
                        }
                    },
                    isSelected = userSelectIndex == dataIndex && !data.isVotePollEnded,
                )
            }
        }
        val hasFirstVoteInfoText = run {
            (data?.isVotePollEnded == true ||
                    (execVoteButtonCount > 0 && execVoteButtonCount % 2 != 0) ||
                    pollState is PollState.LimitVote) &&
                    data?.setting?.showResult == true && data.item?.itemTotal != null
        }
        if (hasFirstVoteInfoText) { //投票已结束，并且要展示投票结果的
            ZbText(
                modifier = Modifier
                    .applyTestTag("tv_vote_tip1")
                    .padding(
                        top = LocalDimens.current.dp30,
                        start = LocalDimens.current.dp20,
                        end = LocalDimens.current.dp20
                    )
                    .fillMaxWidth(),
                text = when {
                    data?.isVotePollEnded == true ->
                        stringResource(
                            R.string.app_user_vote_poll_total_count,
                            data.item?.itemTotal?.toLong() ?: 0L
                        )

                    else -> stringResource(
                        R.string.app_user_vote_poll_vote_count,
                        data?.item?.itemTotal?.toLong() ?: 0L
                    )
                },
                textAlign = TextAlign.Center,
                color = LocalColorPallet.current.textSecondary,
                type = TypographyType.Label2,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
        }
        if (((data?.isVotePollEnded == true ||
                    (execVoteButtonCount > 0 &&
                            execVoteButtonCount % 2 != 0) ||
                    data?.hasVoteButton != true) &&
                    voteTipMessage.isNotEmpty() &&
                    (data?.setting?.showResult != true ||
                            (data.setting.showResult && data.item?.itemTotal != null))) ||
            pollState is PollState.LimitVote //如果已经是被限制投票的状态了，应该展示限制投票的信息
        ) {
            ZbText(
                modifier = Modifier
                    .applyTestTag("tv_vote_tip2")
                    .padding(
                        top = when {
                            hasFirstVoteInfoText ->
                                LocalDimens.current.dp0

                            else -> LocalDimens.current.dp30
                        },
                        start = LocalDimens.current.dp20,
                        end = LocalDimens.current.dp20
                    )
                    .fillMaxWidth(),
                text = voteTipMessage,
                textAlign = TextAlign.Center,
                color = LocalColorPallet.current.textSecondary,
                type = TypographyType.Label2,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
        }
        if (data?.setting?.hasLinkButton == true || data?.hasVoteButton == true) {
            Row(
                modifier = Modifier
                    .padding(vertical = LocalDimens.current.dp16)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(
                    LocalDimens.current.dp16,
                    Alignment.CenterHorizontally
                ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (data.setting?.hasLinkButton == true &&
                    (data.isVotePollEnded || execVoteButtonCount % 2 != 0)
                ) {
                    Button(
                        modifier = Modifier.applyTestTag("btn_vote_other"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LocalColorPallet.current.buttonSecondaryDefault,
                            contentColor = LocalColorPallet.current.buttonSecondaryLabel
                        ),
                        contentPadding = PaddingValues(
                            horizontal = LocalDimens.current.dp16,
                            vertical = LocalDimens.current.dp8
                        ),
                        onClick = { event.onLinkButtonClick(data, data.setting.link) }
                    ) {
                        val voteLinkLabel = remember(useSimpleCNText, data.setting.linkLabel) {
                            val funIcu = VotePollSdk.simpleCN2TraditionalCN
                            if (!useSimpleCNText && funIcu != null) {
                                funIcu.invoke(data.setting.linkLabel ?: "")
                            } else data.setting.linkLabel ?: ""
                        }
                        ZbText(
                            text = voteLinkLabel,
                            type = TypographyType.Button1,
                            scaleType = with(typographyScaleType) { calculateForNewsList }
                        )
                    }
                }
                if (data.hasVoteButton && pollState !is PollState.LimitVote) { // 已结束的活动，不再展示投票的按钮
                    val isVotePollRequesting = remember { AtomicBoolean(false) }
                    Button(
                        modifier = Modifier
                            .applyTestTag(tag = "btn_exec_vote")
                            .alpha(if (userSelectIndex == null) 0.4f else 1.0f),
                        enabled = data.item?.answers
                            ?.indices
                            ?.contains(userSelectIndex) == true &&
                                pollState == PollState.ContinueVote,
                        colors = ButtonColors(
                            containerColor = LocalColorPallet.current.buttonPrimaryDefault,
                            contentColor = LocalColorPallet.current.buttonPrimaryLabel,
                            disabledContentColor = LocalColorPallet.current.buttonPrimaryLabel,
                            disabledContainerColor = LocalColorPallet.current.buttonPrimaryDefault
                        ),
                        contentPadding = PaddingValues(
                            horizontal = LocalDimens.current.dp16,
                            vertical = if (DeviceUtils.isTablet(context))
                                LocalDimens.current.dp8 else LocalDimens.current.dp6
                        ),
                        onClick = {
                            //如果执行过投票了，按钮会变成继续投票，再点击一次才能投票
                            val voteTitle = data.item?.name
                            if (execVoteButtonCount % 2 != 0) {
                                userSelectIndex = null //置空用户选中项目
                                execVoteButtonCount++ //变成偶数才能继续投票
                                enforceRefreshKeyForGridLayout =
                                    System.currentTimeMillis().toString()
                                event.onTrackVoteAgainClick(voteTitle, data)
                                return@Button
                            }
                            val voteInfo = data.item ?: return@Button
                            val voteAnswerItemInfo = voteInfo.answers
                                ?.getOrNull(userSelectIndex ?: return@Button)
                                ?: return@Button
                            if (isVotePollRequesting.get()) return@Button
                            isVotePollRequesting.set(true)
                            event.onExecVoteClick(
                                voteInfo.voteId to listOf(voteAnswerItemInfo),
                                data
                            ) { isVoteOk, _ ->
                                isVotePollRequesting.set(false)
                                if (isVoteOk) {
                                    isMarkVoteResult = true //需要标记投票结果
                                    execVoteButtonCount++ //标记执行了投票了
                                } else {
                                    isMarkVoteResult = true //需要标记投票结果
                                    execVoteButtonCount++ //标记执行了投票了
                                }
                            }
                            event.onTrackVoteClick(voteTitle, voteAnswerItemInfo.title, data)
                        },
                    ) {
                        ZbText(
                            text = stringResource(
                                if (execVoteButtonCount % 2 == 0)
                                    R.string.app_user_vote_poll_exec
                                else R.string.app_user_vote_poll_exec_again
                            ),
                            type = TypographyType.Button1,
                            scaleType = with(typographyScaleType) { calculateForNewsList }
                        )
                    }
                }
            }
        }
    }
    CardDividerView(
        borderConfig = borderInfo?.bottom,
        paddingHorizontal = config.pollCardHorizontalPadding
    )
}

/**
 * 展开式的GridView组件
 * @param modifier Modifier
 * @param enforceRefreshKey 强制刷新key
 * @param inputDataSource 数据源
 * @param itemContent 每个item的内容
 */
@Composable
private fun ExpandedGridView(
    modifier: Modifier = Modifier,
    enforceRefreshKey: String? = null,
    typographyScaleType: TypographyScaleType,
    inputDataSource: List<VoteAnswerItemInfo>,
    itemContent: @Composable BoxScope.(Int, VoteAnswerItemInfo) -> Unit
) {
    val context = LocalContext.current
    val gridSpacing = LocalDimens.current.dp13
    val gridColumnCount = remember(inputDataSource) {
        if (inputDataSource.size <= 2 ||
            !DeviceUtils.isTablet(context)
        ) 2 else 3 // 当总数大于2且是平板的时候，显示3栏
    }
    val dataSource = remember(
        inputDataSource,
        gridColumnCount
    ) { inputDataSource.chunked(gridColumnCount) }
    var gridViewContainerHeight by rememberSaveable(
        enforceRefreshKey,
        typographyScaleType,
        inputDataSource
    ) { mutableStateOf<Int?>(null) }
    var gridViewContainerWidth by rememberSaveable(typographyScaleType) { mutableStateOf<Int?>(null) }
    val gridSizeModifier = remember(enforceRefreshKey, gridViewContainerWidth) {
        if (gridViewContainerHeight == null ||
            gridViewContainerHeight!! < 0f
        ) Modifier else Modifier.defaultMinSize(
            minHeight = context.convertPx2dip(gridViewContainerHeight!!).toFloat().dp
        )
    }
    Column(
        modifier = Modifier
            .then(modifier)
            .then(gridSizeModifier)
            .onSizeChanged { size ->
                val containerHeight = size.height
                if (containerHeight > 0 &&
                    gridViewContainerHeight != containerHeight
                ) gridViewContainerHeight = containerHeight
                gridViewContainerWidth = size.width
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(gridSpacing)
    ) {
        if (gridViewContainerWidth == null) return@Column
        val everyGridWidth =
            (gridViewContainerWidth!! - dipToPixel(gridSpacing) * (gridColumnCount - 1)) / gridColumnCount
        dataSource.fastForEachIndexed { yIndex, rowItems ->
            if (yIndex * gridColumnCount >= inputDataSource.size)
                return@fastForEachIndexed //已经越界了，不再进行绘制
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(
                    space = gridSpacing,
                    alignment = Alignment.CenterHorizontally
                ),
                verticalAlignment = Alignment.Top
            ) {
                rowItems.fastForEachIndexed { xIndex, item ->
                    Box(
                        modifier = Modifier.width(pixelToDip(everyGridWidth))
                    ) { itemContent(yIndex * gridColumnCount + xIndex, item) }
                }
            }
        }
    }
}

/**
 * 投票卡片视图状态管理类接口
 * @param context 上下文对象
 **/
abstract class VotePollViewEventHandler {

    /**
     * 投票标题点击事件
     * @param data 投票信息
     * @param url 关联的链接
     */
    open fun onVoteTitleClick(data: VoteDataInfo?, url: String?) {}

    /**
     * 投票扩展文字链接点击事件
     * @param data 投票信息
     * @param url 关联的链接
     */
    open fun onVoteExtLinkClick(data: VoteDataInfo?, url: String?) {}

    /**
     * 去投票旁边的扩展按钮的点击事件，一般为：去抽奖
     * @param data 投票信息
     * @param url 关联的链接
     */
    open fun onLinkButtonClick(data: VoteDataInfo?, url: String?) {}

    /** 投票成功 **/
    open fun onVotePollSuccess(
        data: VoteDataInfo?,
        selectedItems: List<VoteAnswerItemInfo>?,
        voteCount: Int?
    ) {
    }

    /** 投票失败 **/
    open fun onVotePollFailed() {}

    /**
     * 发起投票按钮的点击事件
     * @param data 投票信息 投票ID:投票选项
     * @param voteData 投票数据
     * @param onPollVoted 投票结果回调, params:是否投票成功 是否达到投票限制
     */
    internal open fun onExecVoteClick(
        data: Pair<String?, List<VoteAnswerItemInfo>>,
        voteData: VoteDataInfo?,
        onPollVoted: (Boolean, Boolean) -> Unit
    ) {
    }

    /**
     * 投票选项加载成功
     * @param pageType 页面类型
     * @param data 投票数据
     */
    open fun onVoteOptionsLoaded(pageType: String?, data: VoteDataInfo?) {}

    /**
     * 投票选项加载失败
     * @param voteId 投票ID
     * @param pageType 页面类型
     */
    open fun onVoteOptionsLoadError(voteId: String?, pageType: String?) {}

    /**
     * 投票点击事件埋点
     * @param voteCampaignName 投票活动名称
     * @param selectedOptionTitle 投票选项名称
     * @param voteDataInfo 投票信息
     */
    open fun onTrackVoteClick(
        voteCampaignName: String?,
        selectedOptionTitle: String?,
        voteDataInfo: VoteDataInfo?
    ) {
    }

    /**
     * 再次投票的点击事件埋点
     * @param voteCampaignName 投票活动名称
     * @param voteDataInfo 投票信息
     */
    open fun onTrackVoteAgainClick(voteCampaignName: String?, voteDataInfo: VoteDataInfo?) {}

}

/** 效果预览方法 **/
@Composable
@Preview(name = "投票组件-浅色")
@Preview(name = "投票组件-深色", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVotePollView() = DefaultPreview {
    InternalVotePollView(
        data = VoteDataInfo(
            title = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
            item = VoteQuestionInfo(
                name = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
                answers = listOf(
                    VoteAnswerItemInfo(
                        img = "a",
                        title = "会。DeepSeek重新定义AI技术发展，让中国弯道超车"
                    ),
                    VoteAnswerItemInfo(
                        title = "不一定。它是中国科技重大进步，但影响是渐进的"
                    ),
                    VoteAnswerItemInfo(
                        title = "不会。它的影响被夸大，中国在AI领域与美国有很大差距"
                    ),
                    VoteAnswerItemInfo(
                        title = "现在下结论为时尚早，还需更多评测和反馈"
                    )
                )
            ),
            showTime = true, startTime = 1752722176811, endTime = 1752733176811
        )
    )
}

/** 效果预览方法 **/
@Composable
@Preview(name = "投票组件-浅色")
@Preview(name = "投票组件-深色", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVotePollView2() = DefaultPreview {
    InternalVotePollView(
        data = VoteDataInfo(
            title = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
            item = VoteQuestionInfo(
                name = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
                link = "https://www.baidu.com",
                answers = listOf(
                    VoteAnswerItemInfo(
                        img = "https://www.baidu.com/a.png",
                        title = "会"
                    ),
                    VoteAnswerItemInfo(
                        img = "https://www.baidu.com/a.png",
                        title = "不一定"
                    ),
                    VoteAnswerItemInfo(
                        img = "https://www.baidu.com/a.png",
                        title = "不会"
                    ),
                    VoteAnswerItemInfo(
                        img = "https://www.baidu.com/a.png",
                        title = "下结论为时尚早"
                    )
                )
            ),
            setting = VoteSettingInfo(showImages = true, linkLabel = "去抽奖", link = "ccc")
        )
    )
}