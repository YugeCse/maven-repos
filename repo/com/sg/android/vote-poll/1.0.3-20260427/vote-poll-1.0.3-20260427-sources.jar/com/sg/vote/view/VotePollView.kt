package com.sg.vote.view

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_YES
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sg.common.theme.SphAppTheme
import com.sg.common.theme.TypographyScaleType
import com.sg.vote.R
import com.sg.vote.VotePollSdk
import com.sg.vote.api.ApiCallback
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.beans.VoteQuestionInfo
import com.sg.vote.data.view.BorderConfig
import com.sg.vote.data.view.BorderInfo
import com.sg.vote.data.view.LocalVoteCardViewConfig
import com.sg.vote.log.LogUtils
import com.sg.vote.utils.ObserveAppLocale
import com.sg.vote.utils.isTraditionalChineseCompat
import com.sg.vote.utils.toJsonObject
import com.sg.vote.utils.toJsonString
import com.sg.vote.view.preview.DefaultPreview
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * 投票视图UI
 * @param modifier Modifier
 * @param uniqueKey 唯一标识，强制刷新时请改变它
 * @param pageType 页面类型，用于区分不同的投票
 * @param data 投票数据
 * @param horizontalPadding 水平内边距
 * @param typographyScaleType 字号类型
 * @param useDarkTheme 是否使用暗黑主题
 * @param border 边框信息
 * @param eventHandler 事件处理
 */
@Composable
fun VotePollView(
    modifier: Modifier = Modifier,
    uniqueKey: String? = null,
    useDarkTheme: Boolean = isSystemInDarkTheme(),
    typographyScaleType: TypographyScaleType = TypographyScaleType.Standard,
    border: BorderInfo? = null,
    horizontalPadding: Dp = 20.dp,
    pageType: String? = null,
    data: VoteDataInfo? = null,
    eventHandler: VotePollViewEventHandler? = null
) {
    val coroutineScope = rememberCoroutineScope()
    val state = rememberInnerVotePollViewSaveableState(pageType, data)
    val event = remember(coroutineScope, state, eventHandler) {
        InnerVotePollViewEventHandler(coroutineScope, state, eventHandler)
    }
    val voteData by state.voteData.collectAsStateWithLifecycle()
    var forceRefreshKey by remember(uniqueKey) { mutableStateOf(uniqueKey) }
    var useSimpleCNText by remember { mutableStateOf(VotePollSdk.useSimpleCN) }
    LifecycleResumeEffect(state) {
        state.syncUserVoteCount()
        onPauseOrDispose { }
    }
    DisposableEffect(uniqueKey, state, eventHandler) {
        val job = coroutineScope.launch {
            val isOk = state.getPollOptions()
            if (isOk)
                eventHandler?.onVoteOptionsLoaded(state.pageType, state.voteData.value)
            else eventHandler?.onVoteOptionsLoadError(state.voteId, state.pageType)
        }
        onDispose { job.cancel() }
    }
    ObserveAppLocale { newLocale ->
        val useSimpleCN = !newLocale.isTraditionalChineseCompat()
        if (VotePollSdk.useSimpleCN != useSimpleCN) {
            VotePollSdk.useSimpleCN = useSimpleCN
            useSimpleCNText = useSimpleCN //更新简繁转换的使用属性
        }
    }
    if (voteData != null &&
        voteData?.hasFullData == true &&
        voteData?.isVotePollStarted == true
    ) {
        SphAppTheme(
            fontFamily = VotePollSdk.fontFamily,
            useDarkTheme = useDarkTheme
        ) {
            val baseConfig = LocalVoteCardViewConfig.current
            val useDarkTheme = when {
                LocalInspectionMode.current ->
                    isSystemInDarkTheme()

                else -> baseConfig.useDarkTheme
            }
            val newConfig = remember(
                baseConfig, useSimpleCNText, useDarkTheme,
                typographyScaleType, border, horizontalPadding
            ) {
                baseConfig.copy(
                    useDarkTheme = useDarkTheme,
                    useSimpleCN = useSimpleCNText,
                    typographyScaleType = typographyScaleType,
                    pollCardHorizontalPadding = horizontalPadding,
                    pollCardViewBorder = border ?: baseConfig.pollCardViewBorder,
                )
            }
            CompositionLocalProvider(LocalVoteCardViewConfig provides newConfig) {
                key(forceRefreshKey) {
                    InternalVotePollView(
                        event = event,
                        data = voteData,
                        modifier = Modifier.then(modifier)
                    )
                }
            }
        }
    }
}

/**
 * 投票视图UI的状态类
 * @param context 上下文对象
 * @param pageType 页面类型，用于区分不同的投票
 * @param voteDataInfo 投票数据
 */
internal class InnerVotePollViewState(
    private val context: Context,
    val pageType: String? = null,
    private val voteDataInfo: VoteDataInfo? = null
) {

    companion object {

        private const val TAG: String = "VotePollViewState"

    }

    /** 投票ID **/
    var voteId: String? = null
        private set

    /** 投票数据 **/
    val voteData = MutableStateFlow<VoteDataInfo?>(null)

    init {
        if (voteDataInfo?.hasFullData == true) {
            voteId = voteDataInfo.id
            voteData.value = voteDataInfo
        } else {
            voteId = voteDataInfo?.id
            voteData.value = null
        }
    }

    /** 获取投票相关数据 **/
    internal suspend fun getPollOptions(): Boolean {
        if (voteData.value != null &&
            voteData.value?.hasFullData == true
        ) return true //不需要获取投票数据
        try {
            val callback = VotePollSdk
                .getPollOptions(voteId = voteId, pageType = pageType)
            if (callback is ApiCallback.Success) {
                voteData.value = callback.dataResult?.also { v ->
                    v.item?.userCount?.let { userCount ->
                        VotePollSdk.updateVoteRecord(
                            ssid = VotePollSdk.customUserId,
                            voteId = voteId,
                            voteCount = userCount
                        )
                    }
                }
                val nowVoteData = voteData.value?.copy()
                if (nowVoteData?.setting?.showResult == true &&
                    nowVoteData.isVotePollEnded &&
                    nowVoteData.item?.itemTotal == null
                ) getVoteDataStatistics() //没有统计结果，当需要统计结果的，拉取统计结果
            }
            return callback is ApiCallback.Success
        } catch (e: Exception) {
            LogUtils.log4i(TAG, "getPollOptions: ${e.message}")
            return false
        }
    }

    /**
     * 发起投票
     * @param answers 投票选项ID
     * @return 是否投票成功 to 是否达到投票限制
     */
    internal suspend fun execVote(answers: List<String>): Pair<Boolean, Boolean> {
        try {
            if (voteId.isNullOrEmpty() ||
                answers.isEmpty()
            ) return false to false//不满足要求，不提交投票
            val callback = VotePollSdk.submitPoll(
                voteId = voteId,
                pageType = pageType,
                site = VotePollSdk.site,
                answers = answers
            )
            if (callback is ApiCallback.Success) {
                val origin = voteData.value?.copy()
                var voteSettings = origin?.setting
                voteData.value = callback.dataResult?.let {
                    if (it.setting != null) {
                        it.also { voteSettings = it.setting }
                    } else it.copy(setting = voteSettings)
                }?.also { v ->
                    v.item?.userCount?.let { userCount ->
                        VotePollSdk.updateVoteRecord(
                            ssid = VotePollSdk.customUserId,
                            voteId = voteId,
                            voteCount = userCount
                        )
                    }
                }
                if (voteSettings?.showResult == true &&
                    (voteData.value?.item?.itemTotal == null ||
                            voteData.value?.item?.answers?.any { it.voteCount == null } == true)
                ) getVoteDataStatistics() //没有统计结果，当需要统计结果的，拉取统计结果
                return true to false
            }
            return false to ((callback?.message
                ?: callback?.extraMessage)
                ?.contains(context.run {
                    val config = Configuration(resources.configuration)
                        .apply {
                            @Suppress("DEPRECATION")
                            if (Build.VERSION.SDK_INT >= 36)
                                setLocale(Locale.of("zh", "CN"))
                            else setLocale(Locale("zh", "CN"))
                        }
                    createConfigurationContext(config)
                }.getString(R.string.app_user_vote_poll_limit_vote_text)) == true)
        } catch (e: Exception) {
            LogUtils.log4i(TAG, "execVote: ${e.message}")
            return false to false
        }
    }

    /** 获取投票统计结果数据 **/
    internal suspend fun getVoteDataStatistics() {
        runCatching {
            if (voteId.isNullOrEmpty()) return
            val callback = VotePollSdk.getPollResult(voteId)
            if (callback is ApiCallback.Success) {
                val origin = voteData.value?.copy()
                voteData.value = callback.dataResult?.let {
                    if (it.setting != null) it
                    else it.copy(setting = origin?.setting)
                }?.also { v ->
                    v.item?.userCount?.let { userCount ->
                        VotePollSdk.updateVoteRecord(
                            ssid = VotePollSdk.customUserId,
                            voteId = voteId,
                            voteCount = userCount
                        )
                    }
                }
            }
        }.onFailure { ex -> LogUtils.log4i(TAG, "getVoteDataStatistics: ${ex.message}") }
    }

    /** 同步用户的投票数据信息 **/
    fun syncUserVoteCount() {
        val ssid = VotePollSdk.customUserId
        val vData = voteData.value?.copy()
        val voteId = vData?.id
        if (ssid.isEmpty() || voteId.isNullOrEmpty())
            return
        VotePollSdk.getVoteRecords(
            ssid = ssid,
            voteId = voteId
        )?.let { recordInfo ->
            voteData.value = vData.copy(
                item = vData.item?.copy(userCount = recordInfo.voteCount)
            )
        }
    }

}

/**
 * 投票视图事件处理类
 * @param coroutineScope 协程作用域
 * @param state 投票视图状态
 * @param eventHandler 事件处理
 */
internal class InnerVotePollViewEventHandler(
    private val coroutineScope: CoroutineScope,
    private val state: InnerVotePollViewState,
    private val eventHandler: VotePollViewEventHandler?,
) : VotePollViewEventHandler() {

    override fun onVoteOptionsLoaded(pageType: String?, data: VoteDataInfo?) {
        super.onVoteOptionsLoaded(pageType, data)
        eventHandler?.onVoteOptionsLoaded(pageType, data)
    }

    override fun onVoteOptionsLoadError(voteId: String?, pageType: String?) {
        super.onVoteOptionsLoadError(voteId, pageType)
        eventHandler?.onVoteOptionsLoadError(voteId, pageType)
    }

    override fun onVoteTitleClick(data: VoteDataInfo?, url: String?) {
        super.onVoteTitleClick(data, url)
        eventHandler?.onVoteTitleClick(data, url)
    }

    override fun onVoteExtLinkClick(data: VoteDataInfo?, url: String?) {
        super.onVoteExtLinkClick(data, url)
        eventHandler?.onVoteExtLinkClick(data, url)
    }

    override fun onLinkButtonClick(data: VoteDataInfo?, url: String?) {
        super.onLinkButtonClick(data, url)
        eventHandler?.onLinkButtonClick(data, url)
    }

    override fun onExecVoteClick(
        data: Pair<String?, List<VoteAnswerItemInfo>>,
        voteData: VoteDataInfo?,
        onPollVoted: (Boolean, Boolean) -> Unit
    ) {
        super.onExecVoteClick(data, voteData, onPollVoted)
        coroutineScope.launch {
            val result =
                state.execVote(data.second.mapNotNull { it.id })
            withContext(Dispatchers.Main) {
                if (result.first)
                    onVotePollSuccess(
                        data = voteData,
                        selectedItems = data.second,
                        voteCount = voteData?.item?.userCount?.plus(1) ?: 1
                    )
                else onVotePollFailed()
                onPollVoted(result.first, result.second) //投票的执行结果反馈回去
            }
        }
        eventHandler?.onExecVoteClick(data, voteData, onPollVoted)
    }

    override fun onVotePollFailed() {
        super.onVotePollFailed()
        eventHandler?.onVotePollFailed()
    }

    override fun onVotePollSuccess(
        data: VoteDataInfo?,
        selectedItems: List<VoteAnswerItemInfo>?,
        voteCount: Int?
    ) {
        super.onVotePollSuccess(
            data, selectedItems, voteCount
        )
        eventHandler?.onVotePollSuccess(data, selectedItems, voteCount)
    }

    override fun onTrackVoteClick(
        voteCampaignName: String?,
        selectedOptionTitle: String?,
        voteDataInfo: VoteDataInfo?
    ) {
        super.onTrackVoteClick(voteCampaignName, selectedOptionTitle, voteDataInfo)
        eventHandler?.onTrackVoteClick(voteCampaignName, selectedOptionTitle, voteDataInfo)
    }

    override fun onTrackVoteAgainClick(
        voteCampaignName: String?,
        voteDataInfo: VoteDataInfo?
    ) {
        super.onTrackVoteAgainClick(voteCampaignName, voteDataInfo)
        eventHandler?.onTrackVoteAgainClick(voteCampaignName, voteDataInfo)
    }
}

/**
 * 投票视图UI的状态管理类
 * @param pageType 页面类型，用于区分不同的投票
 * @param voteDataInfo 投票数据
 */
@Composable
internal fun rememberInnerVotePollViewSaveableState(
    pageType: String? = null,
    voteDataInfo: VoteDataInfo? = null
): InnerVotePollViewState {
    val context = LocalContext.current
    val saver = Saver<InnerVotePollViewState, Map<String, String?>>(
        save = { state ->
            mapOf(
                "pageType" to state.pageType,
                "voteData" to state.voteData.value?.toJsonString()
            )
        },
        restore = { map ->
            InnerVotePollViewState(
                context = context,
                pageType = map["pageType"],
                voteDataInfo = map["voteData"]?.toJsonObject()
            )
        }
    )
    return rememberSaveable(pageType, voteDataInfo, saver = saver) {
        InnerVotePollViewState(context = context, pageType = pageType, voteDataInfo = voteDataInfo)
    }
}

@Composable
@Preview
@Preview(uiMode = UI_MODE_NIGHT_YES)
private fun PreviewVotePollView() = DefaultPreview {
    VotePollView(
        useDarkTheme = isSystemInDarkTheme(),
        border = BorderInfo(
            top = BorderConfig(height = 1),
            bottom = BorderConfig(height = 1),
        ),
        data = VoteDataInfo(
            title = "投票标题",
            item = VoteQuestionInfo(
                name = "投票问题",
                answers = listOf(
                    VoteAnswerItemInfo(
                        img = "https://www.baidu.com/a.png",
                        title = "会"
                    ),
                    VoteAnswerItemInfo(
                        img = "https://www.baidu.com/a.png",
                        title = "不一定"
                    )
                )
            ),
            showTime = true,
            startTime = System.currentTimeMillis(),
            endTime = System.currentTimeMillis() + 1752722176811
        )
    )
}