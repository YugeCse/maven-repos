package com.sg.vote.api

import com.sg.vote.VotePollSdk
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.extras.PageType
import com.sg.vote.data.view.Site
import com.sg.vote.log.LogUtils
import com.sg.vote.utils.toJsonString
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.HttpURLConnection
import kotlin.coroutines.suspendCoroutine

/** 投票接口仓库接口类 **/
internal interface IVotePollApiRepo {

    /**
     * 获取投票选项
     * @param voteId 投票ID，与pageType必须存在其一
     * @param pageType 页面类型，与voteId必须存在其一
     * @param callback 回调
     * @return 发起的网络请求的call对象
     */
    fun getPollOptions(
        voteId: String? = null,
        pageType: String? = null,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call?

    /**
     * 获取投票选项
     * @param voteId 投票ID，与pageType必须存在其一
     * @param pageType 页面类型，与voteId必须存在其一
     * @param callback 回调
     * @return 发起的网络请求的call对象
     */
    fun getPollOptions(
        voteId: String? = null,
        pageType: PageType? = null,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call?

    /**
     * 获取投票结果
     * @param voteId 投票ID
     * @param callback 回调
     * @return 发起的网络请求的call对象
     */
    fun getPollResult(
        voteId: String?,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call?

    /**
     * 执行投票
     * @param voteId 投票ID
     * @param pageType 投票页面
     * @param site 网站，传值：zbcom，zbsg
     * @param answers 投票选项ID集合
     * @param callback 回调
     * @return 发起的网络请求的call对象
     */
    fun submitPoll(
        voteId: String?,
        pageType: String?,
        site: Site? = Site.Zbcom,
        answers: List<String?>,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call?

    /**
     * 执行投票
     * @param voteId 投票ID
     * @param pageType 投票页面
     * @param site 网站，传值：zbcom，zbsg
     * @param answers 投票选项ID集合
     * @param callback 回调
     * @return 发起的网络请求的call对象
     */
    fun submitPoll(
        voteId: String?,
        pageType: PageType?,
        site: Site? = Site.Zbcom,
        answers: List<String?>,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call? = submitPoll(voteId, pageType?.value, site, answers, callback)

    /**
     * 获取投票选项（协程方法）
     * @param voteId 投票ID，与pageType必须存在其一
     * @param pageType 页面类型，与voteId必须存在其一
     */
    suspend fun getPollOptions(
        voteId: String? = null,
        pageType: String? = null,
    ): ApiCallback<VoteDataInfo>? {
        return suspendCoroutine { continuation ->
            getPollOptions(
                voteId = voteId,
                pageType = pageType,
            ) { callback ->
                continuation.resumeWith(Result.success(callback))
            }
        }
    }

    /**
     * 获取投票选项（协程方法）
     * @param voteId 投票ID，与pageType必须存在其一
     * @param pageType 页面类型，与voteId必须存在其一
     */
    suspend fun getPollOptions(
        voteId: String? = null,
        pageType: PageType? = null,
    ): ApiCallback<VoteDataInfo>? {
        return suspendCoroutine { continuation ->
            getPollOptions(
                voteId = voteId,
                pageType = pageType,
            ) { callback ->
                continuation.resumeWith(Result.success(callback))
            }
        }
    }

    /**
     * 获取投票结果（协程方法）
     * @param voteId 投票ID
     */
    suspend fun getPollResult(voteId: String?): ApiCallback<VoteDataInfo>? {
        return suspendCoroutine { continuation ->
            getPollResult(voteId = voteId) { callback ->
                continuation.resumeWith(Result.success(callback))
            }
        }
    }

    /**
     * 执行投票（协程方法）
     * @param voteId 投票ID
     * @param pageType 投票页面
     * @param site 网站，zbcom/zbsg
     * @param answers 投票选项ID集合
     */
    suspend fun submitPoll(
        voteId: String?,
        pageType: String?,
        site: Site?,
        answers: List<String?>,
    ): ApiCallback<VoteDataInfo>? {
        return suspendCoroutine { continuation ->
            submitPoll(
                voteId = voteId,
                pageType = pageType,
                site = site,
                answers = answers
            ) { callback ->
                continuation.resumeWith(Result.success(callback))
            }
        }
    }


    /**
     * 执行投票（协程方法）
     * @param voteId 投票ID
     * @param pageType 投票页面
     * @param site 网站，zbcom/zbsg
     * @param answers 投票选项ID集合
     */
    suspend fun submitPoll(
        voteId: String?,
        pageType: PageType?,
        site: Site?,
        answers: List<String?>,
    ): ApiCallback<VoteDataInfo>? = submitPoll(voteId, pageType?.value, site, answers)

}


/**
 * 投票API仓库
 * @author huangzhongyu@sph.com.sg
 */
internal class VotePollApiRepoImpl private constructor() : IVotePollApiRepo {

    companion object {

        private val instance by lazy { VotePollApiRepoImpl() }

        /** 获取单例对象 **/
        @JvmStatic
        fun singleton(): VotePollApiRepoImpl = instance

    }

    /** httpApi对象 **/
    private val httpApi by lazy { VoteHttpApi.singleton() }

    /**
     * 获取投票数据信息
     * @param voteId 投票ID，与pageType必须存在其一
     * @param pageType 页面类型，与voteId必须存在其一
     */
    override fun getPollOptions(
        voteId: String?,
        pageType: String?,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call? {
        if (voteId.isNullOrEmpty() && pageType == null) {
            callback(
                ApiCallback.Fail(
                    code = HttpURLConnection.HTTP_BAD_REQUEST.toString(),
                    message = "voteId or pageType is required"
                )
            )
            return null
        }
        if (VotePollSdk.customUserId.isEmpty()) {
            callback(
                ApiCallback.Fail(
                    code = HttpURLConnection.HTTP_BAD_REQUEST.toString(),
                    message = "userId is required"
                )
            )
            return null
        }
        return httpApi.getAsync<VoteDataInfo>(
            url = VoteApiUrls.getPollOptions,
            queryParams = mutableMapOf<String, String?>(
                "platform" to "Android",
                "version" to VotePollSdk.version
            ).apply {
                if (!pageType.isNullOrEmpty())
                    put("pageType", pageType)
                if (!voteId.isNullOrEmpty()) put("voteId", voteId)
                put("userId", VotePollSdk.customUserId)
            },
            callback = callback
        ).also { LogUtils.log4i("VotePollApiRepo", "getPollOptions: $voteId, $pageType") }
    }

    override fun getPollOptions(
        voteId: String?,
        pageType: PageType?,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call? = getPollOptions(
        voteId = voteId,
        pageType = pageType?.value,
        callback = callback
    )

    /**
     * 获取投票结果
     * @param voteId 投票ID
     * @param callback 回调
     */
    override fun getPollResult(
        voteId: String?,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call? {
        if (VotePollSdk.customUserId.isEmpty() || voteId.isNullOrEmpty()) {
            callback(
                ApiCallback.Fail(
                    code = HttpURLConnection.HTTP_BAD_REQUEST.toString(),
                    message = "userId and voteId is required"
                )
            )
            return null
        }
        return httpApi.getAsync<VoteDataInfo>(
            url = VoteApiUrls.getVotePollResult(voteId),
            queryParams = mapOf(
                "voteId" to voteId,
                "userId" to VotePollSdk.customUserId,
                "platform" to "Android",
                "version" to VotePollSdk.version,
            ),
            callback = callback
        ).also { LogUtils.log4i("VotePollApiRepo", "getPollResult: $voteId") }
    }

    /**
     * 执行投票
     * @param voteId 投票ID
     * @param pageType 投票页面
     * @param site 网站，zbcom/zbsg
     * @param answers 投票选项ID
     * @param callback 回调
     */
    override fun submitPoll(
        voteId: String?,
        pageType: String?,
        site: Site?,
        answers: List<String?>,
        callback: (ApiCallback<VoteDataInfo>?) -> Unit
    ): Call? {
        if (VotePollSdk.customUserId.isEmpty()) {
            callback(
                ApiCallback.Fail(
                    code = HttpURLConnection.HTTP_BAD_REQUEST.toString(),
                    message = "userId is required"
                )
            )
            return null
        }
        if (voteId.isNullOrEmpty() && pageType == null) {
            callback(
                ApiCallback.Fail(
                    code = HttpURLConnection.HTTP_BAD_REQUEST.toString(),
                    message = "voteId or pageType is required"
                )
            )
            return null
        }
        return httpApi.postAsync<VoteDataInfo>(
            url = VoteApiUrls.submitPoll(voteId),
            requestBody =
                mutableMapOf(
                    "platform" to "Android",
                    "version" to VotePollSdk.version,
                    "userId" to VotePollSdk.customUserId,
                    "pageType" to pageType,
                    "voteId" to voteId,
                    "site" to site?.value,
                    "answers" to answers
                ).toJsonString()
                    ?.toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull()),
            callback = callback
        ).also { LogUtils.log4i("VotePollApiRepo", "submitPoll: $voteId, $site, $answers") }
    }
}