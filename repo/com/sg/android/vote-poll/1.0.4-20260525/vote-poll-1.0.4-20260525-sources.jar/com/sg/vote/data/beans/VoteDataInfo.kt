package com.sg.vote.data.beans

import android.content.Context
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.sg.vote.R
import com.sg.vote.data.extras.PollState
import com.sg.vote.utils.toDateTimeText
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable
import kotlin.math.min

/**
 * 投票数据实体类（包含投票配置、投票问题及其答案）
 * @param id 投票ID
 * @param title 投票标题
 * @param description 投票描述
 * @param eventCategory 活动分类
 * @param linkUrl 扩展文本的链接
 * @param linkText 扩展文本
 * @param assetsPrefix 资源文件路径前缀，投票的图片路径可能需要拼接这个
 * @param startTime 开始时间
 * @param endTime 结束时间
 * @param started 是否已经开始
 * @param stopped 是否已经停止
 * @param ended 是否已经结束
 * @param status 状态（1正常，2暂停，3删除）
 * @param showTime 是否展示活动时间
 * @param item 投票问题及选项数据
 * @param setting 投票的配置信息，是否显示结果、抽奖链接按钮、怎么展示投票布局等(查询统计的接口不会返回该字段)
 */
@Parcelize
@Serializable
data class VoteDataInfo(

    @field:SerializedName("id")
    val id: String? = null,

    @field:SerializedName("title")
    val title: String? = null,

    @field:SerializedName("description")
    val description: String? = null,

    @field:SerializedName("assetsPrefix")
    val assetsPrefix: String? = null,

    @field:SerializedName("eventCategory")
    val eventCategory: String? = null,

    @field:SerializedName("linkText")
    val linkText: String? = null,

    @field:SerializedName("linkUrl")
    val linkUrl: String? = null,

    @field:SerializedName("startTime")
    val startTime: Long? = null,

    @field:SerializedName("endTime")
    val endTime: Long? = null,

    @field:SerializedName("stopped")
    val stopped: Boolean? = null,

    @field:SerializedName("started")
    val started: Boolean? = null,

    @field:SerializedName("ended")
    val ended: Boolean? = null,

    @field:SerializedName("status")
    val status: Int? = null,

    @field:SerializedName("showTime")
    val showTime: Boolean? = null,

    @field:SerializedName("item")
    val item: VoteQuestionInfo? = null,

    @field:SerializedName("setting")
    val setting: VoteSettingInfo? = null,
) : Parcelable {

    /** 是否有完整的投票数据 **/
    val hasFullData: Boolean
        get() = !id.isNullOrEmpty() && !item?.answers.isNullOrEmpty()

    /** 获取投票活动是否已经开始 **/
    val isVotePollStarted: Boolean
        get() {
            return (started == true || (startTime != null &&
                    startTime > 0L &&
                    startTime <= System.currentTimeMillis()))
        }

    /** 获取投票活动是否已经结束 **/
    val isVotePollEnded: Boolean
        get() {
            return ended == true || stopped == true ||
                    (endTime != null &&
                            endTime > 0L &&
                            endTime <= System.currentTimeMillis())
        }

    /** 获取投票活动是否有效 **/
    val isVotePollActive: Boolean
        get() = isVotePollStarted && !isVotePollEnded

    /** 是否有投票按钮, 通过判断投票限制和用户投票次数来判断 **/
    val hasVoteButton: Boolean
        get() {
            if (isVotePollEnded)
                return false //投票结束的，投票按钮不可用
            if (setting?.limitType.isNullOrEmpty() ||
                setting.limitType == "no_limit"
            ) return true
            if (setting.limitType == "daily_limit" ||
                setting.limitType == "total_limit"
            ) {
                return true //(setting.limit ?: 0) > (item?.userCount ?: 0)
            }
            return false
        }

    /** 获取投票活动的活动时间, 时间格式：yyyy-MM-dd~yyyy-MM-dd **/
    val activityTime: String?
        get() {
            val startTimeText =
                startTime?.toDateTimeText("yyyy-MM-dd") ?: return null
            val endedTimeText =
                endTime?.toDateTimeText("yyyy-MM-dd") ?: return null
            return "$startTimeText~$endedTimeText"
        }

}

/** 投票是否已经达到了限制状态 **/
val VoteDataInfo.isVoteLimitState: Boolean
    get() {
        if (isVotePollEnded) return false
        val hasVoteCount =
            min(setting?.limit ?: 0, item?.userCount ?: 0)
        if (setting?.limitType == "daily_limit") {
            return hasVoteCount >= (setting.limit ?: 0)
        }
        if (setting?.limitType == "total_limit") {
            return hasVoteCount >= (setting.limit ?: 0)
        }
        return false
    }

/**
 * 获取投票相关的显示文案信息
 * @param context 上下文对象
 * @return Pair<String, PollState> 提示信息 to [PollState]
 */
fun VoteDataInfo.getVoteLimitDescriptionText(context: Context): Pair<String, PollState> {
    if (isVotePollEnded)
        return context.getString(R.string.app_user_vote_poll_ended) to PollState.EndedVote
    val hasVoteCount =
        min(setting?.limit ?: 0, item?.userCount ?: 0)
    if (setting?.limitType == "daily_limit") {
        if (hasVoteCount < (setting.limit ?: 0)) {
            return context.getString(
                R.string.app_user_vote_poll_count,
                hasVoteCount,
                (setting.limit ?: 0) - hasVoteCount,
                setting.resultText ?: ""
            ) to PollState.ContinueVote
        }
        return context.getString(
            R.string.app_user_vote_poll_limit,
            (setting.limit ?: 0),
            setting.resultText ?: ""
        ) to PollState.LimitVote
    }
    if (setting?.limitType == "total_limit") {
        // if (setting?.limit == 1) {
        //     return context.getString(R.string.app_user_vote_poll_thanks)
        // }
        if (hasVoteCount < (setting.limit ?: 0)) {
            return context.getString(
                R.string.app_user_vote_poll_thanks_count,
                hasVoteCount,
                (setting.limit ?: 0) - hasVoteCount,
                setting.resultText ?: ""
            ) to PollState.ContinueVote
        }
        return context.getString(
            R.string.app_user_vote_poll_limit_vote,
            (setting.limit ?: 0),
            setting.resultText ?: ""
        ) to PollState.LimitVote
    }
    return context.getString(
        R.string.app_user_vote_poll_thanks_with_message,
        setting?.resultText ?: ""
    ) to PollState.ContinueVote
}
