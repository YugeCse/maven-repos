package com.sg.vote.view.options

import android.annotation.SuppressLint
import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.sg.common.theme.LocalColorPallet
import com.sg.common.theme.LocalDimens
import com.sg.common.theme.TypographyScaleType.Companion.calculateForNewsList
import com.sg.common.theme.TypographyType
import com.sg.vote.R
import com.sg.vote.VotePollSdk
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.view.LocalVoteCardViewConfig
import com.sg.vote.utils.applyTestTag
import com.sg.vote.utils.rememberAsyncImagePlaceholder
import com.sg.vote.view.preview.DefaultPreview
import com.sg.vote.view.zaobao.ZbCheckBox
import com.sg.vote.view.zaobao.ZbText

/**
 * 投票表格选项视图
 * @param modifier Modifier
 * @param itemIndex 选项下标
 * @param showImage 是否显示图片
 * @param voteTotalCount 投票总数
 * @param assertUrlPrefix 资产地址前缀
 * @param data 选项信息
 * @param showResult 是否显示结果
 * @param isMarkVoteResult 是否标记投票结果
 * @param isSelected 是否选中
 * @param onClick 点击事件
 */
@SuppressLint("DefaultLocale", "LocalContextGetResourceValueCall")
@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun InternalVoteOptionGridItemView(
    modifier: Modifier = Modifier,
    itemIndex: Int? = 0,
    showImage: Boolean = true,
    showText: Boolean = true,
    voteTotalCount: Long? = 0L,
    data: VoteAnswerItemInfo,
    showResult: Boolean = false,
    isMarkVoteResult: Boolean = false,
    assertUrlPrefix: String? = null,
    isSelected: Boolean = false,
    onClick: (() -> Unit)? = {}
) {
    val config = LocalVoteCardViewConfig.current
    val useSimpleCNText = remember(config) { config.useSimpleCN } //是否使用简体中文
    val typographyScaleType = remember(config) { config.typographyScaleType }
    Box(
        Modifier
            .applyTestTag("vote_grid_item_view")
            .then(modifier)
            .clip(RoundedCornerShape(LocalDimens.current.dp4))
            .background(LocalColorPallet.current.backgroundPrimary)
            .border(
                LocalDimens.current.dp2,
                if (isSelected)
                    LocalColorPallet.current.dividerBrand
                else if (showText) LocalColorPallet.current.dividerPrimary
                else Color.Transparent,
                RoundedCornerShape(LocalDimens.current.dp4)
            )
            .run { if (onClick == null) this else clickable { onClick() } }
            .padding(bottom = if (showText) LocalDimens.current.dp6 else 0.dp)
    ) {
        Column(Modifier.fillMaxWidth()) {
            val context = LocalContext.current
            var containerSize by remember { mutableStateOf<IntSize?>(null) }
            if (showImage) {
                val imgRatio = if (showText) 3f / 2f else 1f
                val imgHolder = rememberAsyncImagePlaceholder(
                    id = R.drawable.ic_list_default_image,
                    idOfDark = R.drawable.ic_list_default_image_night
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(imgRatio)
                ) {
                    AsyncImage(
                        modifier = Modifier
                            .applyTestTag(tag = "iv_vote_grid_item_image")
                            .fillMaxWidth()
                            .aspectRatio(imgRatio),
                        model = run {
                            if (data.img?.matches("^https?://.+".toRegex()) != true)
                                assertUrlPrefix
                                    ?.plus("/")
                                    ?.plus(data.img)
                                    ?: data.img
                            else data.img
                        },
                        error = imgHolder,
                        fallback = imgHolder,
                        placeholder = imgHolder,
                        contentDescription = null,
                        contentScale = ContentScale.Crop
                    )
                    // 没有文本 & 被选中 & 没有点击事件（已经是标记结果了）
                    if (!showText && isSelected && onClick == null) {
                        ZbCheckBox(
                            modifier = Modifier
                                .applyTestTag("cb_check_true")
                                .offset((-1).dp, (-1).dp)
                                .padding(end = LocalDimens.current.dp3)
                                .size(LocalDimens.current.dp24),
                            checked = true
                        )
                    }
                }
            }
            if (showText) Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(LocalDimens.current.dp8),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onClick != null)
                    ZbCheckBox(
                        modifier = Modifier
                            .applyTestTag(tag = "cb_check_$isSelected")
                            .padding(end = LocalDimens.current.dp2)
                            .size(LocalDimens.current.dp24),
                        checked = isSelected
                    )
                val text = remember(useSimpleCNText, data.title) {
                    val funIcu = VotePollSdk.simpleCN2TraditionalCN
                    if (!useSimpleCNText && funIcu != null) {
                        funIcu.invoke(data.title ?: "")
                    } else data.title ?: ""
                }
                ZbText(
                    modifier = Modifier
                        .applyTestTag("tv_vote_item_title")
                        .fillMaxWidth(),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = LocalColorPallet.current.linkHeadlineDefault,
                    text = text,
                    type = TypographyType.Header3,
                    scaleType = with(typographyScaleType) { calculateForNewsList }
                )
            }
            // 注意，没有文本展示的，不显示投票结果输出
            if (showResult && showText) {
                Column(
                    Modifier
                        .applyTestTag("vote_grid_item_result_view")
                        .padding(
                            top = 0.dp,
                            start = LocalDimens.current.dp8,
                            end = LocalDimens.current.dp8,
                            bottom = LocalDimens.current.dp8
                        )
                        .fillMaxWidth()
                        .onGloballyPositioned { coordinates -> containerSize = coordinates.size },
                ) {
                    val votePercent = remember(voteTotalCount, data.voteCount) {
                        if ((voteTotalCount ?: 0L) <= 0L) 0f
                        else (data.voteCount?.toFloat() ?: 0f) / voteTotalCount!!.toFloat()
                    }
                    val percentVoteText = remember(context, votePercent, data.voteCount) {
                        context.getString(
                            R.string.app_user_vote_poll_percent_result,
                            String.format("%.1f", votePercent * 100f), data.voteCount ?: 0L
                        )
                    }
                    if (voteTotalCount != null &&
                        voteTotalCount > 0 &&
                        containerSize?.width != null
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(LocalDimens.current.dp4)
                                .background(
                                    color = LocalColorPallet.current.backgroundQuinary, // 底色
                                    shape = RoundedCornerShape(LocalDimens.current.dp100)
                                )
                        ) {
                            Box(
                                Modifier
                                    .width((with(LocalDensity.current) {
                                        (containerSize?.width ?: 0).toDp()
                                    }) * votePercent)
                                    .height(LocalDimens.current.dp4)
                                    .background(
                                        if (isSelected)
                                            LocalColorPallet.current.backgroundBrandPrimary
                                        else LocalColorPallet.current.backgroundQuaternary,
                                        RoundedCornerShape(LocalDimens.current.dp100)
                                    )

                            )
                        }
                    }
                    ZbText(
                        modifier = Modifier
                            .applyTestTag(tag = "tv_vote_result_text")
                            .padding(LocalDimens.current.dp2),
                        text = percentVoteText,
                        color = if (isSelected)
                            LocalColorPallet.current.textBrandPrimary
                        else LocalColorPallet.current.textSecondary,
                        type = TypographyType.Label4,
                        scaleType = with(typographyScaleType) { calculateForNewsList }
                    )
                }
            }
        }
    }

}

@Composable
@Preview(name = "文字+图，未选中-白色主题")
@Preview(name = "文字+图，未选中-深色主题", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionGridItemView() = DefaultPreview {
    InternalVoteOptionGridItemView(data = VoteAnswerItemInfo(title = "战"))
}

@Composable
@Preview(name = "文字+图，展示结果，选中-白色主题")
@Preview(name = "文字+图，展示结果，选中-深色主题", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionGridItemView2() = DefaultPreview {
    InternalVoteOptionGridItemView(
        isSelected = true,
        showResult = true,
        voteTotalCount = 10,
        data = VoteAnswerItemInfo(title = "战", voteCount = 4)
    )
}

@Composable
@Preview(name = "纯图，不展示结果。选中-白色主题，无文本")
@Preview(name = "纯图，不展示结果。选中-深色主题，无文本", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionGridItemView3() = DefaultPreview {
    InternalVoteOptionGridItemView(
        isSelected = true,
        showText = false,
        showResult = false,
        voteTotalCount = 30,
        data = VoteAnswerItemInfo(title = "战", voteCount = 20)
    )
}

@Composable
@Preview(name = "纯图，展示结果。未选中-白色主题，无文本")
@Preview(name = "纯图，展示结果。未选中-深色主题，无文本", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionGridItemView4() = DefaultPreview {
    InternalVoteOptionGridItemView(
        isSelected = false,
        showText = false,
        showResult = true,
        voteTotalCount = 30,
        onClick = null,
        data = VoteAnswerItemInfo(title = "战", voteCount = 20)
    )
}

@Composable
@Preview(name = "纯图，展示结果。选中-白色主题，无文本")
@Preview(name = "纯图，展示结果。选中-深色主题，无文本", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionGridItemView5() = DefaultPreview {
    InternalVoteOptionGridItemView(
        isSelected = true,
        showText = false,
        showResult = true,
        voteTotalCount = 30,
        onClick = null,
        data = VoteAnswerItemInfo(title = "战", voteCount = 20)
    )
}