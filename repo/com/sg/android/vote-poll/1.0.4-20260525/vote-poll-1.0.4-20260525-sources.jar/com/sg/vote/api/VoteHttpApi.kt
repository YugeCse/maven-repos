package com.sg.vote.api

import android.net.Uri
import androidx.core.net.toUri
import com.sg.vote.VotePollSdk
import com.sg.vote.api.HttpLoggingInterceptor.applyHttpLoggingInterceptor
import com.sg.vote.log.LogUtils
import com.sg.vote.utils.toJsonObject
import okhttp3.Call
import okhttp3.Callback
import okhttp3.ConnectionPool
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.HttpURLConnection
import java.security.KeyStore
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/** 网络API请求类 **/
internal class VoteHttpApi private constructor() {

    companion object {

        private val instance by lazy { VoteHttpApi() }

        /** 获取网络API单例对象 **/
        @JvmStatic
        fun singleton() = instance

        /** 创建一个新的HttpApi对象 **/
        @JvmStatic
        fun newHttpApi() = VoteHttpApi()

    }

    /** 获取OkHttpClient对象 **/
    var okHttpClient: OkHttpClient
        private set

    init {
        val (trustManager, sslSocketFactory) = try {
            val trustManagers =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
                    .apply {
                        @Suppress("CAST_NEVER_SUCCEEDS")
                        init(null as KeyStore?)
                    }.trustManagers
            if (trustManagers.size != 1 || trustManagers[0] !is X509TrustManager)
                throw IllegalStateException(
                    "Unexpected default trust managers: ${trustManagers.contentToString()}"
                )
            val trustManager = trustManagers.first() as X509TrustManager
            val sslSocketFactory = SSLContext.getInstance("TLS")
                .apply { init(null, arrayOf(trustManager), null) }
                .socketFactory
            trustManager to sslSocketFactory
        } catch (e: Exception) {
            LogUtils.log4e("HttpApi", e)
            Pair(null, null)
        }
        okHttpClient = OkHttpClient.Builder().apply {
            connectTimeout(3, TimeUnit.SECONDS)
            readTimeout(6, TimeUnit.SECONDS)
            writeTimeout(6, TimeUnit.SECONDS)
            callTimeout(10, TimeUnit.SECONDS)
            if (LogUtils.logPrintEnabled)
                applyHttpLoggingInterceptor() //应用Okhttp日志打印的Interceptor
            if (VotePollSdk.httpInterceptors.isNotEmpty())
                VotePollSdk.httpInterceptors
                    .forEach { interceptor -> addInterceptor(interceptor) }
            if (VotePollSdk.networkInterceptors.isNotEmpty())
                VotePollSdk.networkInterceptors
                    .forEach { interceptor -> addNetworkInterceptor(interceptor) }
            if (sslSocketFactory != null && trustManager != null)
                sslSocketFactory(sslSocketFactory, trustManager)
            connectionPool(ConnectionPool(6, 2, TimeUnit.MINUTES))
        }.build()
    }

    /**
     * 构建新的HTTP链接
     * @param url 链接URL
     * @param queryParams Query参数
     */
    private fun newHttpUrl(url: String, queryParams: Map<String, Any?> = emptyMap()): String {
        if (queryParams.isEmpty()) return url
        return url.toUri()
            .buildUpon()
            .apply {
                queryParams.forEach { item ->
                    val encodedValue = item.value?.toString()
                        ?.run { Uri.encode(this) }
                    appendQueryParameter(item.key, encodedValue)
                }
            }.build().toString()
    }

    /**
     * 构建新的GET请求
     * @param url 请求链接
     * @param headers 请求头数据
     * @param queryParams Query参数
     */
    fun newGetRequest(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap()
    ): Request {
        val newUrl = newHttpUrl(url, queryParams).toUri().toString()
        return Request.Builder()
            .url(newUrl)
            .get()
            .apply {
                if (headers.isNotEmpty()) {
                    headers.forEach { item ->
                        header(item.key, item.value?.toString() ?: "")
                    }
                }
            }
            .build()
    }

    /**
     * 构建新的POST请求
     * @param url 请求链接
     * @param headers 请求头数据
     * @param queryParams Query参数
     * @param requestBody Request数据包
     */
    fun newPostRequest(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        requestBody: RequestBody? = ByteArray(0).toRequestBody()
    ): Request {
        val newUrl = newHttpUrl(url, queryParams)
        return Request.Builder()
            .url(newUrl)
            .post(requestBody ?: ByteArray(0).toRequestBody())
            .apply {
                if (headers.isNotEmpty()) {
                    headers.forEach { item ->
                        header(item.key, item.value?.toString() ?: "")
                    }
                }
            }
            .build()
    }

    /**
     * 同步处理请求
     * @param request 请求对象的方法
     */
    private inline fun <reified T : Any> handleRequest(request: () -> Request): ApiCallback<T> {
        try {
            val response = okHttpClient.newCall(request()).execute()
            var statusCode = response.code.toString()
            var statusText = response.message
            return if (response.isSuccessful) {
                val outputData = response.body
                    .use { it.byteStream().bufferedReader().readText() }
                val outputObject = when (outputData.trim().isEmpty()) {
                    true -> null
                    else -> outputData.toJsonObject<ApiResponseInfo<T>>()
                }
                if (outputObject == null) {
                    return ApiCallback.Fail(
                        code = 422.toString(),
                        message = "response data cannot parse to the right data"
                    )
                }
                statusCode = when (outputObject.isSuccessful) {
                    true -> HttpURLConnection.HTTP_OK.toString()
                    else -> (outputObject.code ?: statusCode)
                }
                if (statusCode.toIntOrNull()?.isSuccessfulCode == true) {
                    ApiCallback.Success(
                        code = statusCode,
                        message = statusText,
                        dataResult = outputObject.result
                    )
                } else {
                    ApiCallback.Fail(
                        code = statusCode,
                        message = statusText,
                        extraMessage = outputObject.errors?.toString()
                    )
                }
            } else {
                var extraMessage = ""
                val errorContent = response.body
                    .use { it.byteStream().bufferedReader().readText() }
                if (errorContent.isNotEmpty()) {
                    val result = errorContent
                        .toJsonObject<ApiResponseInfo<Any>>()
                    statusCode = result?.code ?: statusCode
                    statusText = result?.message ?: statusText
                    extraMessage = result?.errors?.joinToString() ?: extraMessage
                }
                ApiCallback.Fail(
                    code = statusCode,
                    message = statusText,
                    extraMessage = extraMessage
                )
            }
        } catch (e: Exception) {
            LogUtils.log4e("HttpApi", e)
            return ApiCallback.Fail(null, e.message)
        }
    }

    /**
     * 异步处理请求
     * @param request 请求对象的方法
     * @param callback 回调
     */
    private inline fun <reified T : Any> handleRequestAsync(
        request: () -> Request,
        crossinline callback: (ApiCallback<T>) -> Unit
    ): Call = okHttpClient.newCall(request()).apply {
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback.invoke(ApiCallback.Fail(null, e.message))
            }

            override fun onResponse(call: Call, response: Response) {
                var statusCode = response.code.toString()
                var statusText = response.message
                if (response.isSuccessful) {
                    val outputData = response.body
                        .use { it.byteStream().bufferedReader().readText() }
                    val outputObject = when (outputData.trim().isEmpty()) {
                        true -> null
                        else -> outputData.toJsonObject<ApiResponseInfo<T>>()
                    }
                    if (outputObject == null) {
                        callback.invoke(
                            ApiCallback.Fail(
                                code = 422.toString(),
                                message = "response data cannot parse to the right data"
                            )
                        )
                        return
                    }
                    statusCode = when (outputObject.isSuccessful) {
                        true -> HttpURLConnection.HTTP_OK.toString()
                        else -> (outputObject.code ?: statusCode)
                    }
                    if (statusCode.toIntOrNull()?.isSuccessfulCode == true) {
                        callback.invoke(
                            ApiCallback.Success(
                                code = statusCode,
                                message = statusText,
                                dataResult = outputObject.result
                            )
                        )
                    } else {
                        callback.invoke(
                            ApiCallback.Fail(
                                code = statusCode,
                                message = statusText,
                                extraMessage = outputObject.errors?.toString()
                            )
                        )
                    }
                } else {
                    var extraMessage = ""
                    val errorContent = response.body
                        .use { it.byteStream().bufferedReader().readText() }
                    if (errorContent.isNotEmpty()) {
                        val result = errorContent
                            .toJsonObject<ApiResponseInfo<Any>>()
                        statusCode = result?.code ?: statusCode
                        statusText = result?.message ?: statusText
                        extraMessage = result?.errors?.joinToString() ?: extraMessage
                    }
                    callback.invoke(
                        ApiCallback.Fail(
                            code = statusCode,
                            message = statusText,
                            extraMessage = extraMessage
                        )
                    )
                }
            }
        })
    }

    /**
     * 发送同步GET请求
     * @param url 请求链接
     * @param headers 请求的头部数据
     * @param queryParams Query参数
     */
    inline fun <reified T : Any> get(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap()
    ): ApiCallback<out T> = handleRequest { newGetRequest(url, headers, queryParams) }

    /**
     * 发送GET异步请求
     * @param url 请求链接
     * @param headers 请求的头部数据
     * @param queryParams Query参数
     */
    inline fun <reified T : Any> getAsync(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        crossinline callback: (ApiCallback<T>) -> Unit = {}
    ): Call = handleRequestAsync<T>(
        callback = callback,
        request = { newGetRequest(url, headers, queryParams) }
    )

    /**
     * 发送POST同步请求
     * @param url 请求链接
     * @param requestBody 请求体
     * @param headers 请求的头部数据
     */
    inline fun <reified T : Any> post(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        requestBody: RequestBody? = ByteArray(0).toRequestBody()
    ): ApiCallback<out T> = handleRequest { newPostRequest(url, headers, queryParams, requestBody) }

    /**
     * 发送POST异步请求
     * @param url 请求链接
     * @param requestBody 请求体
     * @param headers 请求的头部数据
     */
    inline fun <reified T : Any> postAsync(
        url: String,
        headers: Map<String, Any?> = emptyMap(),
        queryParams: Map<String, Any?> = emptyMap(),
        requestBody: RequestBody? = ByteArray(0).toRequestBody(),
        crossinline callback: (ApiCallback<T>) -> Unit = {}
    ): Call = handleRequestAsync<T>(
        callback = callback,
        request = { newPostRequest(url, headers, queryParams, requestBody) }
    )

}


/** Http日志Interceptor **/
internal object HttpLoggingInterceptor {


    /** 应用API网络日志Interceptor，需要项目引用Okhttp-Logging库 **/
    fun OkHttpClient.Builder.applyHttpLoggingInterceptor() {
        try {
            val clazz: Class<*>? =
                Class.forName("okhttp3.logging.HttpLoggingInterceptor")
            if (clazz == null) {
                LogUtils.log4i(
                    "tracking::HttpLoggingInterceptor",
                    "项目未引入OkHttp日志库：HttpLoggingInterceptor"
                )
                return
            }
            val loggingInterceptorInstance = clazz.getDeclaredConstructor().newInstance()
            val addInterceptorMethod =
                javaClass.getMethod("addInterceptor", Interceptor::class.java)
            addInterceptorMethod.invoke(this, loggingInterceptorInstance)
            val levelEnum =
                Class.forName($$"okhttp3.logging.HttpLoggingInterceptor$Level")
            val bodyField = levelEnum.getDeclaredField("BODY")
            clazz.getMethod(
                "setLevel",
                Class.forName($$"okhttp3.logging.HttpLoggingInterceptor$Level")
            ).invoke(loggingInterceptorInstance, bodyField[null])
        } catch (e: Exception) {
            LogUtils.log4e("HttpApiManager", "applyHttpLoggingInterceptor: ${e.message}")
        }
    }

}