package com.sg.vote.view.zaobao

import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import com.sg.common.theme.LocalDefaultFontFamily
import com.sg.common.theme.TypographyHandler
import com.sg.common.theme.TypographyScaleType
import com.sg.common.theme.TypographyType

/**
 * 早报字体组件
 * @param modifier 修饰符
 * @param type 字体类型
 * @param scaleType 字体缩放等级
 * @param text 文本
 * @param color 字体颜色
 * @param overflow 文本溢出处理
 * @param softWrap 是否支持换行
 * @param maxLines 最大行数
 * @param minLines 最小行数
 * @param fontFamily 字体家族，不传取应用默认字体
 * @param fontWeight 字重，不传则取计算的默认值
 * @param fontSize 字号，不传则取计算的默认值
 * @param autoSize 自动缩放尺寸处理，默认：不处理
 * @param textAlign 文本对齐方式
 * @param textDecoration 文本装饰
 * @param lineHeight 行高，当不为[TextUnit.Unspecified]时，覆盖计算出来的值
 * @param letterSpacing 字符间距，当不为[TextUnit.Unspecified]时，覆盖计算出来的值
 * @param onTextLayout 文本布局回调
 * @param style 文本样式，会融合上面的字体设置属性(merge)
 */
@Composable
internal fun ZbText(
    modifier: Modifier = Modifier,
    type: TypographyType,
    scaleType: TypographyScaleType = TypographyScaleType.Standard,
    text: String?,
    color: Color = Color.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    fontFamily: FontFamily? = null,
    fontWeight: FontWeight? = null,
    fontSize: TextUnit = TextUnit.Unspecified,
    autoSize: TextAutoSize? = null,
    textAlign: TextAlign? = null,
    textDecoration: TextDecoration? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current,
) {
    val typographyInfo =
        TypographyHandler.getTypographyInfo(type, scaleType)
    Text(
        modifier = modifier,
        style = style,
        text = text ?: "",
        color = color,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        textAlign = textAlign,
        onTextLayout = onTextLayout,
        textDecoration = textDecoration,
        autoSize = autoSize,
        fontWeight = fontWeight ?: typographyInfo.fontWeight,
        fontFamily = fontFamily ?: LocalDefaultFontFamily.current,
        fontSize = if (fontSize == TextUnit.Unspecified) typographyInfo.fontSize else fontSize,
        lineHeight = if (lineHeight == TextUnit.Unspecified) typographyInfo.lineHeight else lineHeight,
        letterSpacing = if (letterSpacing == TextUnit.Unspecified) typographyInfo.letterSpacing else letterSpacing
    )
}

/**
 * 早报字体组件
 * @param modifier 修饰符
 * @param type 字体类型
 * @param scaleType 字体缩放等级
 * @param text 文本
 * @param color 字体颜色
 * @param overflow 文本溢出处理
 * @param softWrap 是否支持换行
 * @param maxLines 最大行数
 * @param minLines 最小行数
 * @param fontFamily 字体家族，不传取应用默认字体
 * @param fontWeight 字重，不传则取计算的默认值
 * @param fontSize 字号，不传则取计算的默认值
 * @param autoSize 自动缩放尺寸处理，默认：不处理
 * @param textAlign 文本对齐方式
 * @param textDecoration 文本装饰
 * @param lineHeight 行高，当不为[TextUnit.Unspecified]时，覆盖计算出来的值
 * @param letterSpacing 字符间距，当不为[TextUnit.Unspecified]时，覆盖计算出来的值
 * @param onTextLayout 文本布局回调
 * @param style 文本样式，会融合上面的字体设置属性(merge)
 */
@Composable
internal fun ZbText(
    modifier: Modifier = Modifier,
    type: TypographyType,
    scaleType: TypographyScaleType = TypographyScaleType.Standard,
    text: AnnotatedString,
    inlineContent: Map<String, InlineTextContent> = mapOf(),
    color: Color = Color.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    fontFamily: FontFamily? = null,
    fontWeight: FontWeight? = null,
    fontSize: TextUnit = TextUnit.Unspecified,
    autoSize: TextAutoSize? = null,
    textAlign: TextAlign? = null,
    textDecoration: TextDecoration? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    onTextLayout: (TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current,
) {
    val typographyInfo =
        TypographyHandler.getTypographyInfo(type, scaleType)
    Text(
        modifier = modifier,
        style = style,
        text = text,
        color = color,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        textAlign = textAlign,
        autoSize = autoSize,
        textDecoration = textDecoration,
        inlineContent = inlineContent,
        onTextLayout = onTextLayout,
        fontWeight = fontWeight ?: typographyInfo.fontWeight,
        fontFamily = fontFamily ?: LocalDefaultFontFamily.current,
        fontSize = if (fontSize == TextUnit.Unspecified) typographyInfo.fontSize else fontSize,
        lineHeight = if (lineHeight == TextUnit.Unspecified) typographyInfo.lineHeight else lineHeight,
        letterSpacing = if (letterSpacing == TextUnit.Unspecified) typographyInfo.letterSpacing else letterSpacing
    )
}