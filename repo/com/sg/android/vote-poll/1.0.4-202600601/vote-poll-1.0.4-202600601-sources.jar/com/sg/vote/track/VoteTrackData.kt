package com.sg.vote.track

import android.os.Bundle
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/** 投票数据 **/
sealed interface VoteTrackData {

    /**
     * 事件对象数据
     * @param eventCategory 事件分类
     * @param eventAction 事件行为
     * @param eventLabel 事件标签
     */
    @Parcelize
    @Serializable
    data class Object(
        val eventCategory: String? = null,
        val eventAction: String? = null,
        val eventLabel: String? = null
    ) : Parcelable, VoteTrackData

    /**
     * Bundle数据包的形式
     * @param data 数据包
     */
    data class BundleObject(val data: Bundle? = null) : VoteTrackData

}