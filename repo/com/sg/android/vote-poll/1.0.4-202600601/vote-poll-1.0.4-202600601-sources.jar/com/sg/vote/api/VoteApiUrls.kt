package com.sg.vote.api

import com.sg.vote.VotePollSdk

/** 投票API的URL地址 **/
internal object VoteApiUrls {

    /** 获取投票数据 **/
    private const val GET_POLL_OPTIONS = "webapi/voteapi"

    /** 执行投票 **/
    private const val SUBMIT_POLL = "webapi/voteapi/%s"

    /** 获取投票结果 **/
    private const val GET_VOTE_POLL_RESULT = "webapi/voteapi/detail/%s"

    /** 获取投票选项的URL **/
    val getPollOptions = GET_POLL_OPTIONS.toFullApiUrl()

    /** 提交投票选项的URL **/
    fun submitPoll(voteId: String?) =
        SUBMIT_POLL.format(voteId ?: "").toFullApiUrl()

    /** 获取投票结果的URL **/
    fun getVotePollResult(voteId: String?) =
        GET_VOTE_POLL_RESULT.format(voteId ?: "").toFullApiUrl()

    /** 构建完整API链接 **/
    private fun String.toFullApiUrl(): String = "${VotePollSdk.apiBaseUrl}/$this"

}