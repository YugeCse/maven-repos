package com.sg.vote.data.beans

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * 投票配置信息实体类
 * @param showResult 投票完成是否展示投票结果
 * @param showImages 是否显示图片
 * @param showAnswerTitle 是否显示答案标题，即：答案文本
 * @param link 投票完成跳转链接（例如: 去抽奖按钮的链接）
 * @param linkLabel 投票完成跳转链接提示文案（例如去抽奖按钮的文本）
 * @param linkTarget 投票完成跳转链接打开方式（例如去抽奖按钮）
 * @param limit 投票限制数量，0为不限制
 * @param limitType 限制类型(限制类型，如:不限制，每天限制，限制总投票次数)，默认为：total_limit，total_limit-总量限制投票，daily_limit-每日限制投票
 * @param resultText 投票完成自定义结果文案，由后台配置的文本
 */
@Parcelize
@Serializable
data class VoteSettingInfo(

    @field:SerializedName("limit")
    val limit: Int? = 1,

    @field:SerializedName("limitType")
    val limitType: String? = "total_limit",

    @field:SerializedName("showImages")
    val showImages: Boolean? = null,

    @field:SerializedName("showAnswerTitle")
    val showAnswerTitle: Boolean? = null,

    @field:SerializedName("showResult")
    val showResult: Boolean? = null,

    @field:SerializedName("resultText")
    val resultText: String? = null,

    @field:SerializedName("link")
    val link: String? = null,

    @field:SerializedName("linkLabel")
    val linkLabel: String? = null,

    @field:SerializedName("linkTarget")
    val linkTarget: String? = null,
) : Parcelable {

    /** 获取是否有链接按钮，这个按钮一般是去抽奖啥的 **/
    val hasLinkButton: Boolean get() = !linkLabel.isNullOrEmpty() && !link.isNullOrEmpty()

}
