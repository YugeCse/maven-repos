package com.sg.vote.view

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sg.common.theme.TypographyScaleType
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.view.BorderInfo

/**
 * 投票视图UI
 * @param modifier Modifier
 * @param uniqueKey 唯一标识，强制刷新时请改变它
 * @param state 投票视图状态
 * @param horizontalPadding 水平内边距
 * @param eventHandler 事件处理
 */
@Composable
fun VotePollView2(
    modifier: Modifier = Modifier,
    uniqueKey: String? = null,
    state: VotePollViewControlState = rememberVotePollViewControlState(),
    horizontalPadding: Dp = 20.dp,
    eventHandler: VotePollViewEventHandler? = null
) {
    val useDarkTheme by state.useDarkTheme
    val voteData by state.voteData
    val pageType by state.pageType
    val border by state.border
    val typographyScaleType by state.typographyScaleType
    VotePollView(
        modifier = Modifier.then(modifier),
        uniqueKey = uniqueKey,
        useDarkTheme = useDarkTheme,
        typographyScaleType = typographyScaleType,
        border = border,
        horizontalPadding = horizontalPadding,
        pageType = pageType,
        data = voteData,
        eventHandler = eventHandler,
    )
}

/** 投票视图状态控制类 **/
class VotePollViewControlState {

    /** 是否使用暗色模式，默认：false **/
    val useDarkTheme = mutableStateOf(false)

    /** 字体缩放类型，默认：[TypographyScaleType.Standard] **/
    val typographyScaleType = mutableStateOf(TypographyScaleType.Standard)

    /** 边框线配置信息，默认：无 **/
    val border = mutableStateOf<BorderInfo?>(null)

    /** 数据调用页面类型，默认：无 **/
    val pageType = mutableStateOf<String?>(null)

    /** 投票数据对象, 默认：无 **/
    val voteData = mutableStateOf<VoteDataInfo?>(null)

    /**
     * 初始化
     * @param voteId 投票ID
     * @param pageType 页面类型
     * @param typographyScaleType 字体缩放类型
     * @param useDarkTheme 是否使用暗黑主题
     */
    fun init(
        voteId: String? = null,
        pageType: String? = null,
        typographyScaleType: TypographyScaleType? = null,
        useDarkTheme: Boolean = false
    ) {
        this.voteData.value = VoteDataInfo(id = voteId)
        this.pageType.value = pageType
        this.useDarkTheme.value = useDarkTheme
        typographyScaleType?.let { scaleType -> this.typographyScaleType.value = scaleType }
    }

    /**
     * 初始化
     * @param voteData 投票数据
     * @param useDarkTheme 是否使用暗色模式
     * @param pageType 页面类型
     */
    fun init(
        voteData: VoteDataInfo? = null,
        pageType: String? = null,
        useDarkTheme: Boolean = false
    ) {
        this.voteData.value = voteData
        this.pageType.value = pageType
        this.useDarkTheme.value = useDarkTheme
    }

    /**
     * 设置是否使用暗色模式
     * @param useDarkTheme 是否使用暗色模式
     */
    fun setUseDarkTheme(useDarkTheme: Boolean) {
        this.useDarkTheme.value = useDarkTheme
    }

    /**
     * 设置字体缩放类型
     * @param scaleType 字体缩放类型
     */
    fun setTypographyScaleType(scaleType: TypographyScaleType) {
        this.typographyScaleType.value = scaleType
    }

    /**
     * 设置边框信息
     * @param border 边框信息
     */
    fun setBorder(border: BorderInfo?) {
        this.border.value = border
    }

    /**
     * 设置页面类型
     * @param pageType 页面类型
     */
    fun setPageType(pageType: String?) {
        this.pageType.value = pageType
    }

    /**
     * 设置投票数据
     * @param voteData 投票数据
     */
    fun setVoteData(voteData: VoteDataInfo?) {
        this.voteData.value = voteData
    }

}

/** 提供VotePollViewControlState对象 **/
@Composable
fun rememberVotePollViewControlState(): VotePollViewControlState =
    remember { VotePollViewControlState() }