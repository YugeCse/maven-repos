package com.sg.vote.api

import com.google.gson.annotations.SerializedName

/** 回调对象类 **/
sealed interface ApiCallback<T> {

    /** 状态码 **/
    var code: String?

    /** 状态消息 **/
    var message: String?

    /** 额外的信息 **/
    var extraMessage: String?

    /** 成功 **/
    data class Success<T>(
        @field:SerializedName("code")
        override var code: String?,
        @field:SerializedName("message")
        override var message: String? = null,
        @field:SerializedName("data")
        var dataResult: T? = null,
        @field:SerializedName("extraMessage")
        override var extraMessage: String? = null
    ) : ApiCallback<T>

    /** 失败 **/
    data class Fail<T : Any>(
        @field:SerializedName("code")
        override var code: String?,
        @field:SerializedName("message")
        override var message: String? = null,
        @field:SerializedName("extraMessage")
        override var extraMessage: String? = null
    ) : ApiCallback<T>

}

/** 是否是成功的code **/
val Int.isSuccessfulCode: Boolean get() = this in 200..299

/** 获取是否是成功，code=200~299 **/
internal val ApiCallback<*>.isSuccessful
    get() = code?.matches("^\\d+$".toRegex()) == true && code?.toIntOrNull()?.isSuccessfulCode == true
