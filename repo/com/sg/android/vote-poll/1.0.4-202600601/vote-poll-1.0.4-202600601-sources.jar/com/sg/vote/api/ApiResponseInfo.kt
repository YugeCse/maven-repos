package com.sg.vote.api

/**
 * 接口返回数据实体类
 * @param code 状态码
 * @param message 状态消息
 * @param timestamp 时间戳
 * @param result 返回数据
 * @param errors 错误信息
 */
internal data class ApiResponseInfo<T>(
    val code: String? = null,
    val message: String? = null,
    val timestamp: String? = null,
    val result: T? = null,
    val errors: List<String?>? = null
) {

    /** 获取是否是成功的 **/
    val isSuccessful: Boolean get() = code == "00000"

}
