package com.sg.vote.data.view

/**
 * 投票记录实体类
 * @param userSsid 用户ssid
 * @param voteId 投票id
 * @param voteCount 投票数
 */
data class PollRecordInfo(
    val userSsid: String? = "",
    val voteId: String? = null,
    val voteCount: Int? = null
)