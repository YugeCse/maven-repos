package com.sg.vote.data.view

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sg.common.theme.TypographyScaleType

/**
 * 投票卡片的配置类
 * @param useDarkTheme 是否使用深色主题，默认为：false
 * @param typographyScaleType 字体缩放类型，默认:[TypographyScaleType.Standard]
 * @param pollCardViewBorder 投票卡片的边框信息, 默认为：null
 * @param pollCardHorizontalPadding 投票卡片的水平内边距, 默认为：20.dp
 * @param useSimpleCN 是否使用简体中文，默认为：true
 */
internal data class VoteCardViewConfig(
    val useDarkTheme: Boolean = false,
    val typographyScaleType: TypographyScaleType = TypographyScaleType.Standard,
    val pollCardViewBorder: BorderInfo? = null,
    val pollCardHorizontalPadding: Dp = 20.dp,
    val useSimpleCN: Boolean = true
)

/** 获取本地的投票视图的配置信息 **/
internal val LocalVoteCardViewConfig = compositionLocalOf { VoteCardViewConfig() }
