package com.sg.vote.view.other

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.toColorInt
import com.sg.common.theme.LocalColorPallet
import com.sg.common.theme.LocalDimens
import com.sg.common.theme.LocalUiUseDarkTheme
import com.sg.vote.data.view.BorderConfig
import com.sg.vote.utils.rgbToColorInt


/**
 * 卡片和容器的分割线处理
 * @param modifier 修饰器
 * @param bgColor 背景颜色
 * @param borderConfig 边框配置
 */
@Composable
internal fun CardDividerView(
    modifier: Modifier = Modifier,
    bgColor: Color? = null,
    borderConfig: BorderConfig? = null,
    paddingHorizontal: Dp = LocalDimens.current.dp0,
) {
    if ((borderConfig?.height ?: 0) <= 0) return
    val isDarkMode = LocalUiUseDarkTheme.current
    val light = borderConfig?.light
    val dark = borderConfig?.dark
    // 根据深浅色颜色值，获取到对应的color对象
    val borderColor = if (light != null && dark != null) {
        try {
            val colorString = if (isDarkMode) dark else light
            if (colorString.startsWith("#")) { //这里可能透明在后面
                Color(colorString.toColorInt())
            } else if (colorString.startsWith("rgb")) {
                colorString.rgbToColorInt()?.let { Color(it) }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    } else null
    HorizontalDivider(
        modifier = Modifier
            .fillMaxWidth()
            .then(modifier)
            .run { if (bgColor != null) background(bgColor) else this }
            .padding(horizontal = paddingHorizontal),
        thickness = (borderConfig?.height ?: 0).dp,
        color = borderColor ?: LocalColorPallet.current.dividerPrimary
    )
}
