package com.sg.vote.view.zaobao

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import com.sg.common.theme.DefaultPreview
import com.sg.common.theme.LocalUiUseDarkTheme
import com.sg.vote.R
import com.sg.vote.utils.singleClickable

/** 早报CheckBox的形状 **/
internal sealed interface ZbCheckBoxShape {

    /** 圆角矩形 **/
    object RoundedRect : ZbCheckBoxShape

    /** 圆形 **/
    object Circle : ZbCheckBoxShape

}

/**
 * 早报的CheckBox按钮
 * @param modifier Modifier
 * @param shape CheckBox的形状，默认：RoundedRect
 * @param checked 是否选中，默认：false
 * @param onCheckedChange 点击事件，返回是否选中œ
 */
@Composable
internal fun ZbCheckBox(
    modifier: Modifier = Modifier,
    shape: ZbCheckBoxShape = ZbCheckBoxShape.RoundedRect,
    checked: Boolean = false,
    onCheckedChange: ((Boolean) -> Unit)? = null
) {
    val useDarkTheme = LocalUiUseDarkTheme.current
    val drawableId = remember(useDarkTheme, shape, checked) {
        if (checked) {
            if (shape is ZbCheckBoxShape.RoundedRect) {
                if (useDarkTheme)
                    R.drawable.ic_zb_checkbox_selected_night
                else R.drawable.ic_zb_checkbox_selected
            } else {
                if (useDarkTheme)
                    R.drawable.ic_zb_checkbox_circle_selected_night
                else R.drawable.ic_zb_checkbox_circle_selected
            }
        } else {
            if (shape is ZbCheckBoxShape.RoundedRect) {
                if (useDarkTheme)
                    R.drawable.ic_zb_checkbox_night
                else R.drawable.ic_zb_checkbox
            } else {
                if (useDarkTheme)
                    R.drawable.ic_zb_checkbox_circle_night
                else R.drawable.ic_zb_checkbox_circle
            }
        }
    }
    Image(
        modifier = Modifier.then(modifier).run {
            if (onCheckedChange == null) this
            else singleClickable { onCheckedChange(!checked) }
        },
        contentScale = ContentScale.Fit,
        contentDescription = "zb_check_box_$checked",
        imageVector = ImageVector.vectorResource(drawableId),
    )
}

/** CheckBox组件-未选中预览 **/
@Composable
@Preview(name = "CheckBox组件", uiMode = Configuration.UI_MODE_NIGHT_NO)
@Preview(name = "CheckBox组件", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewZbCheckBox() = DefaultPreview { ZbCheckBox() }

/** CheckBox组件-选中预览 **/
@Composable
@Preview(name = "CheckBox组件", uiMode = Configuration.UI_MODE_NIGHT_NO)
@Preview(name = "CheckBox组件", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewZbCheckBox2() = DefaultPreview { ZbCheckBox(checked = true) }

/** CheckBox组件-选中预览 **/
@Composable
@Preview(name = "CheckBox组件", uiMode = Configuration.UI_MODE_NIGHT_NO)
@Preview(name = "CheckBox组件", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewZbCheckBox3() =
    DefaultPreview { ZbCheckBox(checked = true, shape = ZbCheckBoxShape.Circle) }