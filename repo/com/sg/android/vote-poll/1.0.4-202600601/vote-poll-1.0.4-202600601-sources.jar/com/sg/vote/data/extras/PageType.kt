package com.sg.vote.data.extras

/**
 * 页面类型
 * @param value 页面类型值
 */
enum class PageType(val value: String) {

    /** APP首页 **/
    AppHomePage("app_home"),

    /** APP文章详情页 **/
    AppArticle("app_article"),

    /** 网站首页 **/
    WebsiteHomePage("website_homepage"),

    /** 网站列表页 **/
    WebsiteListing("website_listing"),

    /** 网站文章详情页 **/
    WebsiteArticle("website_article"),

    /** 第三方 **/
    ThirdPlatform("third_platform")

}