package com.sg.vote.data.view

import android.os.Parcelable
import com.sg.common.theme.ColorPallet
import com.sg.common.theme.ColorPallet.formatHex
import kotlinx.parcelize.Parcelize

/**
 * 边框线配置
 * @param top 顶部边框线
 * @param bottom 底部边框线
 */
@Parcelize
data class BorderInfo(
    val top: BorderConfig? = null,
    val bottom: BorderConfig? = null
) : Parcelable

/**
 * 边框线配置
 * @param light 选中颜色，支持格式：#FFFFFFFF或者rgb(0,0,0)/rgba(0, 0, 0, 0)
 * @param dark 未选中颜色，支持格式：#FFFFFFFF或者rgb(0,0,0)/rgba(0, 0, 0, 0)
 * @param height 边框线的高度
 */
@Parcelize
data class BorderConfig(
    val light: String? = ColorPallet.lightColorScheme.dividerPrimary.formatHex(),
    val dark: String? = ColorPallet.darkColorScheme.dividerPrimary.formatHex(),
    var height: Int? = null,
) : Parcelable