package com.sg.vote.utils

import android.content.Context
import android.content.res.Configuration

internal object DeviceUtils {

    /**
     * 是否是平板应用
     * @param context 上下文对象
     */
    @JvmStatic
    fun isTablet(context: Context): Boolean {
        return ((context.resources.configuration.screenLayout
                and Configuration.SCREENLAYOUT_SIZE_MASK)
                >= Configuration.SCREENLAYOUT_SIZE_LARGE)
    }

}