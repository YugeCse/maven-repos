package com.sg.vote.utils

import androidx.annotation.DimenRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit


/** 获取字体大小的单位 **/
@Composable
@ReadOnlyComposable
internal fun fontDimenResource(@DimenRes id: Int): TextUnit =
    with(LocalDensity.current) { dimensionResource(id).toSp() }

/** Px测量大小 **/
@Composable
@ReadOnlyComposable
internal fun pixelDimenResource(
    @DimenRes id: Int,
    isDip: Boolean = true
): Float = when (isDip) {
    true -> dipToPixel(dimensionResource(id))
    else -> spToPixel(fontDimenResource(id))
}

/** Px转Dip **/
@Composable
@ReadOnlyComposable
internal fun pixelToDip(pixel: Float): Dp = with(LocalDensity.current) { pixel.toDp() }

/** Px转Dip **/
@Composable
@ReadOnlyComposable
internal fun pixelToDip(pixel: Int): Dp = with(LocalDensity.current) { pixel.toDp() }

/** Dip转Px **/
@Composable
@ReadOnlyComposable
internal fun dipToPixel(dp: Dp): Float = with(LocalDensity.current) { dp.toPx() }

/** SP转Px **/
@Composable
@ReadOnlyComposable
internal fun spToPixel(sp: TextUnit): Float = with(LocalDensity.current) { sp.toPx() }

/** pixel转Sp **/
@Composable
@ReadOnlyComposable
internal fun pixelToSp(pixel: Int): TextUnit = with(LocalDensity.current) { pixel.toDp().toSp() }

/** pixel转Sp **/
@Composable
@ReadOnlyComposable
internal fun pixelToSp(pixel: Float): TextUnit = with(LocalDensity.current) { pixel.toDp().toSp() }

/** Dip转Sp **/
@Composable
@ReadOnlyComposable
internal fun dipToSp(dp: Dp): TextUnit = pixelToSp(dipToPixel(dp))

/** Sp转Dip **/
@Composable
@ReadOnlyComposable
internal fun spToDip(sp: TextUnit): Dp = pixelToDip(spToPixel(sp))
