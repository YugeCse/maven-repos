package com.sg.vote.data.extras

/** 投票状态 **/
sealed interface PollState {

    /** 活动结束 **/
    object EndedVote : PollState

    /** 可以继续投票 **/
    object ContinueVote : PollState

    /** 限制投票，不能再投 **/
    object LimitVote : PollState

}