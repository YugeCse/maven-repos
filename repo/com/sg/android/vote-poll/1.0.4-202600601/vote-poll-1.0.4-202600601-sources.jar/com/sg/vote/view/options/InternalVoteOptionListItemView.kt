package com.sg.vote.view.options

import android.annotation.SuppressLint
import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.sg.common.theme.DefaultPreview
import com.sg.common.theme.LocalColorPallet
import com.sg.common.theme.LocalDimens
import com.sg.common.theme.TypographyScaleType.Companion.calculateForNewsList
import com.sg.common.theme.TypographyType
import com.sg.vote.R
import com.sg.vote.VotePollSdk
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.view.LocalVoteCardViewConfig
import com.sg.vote.utils.applyTestTag
import com.sg.vote.view.zaobao.ZbCheckBox
import com.sg.vote.view.zaobao.ZbText

/**
 * 投票列表选项视图
 * @param modifier Modifier
 * @param data 选项信息
 * @param isSelected 是否选中
 * @param isMarkVoteResult 是否标记投票结果
 * @param onClick 点击事件
 */
@SuppressLint("DefaultLocale", "LocalContextGetResourceValueCall")
@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun InternalVoteOptionListItemView(
    modifier: Modifier = Modifier,
    voteTotalCount: Long? = 0L,
    data: VoteAnswerItemInfo,
    showResult: Boolean = false,
    isSelected: Boolean = false,
    isMarkVoteResult: Boolean = false,
    onClick: (() -> Unit)? = {}
) {
    val config = LocalVoteCardViewConfig.current
    val useSimpleCNText = remember(config) { config.useSimpleCN } //是否使用简体中文
    val typographyScaleType = remember(config) { config.typographyScaleType }
    Column(
        Modifier
            .applyTestTag(tag = "vote_list_item_view")
            .then(modifier)
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalDimens.current.dp4))
            .background(LocalColorPallet.current.backgroundSecondary)
            .border(
                if (isSelected) LocalDimens.current.dp2 else LocalDimens.current.dp1,
                if (isSelected) LocalColorPallet.current.dividerBrand
                else LocalColorPallet.current.dividerPrimary,
                RoundedCornerShape(LocalDimens.current.dp4)
            )
            .run {
                if (onClick == null) this
                else clickable { onClick() }
            }
            .padding(LocalDimens.current.dp10)) {
        val color = LocalColorPallet.current
        val context = LocalContext.current
        var containerSize by remember { mutableStateOf<IntSize?>(null) }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onClick != null)
                ZbCheckBox(
                    modifier = Modifier
                        .applyTestTag(tag = "cb_check_$isSelected")
                        .padding(end = LocalDimens.current.dp8)
                        .size(LocalDimens.current.dp24),
                    checked = isSelected
                )
            val text = remember(useSimpleCNText, data.title) {
                val funIcu = VotePollSdk.simpleCN2TraditionalCN
                if (!useSimpleCNText && funIcu != null) {
                    funIcu.invoke(data.title ?: "")
                } else data.title ?: ""
            }
            ZbText(
                modifier = Modifier
                    .applyTestTag(tag = "tv_vote_item_title")
                    .fillMaxWidth()
                    .onGloballyPositioned { coordinates -> containerSize = coordinates.size },
                text = text,
                color = LocalColorPallet.current.textPrimary,
                type = TypographyType.Header3,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
        }
        if (showResult) {
            Column(
                modifier = Modifier
                    .applyTestTag(tag = "vote_list_item_result_view")
                    .padding(top = LocalDimens.current.dp8)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
            ) {
                val votePercent = remember(voteTotalCount, data.voteCount) {
                    if ((voteTotalCount ?: 0L) <= 0L) 0f
                    else (data.voteCount?.toFloat() ?: 0f) / voteTotalCount!!.toFloat()
                }
                val percentVoteText = remember(context, votePercent, data.voteCount) {
                    context.getString(
                        R.string.app_user_vote_poll_percent_result,
                        String.format("%.1f", votePercent * 100f), data.voteCount ?: 0L
                    )
                }
                if (voteTotalCount != null &&
                    voteTotalCount > 0 &&
                    containerSize?.width != null
                ) {
                    ProgressBar(
                        progress = votePercent,
                        progressColor = if (isSelected) color.backgroundBrandPrimary else color.backgroundQuaternary
                    )
                }
                ZbText(
                    modifier = Modifier
                        .applyTestTag(tag = "tv_vote_result_text")
                        .padding(LocalDimens.current.dp2),
                    text = percentVoteText,
                    color = if (isSelected) color.textBrandPrimary else color.textSecondary,
                    type = TypographyType.Label4,
                    scaleType = with(typographyScaleType) { calculateForNewsList }
                )
            }
        }
    }
}

@Composable
private fun ProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    backgroundColor: Color = LocalColorPallet.current.backgroundQuinary,
    progressColor: Color = LocalColorPallet.current.backgroundBrandPrimary,
    height: Dp = LocalDimens.current.dp4,
    radius: Dp = LocalDimens.current.dp100
) {
    val endRadius = if (progress >= 0.99f) radius else 0.dp
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .background(backgroundColor, RoundedCornerShape(radius))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .background(
                    color = progressColor,
                    shape = RoundedCornerShape(
                        topStart = radius,
                        bottomStart = radius,
                        topEnd = endRadius,
                        bottomEnd = endRadius
                    )
                )
        )
    }
}

@Composable
@Preview(name = "未选中-白色主题")
@Preview(name = "未选中-深色主题", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionListItemView() = DefaultPreview {
    InternalVoteOptionListItemView(
        data = VoteAnswerItemInfo(
            title = "会。DeepSeek重新定义AI技术发展，让中国弯道超车"
        )
    )
}

@Composable
@Preview(name = "选中-白色主题")
@Preview(name = "选中-深色主题", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionListItemView2() = DefaultPreview {
    InternalVoteOptionListItemView(
        voteTotalCount = 20,
        isSelected = true,
        showResult = true,
        data = VoteAnswerItemInfo(
            voteCount = 10,
            title = "会。DeepSeek重新定义AI技术发展，让中国弯道超车",
        )
    )
}

@Composable
@Preview(name = "选中-白色主题")
@Preview(name = "选中-深色主题", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVoteOptionListItemView3() = DefaultPreview {
    InternalVoteOptionListItemView(
        voteTotalCount = 20,
        isSelected = false,
        showResult = true,
        data = VoteAnswerItemInfo(
            voteCount = 10,
            title = "会。DeepSeek重新定义AI技术发展，让中国弯道超车"
        )
    )
}