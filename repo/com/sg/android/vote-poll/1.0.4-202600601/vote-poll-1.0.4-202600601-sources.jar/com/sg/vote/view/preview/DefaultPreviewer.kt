package com.sg.vote.view.preview

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import com.sg.vote.data.view.LocalVoteCardViewConfig
import com.sg.vote.data.view.VoteCardViewConfig

/**
 * 默认的视图预览方法
 * @param content 视图内容
 */
@Composable
internal fun DefaultPreview(content: @Composable () -> Unit) {
    val useDarkTheme = isSystemInDarkTheme()
    val voteCardViewConfig = remember(useDarkTheme) {
        VoteCardViewConfig(useDarkTheme = useDarkTheme)
    }
    com.sg.common.theme.DefaultPreview {
        CompositionLocalProvider(
            LocalVoteCardViewConfig provides voteCardViewConfig
        ) { content() }
    }
}