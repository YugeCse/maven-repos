package com.sg.vote.view.options

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastForEachIndexed
import com.sg.common.theme.LocalDimens
import com.sg.common.theme.TypographyScaleType
import com.sg.common.theme.utils.convertPx2dip
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.utils.DeviceUtils
import com.sg.vote.utils.dipToPixel
import com.sg.vote.utils.pixelToDip


/**
 * 展开式的GridView组件
 * @param modifier Modifier
 * @param enforceRefreshKey 强制刷新key
 * @param inputDataSource 数据源
 * @param itemContent 每个item的内容
 */
@Composable
internal fun InternalVoteExpandedGridView(
    modifier: Modifier = Modifier,
    enforceRefreshKey: String? = null,
    typographyScaleType: TypographyScaleType,
    inputDataSource: List<VoteAnswerItemInfo>,
    itemContent: @Composable BoxScope.(Int, Int, VoteAnswerItemInfo) -> Unit
) {
    val context = LocalContext.current
    val dp640 = LocalDimens.current.dp640
    val dp480 = LocalDimens.current.dp480
    val gridSpacing = LocalDimens.current.dp32
    val screenWidth = LocalWindowInfo.current.containerDpSize.width
    val gridColumnCount = remember(context, screenWidth) {
        when {
            !DeviceUtils.isTablet(context) ->
                2 //如果是手机，展示2个
            else -> when {
                screenWidth > dp640 -> 5
                screenWidth == dp640 -> 4
                screenWidth >= dp480 -> 3
                else -> 2
            }
        }
    }
    val dataSource = remember(
        inputDataSource,
        gridColumnCount
    ) { inputDataSource.chunked(gridColumnCount) }
    var gridViewContainerHeight by rememberSaveable(
        enforceRefreshKey,
        typographyScaleType,
        inputDataSource
    ) { mutableStateOf<Int?>(null) }
    var gridViewContainerWidth by rememberSaveable(typographyScaleType) { mutableStateOf<Int?>(null) }
    val gridSizeModifier = remember(enforceRefreshKey, gridViewContainerWidth) {
        if (gridViewContainerHeight == null ||
            gridViewContainerHeight!! < 0f
        ) Modifier else Modifier.defaultMinSize(
            minHeight = context.convertPx2dip(gridViewContainerHeight!!).toFloat().dp
        )
    }
    Column(
        modifier = Modifier
            .then(modifier)
            .padding(horizontal = LocalDimens.current.dp12)
            .then(gridSizeModifier)
            .onSizeChanged { size ->
                val containerHeight = size.height
                if (containerHeight > 0 &&
                    gridViewContainerHeight != containerHeight
                ) gridViewContainerHeight = containerHeight
                gridViewContainerWidth = size.width
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(gridSpacing)
    ) {
        if (gridViewContainerWidth == null) return@Column
        val everyGridWidth =
            (gridViewContainerWidth!! - dipToPixel(gridSpacing) * (gridColumnCount - 1)) / gridColumnCount
        dataSource.fastForEachIndexed { yIndex, rowItems ->
            if (yIndex * gridColumnCount >= inputDataSource.size)
                return@fastForEachIndexed //已经越界了，不再进行绘制
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(
                    space = gridSpacing,
                    alignment = Alignment.Start
                ),
                verticalAlignment = Alignment.Top
            ) {
                rowItems.fastForEachIndexed { xIndex, item ->
                    Box(
                        modifier = Modifier.width(pixelToDip(everyGridWidth))
                    ) { itemContent(yIndex, yIndex * gridColumnCount + xIndex, item) }
                }
            }
        }
    }
}