package com.sg.vote.track

/** 埋点接口对象 **/
fun interface ITrackInterface {

    /**
     * 发送事件
     * @param event 事件类型
     */
    fun sendEvent(event: VoteTrackEvent)

}