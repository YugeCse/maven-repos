package com.sg.vote.utils

import android.annotation.SuppressLint
import androidx.annotation.DrawableRes
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTag
import androidx.compose.ui.semantics.testTagsAsResourceId
import coil3.compose.AsyncImagePainter
import coil3.compose.rememberAsyncImagePainter
import com.sg.common.theme.LocalUiUseDarkTheme


/**
 * 创建AsyncImage的PlaceHolder
 * @param id 浅色图片资源ID
 * @param idOfDark 深色图片资源ID
 */
@Composable
internal fun rememberAsyncImagePlaceholder(
    @DrawableRes id: Int,
    @DrawableRes idOfDark: Int
): AsyncImagePainter {
    val useDarkTheme = LocalUiUseDarkTheme.current
    val imageHolderId by remember {
        derivedStateOf { if (!useDarkTheme) id else idOfDark }
    }
    return rememberAsyncImagePainter(imageHolderId)
}

/**
 * 单击事件
 * @param enabled 是否启用
 * @param onClickLabel 点击标签
 * @param role 角色
 * @param clickLimitTime 点击间隔时间
 * @param interactionSource 交互源
 * @param onClick 点击事件
 */
internal fun Modifier.singleClickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    useLocalIndication: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    clickLimitTime: Long = 800L,
    onClick: (() -> Unit)? = null
) = composed {
    var recordTimeMillis by remember { mutableLongStateOf(0L) }
    if (onClick == null) this
    else clickable(
        enabled = enabled,
        role = role,
        onClickLabel = onClickLabel,
        interactionSource = interactionSource,
        indication = if (!useLocalIndication) null else LocalIndication.current
    ) {
        val curTimeMillis = System.currentTimeMillis()
        if (recordTimeMillis == 0L ||
            curTimeMillis - recordTimeMillis >=
            (if (clickLimitTime < 0) 0 else clickLimitTime)
        ) {
            onClick.invoke() //可以执行点击事件
            recordTimeMillis = curTimeMillis //赋值新的时间戳
        }
    }
}


/**
 * 无点击特效的点击事件
 * @param onClick 点击事件
 */
internal fun Modifier.noEffectClick(onClick: () -> Unit): Modifier =
    this then Modifier.pointerInput(Unit) { detectTapGestures { onClick() } }


/**
 * 应用testTag
 * @param tag TAG标记
 * @param tagAsResourceId tag是否作为ResourceId，默认：true
 */
@SuppressLint("UnnecessaryComposedModifier")
@OptIn(ExperimentalComposeUiApi::class)
internal fun Modifier.applyTestTag(
    tag: String?,
    tagAsResourceId: Boolean = true
): Modifier = composed {
    if (tag.isNullOrEmpty())
        return@composed this
    val context = LocalContext.current
    val applicationId = context.packageName
    val tagAsResourceIdAvailable =
        tagAsResourceId && applicationId.isNotEmpty()
    return@composed semantics {
        contentDescription = tag
        if (tagAsResourceIdAvailable)
            testTag = "$applicationId:id/$tag"
        testTagsAsResourceId = tagAsResourceIdAvailable
    }
}