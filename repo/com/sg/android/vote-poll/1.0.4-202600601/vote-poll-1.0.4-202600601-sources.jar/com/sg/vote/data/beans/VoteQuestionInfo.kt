package com.sg.vote.data.beans

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * 投票问题信息实体类(包含投票答案选项)
 * @param id 选项ID
 * @param voteId 投票ID
 * @param questType 问题类型，1-是否是单选
 * @param name 投票问题名称
 * @param link 问题链接地址
 * @param itemTotal 投票总数(查询统计的接口返回该字段)
 * @param answers 投票的选项(答案)
 */
@Parcelize
@Serializable
data class VoteQuestionInfo(

    @field:SerializedName("id")
    val id: String? = null,

    @field:SerializedName("voteId")
    val voteId: String? = null,

    @field:SerializedName("questType")
    val questType: Int? = null,

    @field:SerializedName("name")
    val name: String? = null,

    @field:SerializedName("link")
    val link: String? = null,

    @field:SerializedName("userCount")
    val userCount: Int? = null,

    @field:SerializedName("itemTotal")
    val itemTotal: Int? = null,

    @field:SerializedName("answers")
    val answers: List<VoteAnswerItemInfo>? = null
) : Parcelable
