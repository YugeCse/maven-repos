package com.sg.vote.data.view

/**
 * 应用站点
 * @param value 网站，zbcom/zbsg
 */
sealed class Site(val value: String) {

    /** Zbcom **/
    object Zbcom : Site("zbcom")

    /** Zbsg **/
    object Zbsg : Site("zbsg")

}