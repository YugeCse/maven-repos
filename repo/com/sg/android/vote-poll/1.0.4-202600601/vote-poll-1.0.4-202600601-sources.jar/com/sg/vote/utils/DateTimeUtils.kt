package com.sg.vote.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/**
 * 时间戳转换成日期字符串(只对10位或13的时间戳生效)
 * @param pattern 日期格式字符串，默认：yyyy-MM-dd HH:mm:ss
 */
internal fun Long.toDateTimeText(
    pattern: String = "yyyy-MM-dd HH:mm:ss",
    locale: Locale = Locale.getDefault()
): String {
    val millis = if (toString().length == 10) this * 1000L else this
    return SimpleDateFormat(pattern, locale).format(Date(millis))
}