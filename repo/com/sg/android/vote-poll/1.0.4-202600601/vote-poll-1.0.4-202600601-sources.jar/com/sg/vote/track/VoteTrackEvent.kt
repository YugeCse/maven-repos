package com.sg.vote.track

/**
 * 埋点事件
 * @param name 事件名称
 * @param data 事件数据包
 */
sealed class VoteTrackEvent(val name: String, open val data: VoteTrackData? = null) {

    /**
     * 投票标题点击事件
     * @param data 数据包
     */
    internal data class VoteTitleClick(override val data: VoteTrackData? = null) :
        VoteTrackEvent("vote_title_click", data)

    /**
     * 投票扩展链接点击事件
     * @param data 数据包
     */
    internal data class VoteExtLinkClick(override val data: VoteTrackData? = null) :
        VoteTrackEvent("vote_ext_link_click", data)

    /**
     * 投票扩展按钮点击事件，例如：去抽奖
     * @param data 数据包
     */
    internal data class VoteLinkButtonClick(override val data: VoteTrackData? = null) :
        VoteTrackEvent("vote_ext_button_click", data)

    /**
     * 投票提交事件(提交网络前)
     * @param data 数据包
     */
    data class VoteSubmitSendClick(override val data: VoteTrackData? = null) :
        VoteTrackEvent("custom_app_event", data)

    /**
     * 再次投票按钮的点击事件
     * @param data 数据包
     */
    data class VoteAgainClick(override val data: VoteTrackData? = null) :
        VoteTrackEvent("custom_app_event", data)

    /**
     * 投票提交成功后的事件
     * @param data 数据包
     */
    internal data class VoteSuccess(override val data: VoteTrackData? = null) :
        VoteTrackEvent("vote_success", data)

}
