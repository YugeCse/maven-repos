package com.sg.vote.data.extras

/**
 * 投票执行结果实体类
 * @param message 信息，一般用于反馈提示信息
 */
sealed class VoteExecResult(
    open val message: String? = null
) {

    /**
     * 投票成功
     * @param message 消息内容
     */
    data class Success(
        override val message: String?
    ) : VoteExecResult(message)

    /**
     * 投票被限制
     * @param message 消息内容
     */
    data class Limited(
        override val message: String?
    ) : VoteExecResult(message)

    /**
     * 投票失败
     * @param message 消息内容
     */
    data class Failure(
        override val message: String?
    ) : VoteExecResult(message)

}
