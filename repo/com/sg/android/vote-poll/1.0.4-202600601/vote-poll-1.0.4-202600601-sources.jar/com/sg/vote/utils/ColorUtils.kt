package com.sg.vote.utils

import android.graphics.Color

/**
 * rgba/rgb string to color int
 * @param this rgba/rgb string
 */
internal fun String.rgbToColorInt(): Int? {
    // rgba
    val rgba =
        Regex("""rgba\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*([0-9.]+)\s*\)""")
    val rgb = Regex("""rgb\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)""")

    rgba.matchEntire(this)?.let { m ->
        val (r, g, b, a) = m.destructured
        return Color.argb(
            (a.toFloat().coerceIn(0f, 1f) * 255).toInt(),
            r.toInt(), g.toInt(), b.toInt()
        )
    }

    rgb.matchEntire(this)?.let { m ->
        val (r, g, b) = m.destructured
        return Color.rgb(r.toInt(), g.toInt(), b.toInt())
    }

    return null
}