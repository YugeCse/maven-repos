package com.sg.vote

import androidx.compose.ui.text.font.FontFamily
import com.sg.vote.data.view.Site
import com.sg.vote.track.ITrackInterface
import okhttp3.Interceptor

/**
 * 投票SDK配置类
 *
 * @author huangzhongyu@sph.com.sg
 *
 * @param site 网站，zbcom/zbsg
 * @param apiBaseUrlType 接口请求的基础地址类型
 * @param customUserId 用户ID
 * @param logEnable 是否支持打印日志
 * @param fontFamily UI组件的字体配置
 * @param httpInterceptors 网络请求拦截器
 * @param networkInterceptors 网络连接拦截器
 * @param simpleCN2TraditionalCN 用户中文简繁转换的方法
 * @param voteTracker 投票埋点接口对象，需要宿主APP实现并赋值
 */
data class VotePollSdkConfig(
    var site: Site = Site.Zbcom,
    var apiBaseUrlType: VoteApiBaseUrlType = VoteApiBaseUrlType.Sit,
    var customUserId: String = "",
    var logEnable: Boolean = BuildConfig.DEBUG,
    var fontFamily: FontFamily = FontFamily.Default,
    var simpleCN2TraditionalCN: ((String) -> String)? = null,
    var voteTracker: ITrackInterface? = null,
    var httpInterceptors: List<Interceptor> = emptyList(),
    var networkInterceptors: List<Interceptor> = emptyList(),
)

/** 投票接口请求的基础地址类型 **/
sealed interface VoteApiBaseUrlType {

    /** Sit **/
    data object Sit : VoteApiBaseUrlType

    /** Uat **/
    data object Uat : VoteApiBaseUrlType

    /** Prod **/
    data object Prod : VoteApiBaseUrlType

    companion object {

        /**
         * 获取接口请求的基础地址
         * @param type 接口请求的基础地址类型
         */
        internal fun getApiBaseUrl(type: VoteApiBaseUrlType): String {
            return when (type) {
                is Sit -> "https://www-sit-ali.zaobao.com"
                is Uat -> "https://www-uat-ali.zaobao.com"
                is Prod -> "https://polls.zaobao.com" //2026.03.13域名切换：https://polls.zbstatic5.com
            }
        }

    }

}