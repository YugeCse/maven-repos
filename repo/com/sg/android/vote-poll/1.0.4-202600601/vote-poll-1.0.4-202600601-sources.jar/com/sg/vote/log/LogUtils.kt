package com.sg.vote.log

import android.util.Log
import com.sg.vote.BuildConfig


/**
 * @Author: 曹秋淋
 * @Date: 2023/1/6
 * 统一日志输出类
 */
internal object LogUtils {

    private const val DEFAULT_LOG_TAG = "LogUtils"

    /** 是否可以打印日志 **/
    private var mLogEnabled: Boolean = BuildConfig.DEBUG

    /** 设置或获取是否可以打印日志 **/
    var logPrintEnabled: Boolean
        set(value) {
            mLogEnabled = value
        }
        get() = mLogEnabled

    /** 日志打印 **/
    private fun printLog(block: () -> Unit) {
        if (mLogEnabled) block.invoke()
    }

    /**
     * info 级别日志输出
     * @param tag
     * @param msg 打印内容
     */
    @JvmStatic
    fun log4i(
        tag: String = DEFAULT_LOG_TAG,
        msg: String?,
        vararg formatArgs: Any?
    ) = printLog {
        msg?.let {
            Log.i(
                tag,
                if (formatArgs.isEmpty()) it else it.format(*formatArgs)
            )
        }
    }

    /**
     * info 级别日志输出
     * @param tag
     * @param throwable 异常信息
     */
    @JvmStatic
    fun log4i(
        tag: String = DEFAULT_LOG_TAG,
        throwable: Throwable?
    ) = printLog { throwable?.message?.let { Log.i(tag, it) } }

    /**
     * desc 级别日志输出
     * @param tag
     * @param msg 打印内容
     */
    @JvmStatic
    fun log4d(
        tag: String = DEFAULT_LOG_TAG,
        msg: String?,
        vararg formatArgs: Any?
    ) = printLog {
        msg?.let {
            Log.d(
                tag,
                if (formatArgs.isEmpty()) it else it.format(*formatArgs)
            )
        }
    }

    /**
     * desc 级别日志输出
     * @param tag
     * @param throwable 异常信息
     */
    @JvmStatic
    fun log4d(
        tag: String = DEFAULT_LOG_TAG,
        throwable: Throwable?
    ) = printLog { throwable?.message?.let { Log.d(tag, it) } }

    /**
     * waring 级别日志输出
     * @param tag
     * @param msg 打印内容
     */
    @JvmStatic
    fun log4w(
        tag: String = DEFAULT_LOG_TAG,
        msg: String?,
        vararg formatArgs: Any?
    ) = printLog {
        msg?.let {
            Log.w(
                tag,
                if (formatArgs.isEmpty()) it else it.format(*formatArgs)
            )
        }
    }

    /**
     * waring 级别日志输出
     * @param tag
     * @param throwable 打印内容
     */
    @JvmStatic
    fun log4w(
        tag: String = DEFAULT_LOG_TAG,
        throwable: Throwable?
    ) = printLog { throwable?.message?.let { Log.w(tag, it) } }

    /**
     * error 级别日志输出
     * @param tag
     * @param msg 打印内容
     */
    @JvmStatic
    fun log4e(
        tag: String = DEFAULT_LOG_TAG,
        msg: String?,
        vararg formatArgs: Any?
    ) = printLog {
        msg?.let {
            Log.e(
                tag,
                if (formatArgs.isEmpty()) it else it.format(*formatArgs)
            )
        }
    }

    /**
     * error 级别日志输出
     * @param tag
     * @param throwable 异常信息
     */
    @JvmStatic
    fun log4e(
        tag: String = DEFAULT_LOG_TAG,
        throwable: Throwable?
    ) = printLog { throwable?.message?.let { Log.e(tag, it) } }
}