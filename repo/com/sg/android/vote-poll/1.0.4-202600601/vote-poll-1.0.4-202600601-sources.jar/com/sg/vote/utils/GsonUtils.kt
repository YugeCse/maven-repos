package com.sg.vote.utils

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.sg.vote.BuildConfig

/** 字符串转化成JSON对象 **/
internal inline fun <reified T : Any> String.toJsonObject(): T? {
    return try {
        Gson().fromJson<T>(
            this,
            object : TypeToken<T>() {}.type
        )
    } catch (e: Exception) {
        if (BuildConfig.DEBUG)
            e.printStackTrace()
        null
    }
}

/** 转化成JSON字符串 **/
internal fun Any.toJsonString(): String? = Gson().toJson(this)