package com.sg.vote.data.beans

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * 投票选项(答案)信息实体类
 * @param id 选项ID
 * @param itemId 选项归属的问题ID
 * @param title 标题
 * @param img 图片地址，可能不是完成的URL，需要拼接：[VoteDataInfo.assetsPrefix]
 * @param weight 权重，用于排序
 * @param voteCount 投票数(查询统计的接口返回该字段)
 */
@Parcelize
@Serializable
data class VoteAnswerItemInfo(

    @field:SerializedName("id")
    val id: String? = null,

    @field:SerializedName("itemId")
    val itemId: String? = null,

    @field:SerializedName("title")
    val title: String? = null,

    @field:SerializedName("img")
    val img: String? = null,

    @field:SerializedName("weight")
    val weight: Int? = null,

    @field:SerializedName("voteCount")
    val voteCount: Long? = null,
) : Parcelable