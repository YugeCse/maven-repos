package com.sg.vote

import android.content.Context
import androidx.compose.ui.text.font.FontFamily
import com.sg.vote.api.IVotePollApiRepo
import com.sg.vote.api.VotePollApiRepoImpl
import com.sg.vote.data.view.PollRecordInfo
import com.sg.vote.data.view.Site
import com.sg.vote.log.LogUtils
import com.sg.vote.track.ITrackInterface
import com.sg.vote.utils.currentAppLocale
import com.sg.vote.utils.isTraditionalChineseCompat
import okhttp3.Interceptor

/**
 * 投票SDK主类，提供SDK的初始化方法、请求投票数据等
 *
 * @author huangzhongyu@sph.com.sg
 *
 **/
object VotePollSdk : IVotePollApiRepo by VotePollApiRepoImpl.singleton() {

    /** 可用应用的白名单 **/
    private val availableAppWhiteList: List<String> = listOf(
        "com.sph.example", //sdk的demo应用
        "com.zb.sph.chinadev", //联合早报CN测试版
        "com.zb.sph.zaobaochina", //联合早报CN正式版
        "com.zb.sph.zaobaosingapore.debug", //联合早报SG测试版
        "com.zb.sph.zaobaosingapore" //联合早报SG正式版
    )

    /** 是否支持打印日志 **/
    var logEnable: Boolean = BuildConfig.DEBUG
        internal set(value) {
            field = value
            LogUtils.logPrintEnabled = value
        }

    /** 网址关联：zbcom/zbsg **/
    var site: Site = Site.Zbcom
        private set

    /** 接口请求的基础地址 **/
    internal var apiBaseUrl: String = ""
        private set

    /** 获取或设置投票用户ID **/
    var customUserId: String = ""

    /** 获取版本名称，例如：1.0.0 **/
    var version: String = "1.0.0"
        internal set

    /** 获取UI使用的字体 **/
    var fontFamily: FontFamily = FontFamily.Default
        internal set

    /** 是否使用简体中文 **/
    internal var useSimpleCN: Boolean = true

    /** 设置或获取简体中文转繁体中文方法 **/
    var simpleCN2TraditionalCN: ((String) -> String)? = null

    /** 数据埋点对象，宿主APP如果需要埋点，需给该对象实现接口[ITrackInterface] **/
    var voteTracker: ITrackInterface? = null

    /** 网络请求拦截器 **/
    var httpInterceptors: List<Interceptor> = emptyList()

    /** 网络请求拦截器 **/
    var networkInterceptors: List<Interceptor> = emptyList()

    /**
     * 初始化SDK
     * @param context 上下文对象
     * @param config 配置参数
     */
    @JvmStatic
    fun initialize(context: Context, config: VotePollSdkConfig.() -> Unit = {}) {
        val available = (BuildConfig.DEBUG ||
                context.packageName in availableAppWhiteList)
        val votePollSdkConfig = VotePollSdkConfig().apply(config)
        site = votePollSdkConfig.site
        customUserId = votePollSdkConfig.customUserId
        apiBaseUrl = when {
            !available -> ""
            else -> VoteApiBaseUrlType
                .getApiBaseUrl(votePollSdkConfig.apiBaseUrlType)
        }
        logEnable = votePollSdkConfig.logEnable
        fontFamily = votePollSdkConfig.fontFamily
        voteTracker = votePollSdkConfig.voteTracker
        httpInterceptors = votePollSdkConfig.httpInterceptors
        networkInterceptors = votePollSdkConfig.networkInterceptors
        simpleCN2TraditionalCN = votePollSdkConfig.simpleCN2TraditionalCN
        useSimpleCN = !context.currentAppLocale.isTraditionalChineseCompat()
        LogUtils.log4i(
            "VotePollSdk",
            "initialize: VotePollSdk initialized; " +
                    "config = $votePollSdkConfig; 简繁：${if (useSimpleCN) "简体" else "繁体"}"
        )
        clearVoteRecords() //清空内置的投票数据信息
    }

    /** 投票记录字段，用于应用当次记录同步投票的 **/
    private val voteRecords = mutableListOf<PollRecordInfo>()

    /**
     * 获取投票记录
     * @param ssid 用户ssid
     * @param voteId 投票id
     */
    @JvmStatic
    internal fun getVoteRecords(ssid: String?, voteId: String?): PollRecordInfo? {
        if (ssid == null || voteId == null) return null
        return voteRecords.firstOrNull { r -> r.userSsid == ssid && r.voteId == voteId }
    }

    /**
     * 更新投票记录
     * @param ssid 用户ssid
     * @param voteId 投票id
     * @param voteCount 投票数
     */
    @JvmStatic
    internal fun updateVoteRecord(
        ssid: String?,
        voteId: String?,
        voteCount: Int?
    ) {
        val index = voteRecords
            .indexOfFirst { r -> r.userSsid == ssid && r.voteId == voteId }
        if (index < 0) { //如果不存在这个记录，就新增一条记录
            voteRecords.add(
                PollRecordInfo(
                    userSsid = ssid,
                    voteId = voteId,
                    voteCount = voteCount
                )
            )
        } else voteRecords[index] = voteRecords[index].copy(voteCount = voteCount ?: 0)
    }

    /** 清空投票记录数据 **/
    @JvmStatic
    internal fun clearVoteRecords(): Unit = voteRecords.clear()

}