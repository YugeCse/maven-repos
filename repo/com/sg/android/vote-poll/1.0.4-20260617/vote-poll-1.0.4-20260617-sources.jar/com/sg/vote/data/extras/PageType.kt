package com.sg.vote.data.extras

/**
 * 投票UI目标页面类型
 * @param value 页面类型值
 */
sealed class PageType(open val value: String) {

    /** APP首页 **/
    data object AppHomePage : PageType("app_homepage")

    /** APP文章详情页 **/
    data object AppArticle : PageType("app_article")

    /** 网站首页 **/
    data object WebsiteHomePage : PageType("website_homepage")

    /** 网站列表页 **/
    data object WebsiteListing : PageType("website_listing")

    /** 网站文章详情页 **/
    data object WebsiteArticle : PageType("website_article")

    /** 第三方 **/
    data object ThirdPlatform : PageType("third_platform")

    /** 自定义PageType类型 **/
    data class Custom(override val value: String) : PageType(value)

}