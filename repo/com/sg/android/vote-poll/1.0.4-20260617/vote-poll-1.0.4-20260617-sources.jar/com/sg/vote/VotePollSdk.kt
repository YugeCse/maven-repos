package com.sg.vote

import android.annotation.SuppressLint
import android.content.Context
import android.view.Gravity
import android.widget.Toast
import androidx.compose.ui.text.font.FontFamily
import com.sg.vote.api.IVotePollApiRepo
import com.sg.vote.api.VotePollApiRepoImpl
import com.sg.vote.data.view.PollRecordInfo
import com.sg.vote.data.view.Site
import com.sg.vote.log.LogUtils
import com.sg.vote.track.ITrackInterface
import com.sg.vote.utils.currentAppLocale
import com.sg.vote.utils.isTraditionalChineseCompat
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Interceptor
import java.lang.ref.WeakReference

/**
 * 投票SDK主类，提供SDK的初始化方法、请求投票数据等
 *
 * @author huangzhongyu@sph.com.sg
 *
 **/
@SuppressLint("StaticFieldLeak")
object VotePollSdk : IVotePollApiRepo by VotePollApiRepoImpl.singleton() {

    private const val TAG: String = "VotePollSdk"

    /** 缓存context对象 **/
    private var contextRef: WeakReference<Context>? = null

    /** 获取初始化时的Context对象 **/
    val context: Context? get() = contextRef?.get()

    /** 可用应用的白名单 **/
    private val availableAppWhiteList: List<String> = listOf(
        "com.sph.example", //sdk的demo应用
        "com.zb.sph.chinadev", //联合早报CN测试版
        "com.zb.sph.zaobaochina", //联合早报CN正式版
        "com.zb.sph.zaobaosingapore.debug", //联合早报SG测试版
        "com.zb.sph.zaobaosingapore" //联合早报SG正式版
    )

    /** 是否支持打印日志 **/
    var logEnable: Boolean = BuildConfig.DEBUG
        internal set(value) {
            field = value
            LogUtils.logPrintEnabled = value
        }

    /** SDK编译版本 **/
    var sdkVersion: String = BuildConfig.compileVersion

    /** SDK编译日期 **/
    var sdkCompileDate: String = BuildConfig.compileDate

    /** 网址关联：zbcom/zbsg **/
    var site: Site = Site.Zbcom
        private set

    /** 接口请求的基础地址 **/
    internal var apiBaseUrl: String = ""
        private set

    /** 获取或设置投票用户ID **/
    var customUserId: String = ""

    /** 获取版本名称，例如：1.0.0 **/
    var version: String = "1.0.0"
        internal set

    /** 获取UI使用的字体 **/
    var fontFamily: FontFamily = FontFamily.Default
        internal set

    /** 是否使用简体中文 **/
    internal var useSimpleCN: Boolean = true

    /** 设置或获取简体中文转繁体中文方法 **/
    var simpleCN2TraditionalCN: ((String) -> String)? = null

    /** 数据埋点对象，宿主APP如果需要埋点，需给该对象实现接口[ITrackInterface] **/
    var voteTracker: ITrackInterface? = null

    /** 网络请求拦截器 **/
    var httpInterceptors: List<Interceptor> = emptyList()

    /** 网络请求拦截器 **/
    var networkInterceptors: List<Interceptor> = emptyList()

    /** 显示Toast信息的回调，用于显示成功/错误等信息 **/
    var showToastMessage: (String) -> Unit = { msg ->
        context?.let {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).apply {
                setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, 260)
            }.show()
        }
    }

    /** 显示Toast信息的回调 **/
    internal var showToastMessageById: (msgId: Int) -> Unit = { msgId ->
        context?.let { ctx -> showToastMessage(ctx.getString(msgId)) }
    }

    /**
     * 初始化SDK
     * @param context 上下文对象
     * @param config 配置参数
     */
    @JvmStatic
    fun initialize(context: Context, config: VotePollSdkConfig.() -> Unit = {}) {
        if (contextRef == null)
            contextRef = WeakReference(context.applicationContext) //使用Context引用
        val available = (BuildConfig.DEBUG ||
                context.packageName in availableAppWhiteList)
        val votePollSdkConfig = VotePollSdkConfig().apply(config)
        site = votePollSdkConfig.site
        customUserId = votePollSdkConfig.customUserId
        apiBaseUrl = when {
            !available -> ""
            else -> VoteApiBaseUrlType
                .getApiBaseUrl(votePollSdkConfig.apiBaseUrlType)
        }
        logEnable = votePollSdkConfig.logEnable
        fontFamily = votePollSdkConfig.fontFamily
        voteTracker = votePollSdkConfig.voteTracker
        httpInterceptors = votePollSdkConfig.httpInterceptors
        networkInterceptors = votePollSdkConfig.networkInterceptors
        simpleCN2TraditionalCN = votePollSdkConfig.simpleCN2TraditionalCN
        useSimpleCN = !context.currentAppLocale.isTraditionalChineseCompat()
        LogUtils.log4i(
            TAG,
            "initialize: VotePollSdk initialized; " +
                    "config = $votePollSdkConfig; 简繁：${if (useSimpleCN) "简体" else "繁体"}"
        )
        // clearVoteRecords() //清空内置的投票数据信息
    }

    /** 投票记录同步锁 **/
    private val voteRecordLock = Mutex()

    /** 投票记录字段，用于应用当次记录同步投票的 **/
    private val voteRecords = mutableListOf<PollRecordInfo>()

    /**
     * 获取投票记录(获取时，会对比用户id/voteId)
     * @param ssid 用户ssid
     * @param voteId 投票id
     * @return 获取匹配到的投票记录信息
     */
    @JvmStatic
    internal suspend fun getVoteRecords(
        ssid: String?,
        voteId: String?
    ): PollRecordInfo? {
        if (ssid == null || voteId == null) return null
        return voteRecordLock.withLock {
            voteRecords.firstOrNull { r -> r.userSsid == ssid && r.voteId == voteId }
                ?.also { recordInfo ->
                    LogUtils.log4i(
                        TAG,
                        "调用了[getVoteRecords], 投票记录：voteId=${recordInfo.voteId},voteCount=${recordInfo.voteCount}"
                    )
                }
        }
    }

    /**
     * 更新投票记录
     * @param ssid 用户ssid
     * @param voteId 投票id
     * @param voteCount 投票数
     */
    @JvmStatic
    internal suspend fun updateVoteRecord(
        ssid: String?,
        voteId: String?,
        voteCount: Int?
    ) {
        voteRecordLock.withLock {
            val index = voteRecords.indexOfFirst { r ->
                r.userSsid == ssid && r.voteId == voteId
            }
            if (index < 0) { //如果不存在这个记录，就新增一条记录
                voteRecords.add(
                    PollRecordInfo(
                        userSsid = ssid,
                        voteId = voteId,
                        voteCount = voteCount
                    )
                )
            } else {
                voteRecords[index] =
                    voteRecords[index].copy(voteCount = voteCount ?: 0)
            }
            LogUtils.log4i(
                TAG,
                "调用了[updateVoteRecord], 投票记录：voteId=${voteId},voteCount=${voteCount}"
            )
        }
    }

    /** 清空投票记录数据 **/
    @JvmStatic
    internal suspend fun clearVoteRecords() {
        voteRecordLock.withLock {
            voteRecords.clear().also {
                LogUtils.log4i(TAG, "调用了[clearVoteRecords], 清空了本地投票记录")
            }
        }
    }

}