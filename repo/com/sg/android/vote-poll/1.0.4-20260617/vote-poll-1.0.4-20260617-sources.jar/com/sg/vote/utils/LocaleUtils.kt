package com.sg.vote.utils

import android.content.Context
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalConfiguration
import java.util.Locale

/** 获取当前APP使用的语言类型 **/
internal val Context.currentAppLocale: Locale
    get() {
        val config = resources.configuration
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.locales[0]
        } else {
            @Suppress("DEPRECATION") config.locale
        }
    }

/**
 * 监听APP语言类型变化
 * @param onLocaleChanged 语言类型变化回调
 */
@Composable
internal fun ObserveAppLocale(onLocaleChanged: (Locale) -> Unit) {
    val configuration = LocalConfiguration.current
    val locale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        configuration.locales[0]
    } else {
        @Suppress("DEPRECATION") configuration.locale
    }
    LaunchedEffect(locale) { onLocaleChanged(locale) }
}

/**
 * 是否是繁体中文
 * @return 是否是繁体中文
 */
internal fun Locale.isTraditionalChineseCompat(): Boolean {
    if (language != "zh") return false
    when (script) {
        "Hant" -> return true
        "Hans" -> return false
    }
    // script 为空时，用地区兜底
    return when (country) {
        "TW", // 台湾
        "HK", // 香港
        "MO"  // 澳门
            -> true

        "CN", // 中国大陆
        "SG", // 新加坡
        "MY"  // 马来西亚
            -> false

        else -> false // 默认不当成繁体
    }
}
