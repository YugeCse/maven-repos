package com.sg.vote.view.handler

import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.extras.VoteExecResult
import com.sg.vote.view.InnerVotePollViewState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


/**
 * 投票视图事件处理类
 * @param coroutineScope 协程作用域
 * @param state 投票视图状态
 * @param eventHandler 事件处理
 */
internal class VotePollViewEventHandlerImpl(
    private val coroutineScope: CoroutineScope,
    private val state: InnerVotePollViewState,
    private val eventHandler: VotePollViewEventHandler?,
) : InternalVotePollViewEventHandler {

    override fun onVoteOptionsLoaded(pageType: String?, data: VoteDataInfo?) {
        super.onVoteOptionsLoaded(pageType, data)
        eventHandler?.onVoteOptionsLoaded(pageType, data)
    }

    override fun onVoteOptionsLoadError(voteId: String?, pageType: String?) {
        super.onVoteOptionsLoadError(voteId, pageType)
        eventHandler?.onVoteOptionsLoadError(voteId, pageType)
    }

    override fun onVoteTitleClick(data: VoteDataInfo?, url: String?) {
        super.onVoteTitleClick(data, url)
        eventHandler?.onVoteTitleClick(data, url)
    }

    override fun onVoteExtLinkClick(data: VoteDataInfo?, url: String?) {
        super.onVoteExtLinkClick(data, url)
        eventHandler?.onVoteExtLinkClick(data, url)
    }

    override fun onLinkButtonClick(data: VoteDataInfo?, url: String?) {
        super.onLinkButtonClick(data, url)
        eventHandler?.onLinkButtonClick(data, url)
    }

    override fun onExecVoteClick(
        data: Pair<String?, List<VoteAnswerItemInfo>>,
        voteData: VoteDataInfo?,
        onPollVoted: (VoteExecResult) -> Unit
    ) {
        super.onExecVoteClick(data, voteData, onPollVoted)
        coroutineScope.launch {
            val result =
                state.execVote(data.second.mapNotNull { it.id })
            if (voteData?.isVotePollEnded == true) {
                onVotePollFailed(result.message)
                return@launch //投票活动结束了，直接Return, 不需要去执行下面的回调方法了
            }
            withContext(Dispatchers.Main) {
                if (result is VoteExecResult.Success)
                    onVotePollSuccess(
                        data = voteData,
                        selectedItems = data.second,
                        voteCount = voteData?.item?.userCount?.plus(1) ?: 1
                    )
                else onVotePollFailed(message = result.message)
                onPollVoted(result) //投票的执行结果反馈回去
                eventHandler?.onExecVoteClick(data, voteData, onPollVoted)
            }
        }
    }

    override fun onVotePollFailed(message: String?) {
        super.onVotePollFailed(message)
        eventHandler?.onVotePollFailed(message)
    }

    override fun onVotePollSuccess(
        data: VoteDataInfo?,
        selectedItems: List<VoteAnswerItemInfo>?,
        voteCount: Int?
    ) {
        super.onVotePollSuccess(data, selectedItems, voteCount)
        eventHandler?.onVotePollSuccess(data, selectedItems, voteCount)
    }

    override fun onTrackVoteClick(
        pageType: String?,
        selectedOptionTitle: String?,
        voteDataInfo: VoteDataInfo?
    ) {
        super.onTrackVoteClick(pageType, selectedOptionTitle, voteDataInfo)
        eventHandler?.onTrackVoteClick(pageType, selectedOptionTitle, voteDataInfo)
    }

    override fun onTrackVoteAgainClick(
        pageType: String?,
        voteDataInfo: VoteDataInfo?
    ) {
        super.onTrackVoteAgainClick(pageType, voteDataInfo)
        eventHandler?.onTrackVoteAgainClick(pageType, voteDataInfo)
    }
}