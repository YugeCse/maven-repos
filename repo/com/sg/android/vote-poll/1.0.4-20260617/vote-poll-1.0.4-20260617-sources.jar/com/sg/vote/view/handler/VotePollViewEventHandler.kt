package com.sg.vote.view.handler

import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.extras.VoteExecResult


/** 投票卡片视图状态管理类接口 **/
interface VotePollViewEventHandler {

    /**
     * 投票标题点击事件
     * @param data 投票信息
     * @param url 关联的链接
     */
    fun onVoteTitleClick(data: VoteDataInfo?, url: String?) {}

    /**
     * 投票扩展文文本链接点击事件
     * @param data 投票信息
     * @param url 关联的链接
     */
    fun onVoteExtLinkClick(data: VoteDataInfo?, url: String?) {}

    /**
     * 去投票旁边的扩展按钮的点击事件，一般为：去抽奖
     * @param data 投票信息
     * @param url 关联的链接
     */
    fun onLinkButtonClick(data: VoteDataInfo?, url: String?) {}

    /**
     * 发起投票按钮的点击事件
     * @param data 投票信息 投票ID:投票选项
     * @param voteData 投票数据
     * @param onPollVoted 投票结果回调, params:是否投票成功 是否达到投票限制
     */
    fun onExecVoteClick(
        data: Pair<String?, List<VoteAnswerItemInfo>>,
        voteData: VoteDataInfo?,
        onPollVoted: (VoteExecResult) -> Unit
    ) {
    }

    /**
     * 投票成功
     * @param data 投票的数据实体对象
     * @param selectedItems 选中的投票答案
     * @param voteCount 用户当前投票数
     */
    fun onVotePollSuccess(
        data: VoteDataInfo?,
        selectedItems: List<VoteAnswerItemInfo>?,
        voteCount: Int?
    ) {
    }

    /** 投票失败 **/
    fun onVotePollFailed(message: String?) {}

    /**
     * 投票选项加载成功
     * @param pageType 页面类型
     * @param data 投票数据
     */
    fun onVoteOptionsLoaded(pageType: String?, data: VoteDataInfo?) {}

    /**
     * 投票选项加载失败
     * @param voteId 投票ID
     * @param pageType 页面类型
     */
    fun onVoteOptionsLoadError(voteId: String?, pageType: String?) {}

    /**
     * 投票点击事件埋点
     * @param pageType 投票活动pageType
     * @param selectedOptionTitle 投票选项名称
     * @param voteDataInfo 投票信息
     */
    fun onTrackVoteClick(
        pageType: String?,
        selectedOptionTitle: String?,
        voteDataInfo: VoteDataInfo?
    ) {
    }

    /**
     * 再次投票的点击事件埋点
     * @param pageType 投票活动pageType
     * @param voteDataInfo 投票信息
     */
    fun onTrackVoteAgainClick(pageType: String?, voteDataInfo: VoteDataInfo?) {}

}