package com.sg.vote.view

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.util.fastForEachIndexed
import com.sg.common.theme.LocalColorPallet
import com.sg.common.theme.LocalDimens
import com.sg.common.theme.LocalUiUseDarkTheme
import com.sg.common.theme.TypographyScaleType.Companion.calculateForNewsList
import com.sg.common.theme.TypographyType
import com.sg.vote.R
import com.sg.vote.VotePollSdk
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.data.beans.VoteQuestionInfo
import com.sg.vote.data.beans.VoteSettingInfo
import com.sg.vote.data.beans.getVoteLimitDescriptionText
import com.sg.vote.data.extras.PollState
import com.sg.vote.data.extras.VoteExecResult
import com.sg.vote.data.view.LocalVoteCardViewConfig
import com.sg.vote.utils.DeviceUtils
import com.sg.vote.utils.applyTestTag
import com.sg.vote.utils.pixelToDip
import com.sg.vote.utils.singleClickable
import com.sg.vote.view.handler.InternalVotePollViewEventHandler
import com.sg.vote.view.handler.VotePollViewEventHandler
import com.sg.vote.view.options.InternalVoteExpandedGridView
import com.sg.vote.view.options.InternalVoteOptionGridItemView
import com.sg.vote.view.options.InternalVoteOptionListItemView
import com.sg.vote.view.other.CardDividerView
import com.sg.vote.view.preview.DefaultPreview
import com.sg.vote.view.zaobao.ZbText
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 投票卡片视图
 * @param modifier Modifier
 * @param pageType 投票数据的pageType
 * @param data 投票信息(可能包含投票结果信息)
 * @param event 投票卡片视图事件管理类
 **/
@Composable
internal fun InternalVotePollView(
    modifier: Modifier = Modifier,
    pageType: String? = null,
    data: VoteDataInfo? = null,
    event: VotePollViewEventHandler = remember { object : InternalVotePollViewEventHandler {} },
) = Column(
    modifier = Modifier
        .applyTestTag("internal_vote_poll_view")
        .then(modifier)
        .fillMaxWidth()
        .background(LocalColorPallet.current.backgroundPrimary)
) {
    val context = LocalContext.current
    val isInEditMode = LocalInspectionMode.current
    val config = LocalVoteCardViewConfig.current
    val borderInfo = remember(config) { config.pollCardViewBorder }
    val typographyScaleType = remember(config) { config.typographyScaleType }
    val useSimpleCNText = remember(config) { config.useSimpleCN } //是否使用简体中文
    var enforceRefreshKeyForVotePollView by remember { mutableLongStateOf(0L) }
    var enforceRefreshKeyForGridLayout by remember { mutableStateOf<String?>(null) }

    /** 投票按钮执行次数，没有执行过投票，就不展示投票结果信息; 偶数次才能投票，否则只能是继续投票点击后返回投票状态 **/
    var execVoteButtonCount by rememberSaveable { mutableIntStateOf(0) }
    CardDividerView(
        borderConfig = borderInfo?.top,
        paddingHorizontal = config.pollCardHorizontalPadding
    )
    key(enforceRefreshKeyForVotePollView) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(LocalColorPallet.current.backgroundPrimary)
                .padding(
                    vertical = LocalDimens.current.dp16,
                    horizontal = config.pollCardHorizontalPadding
                ),
            horizontalAlignment = Alignment.Start
        ) {
            ZbText(
                modifier = Modifier.applyTestTag("vote_poll_view_title"),
                text = stringResource(R.string.app_user_vote_poll_title),
                color = when {
                    !LocalUiUseDarkTheme.current ->
                        LocalColorPallet.current.textEmphasis

                    else -> LocalColorPallet.current.linkEmphasisDefault
                },
                type = TypographyType.Header2,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
            val voteTitleInteractionSource = remember { MutableInteractionSource() }
            val voteQuestionTitle = remember(useSimpleCNText, data?.item?.name) {
                val funIcu = VotePollSdk.simpleCN2TraditionalCN
                if (!useSimpleCNText && funIcu != null) {
                    funIcu.invoke(data?.item?.name ?: "")
                } else data?.item?.name ?: ""
            }
            ZbText(
                modifier = Modifier
                    .applyTestTag("tv_vote_title")
                    .padding(top = LocalDimens.current.dp16)
                    .run {
                        if (data?.item?.link.isNullOrEmpty()) this
                        else singleClickable(
                            useLocalIndication = false,
                            interactionSource = voteTitleInteractionSource
                        ) { event.onVoteTitleClick(data, data.item.link) }
                    },
                text = voteQuestionTitle,
                color = when {
                    data?.item?.link.isNullOrEmpty() ->
                        LocalColorPallet.current.textEmphasis

                    else -> LocalColorPallet.current.linkInComponentBrandSecondary
                },
                type = TypographyType.Header4,
                scaleType = with(typographyScaleType) { calculateForNewsList }
            )
            if (data?.showTime == true) { //如果需要显示活动时间的话
                ZbText(
                    modifier = Modifier
                        .applyTestTag("tv_vote_event_time")
                        .padding(top = LocalDimens.current.dp5),
                    text = stringResource(
                        R.string.app_user_vote_poll_activity_time,
                        (data.activityTime ?: "")
                    ),
                    color = LocalColorPallet.current.textPrimary,
                    type = TypographyType.Body2,
                    scaleType = with(typographyScaleType) { calculateForNewsList }
                )
            }
            if (data?.setting?.showImages != true) {
                HorizontalDivider(
                    thickness = LocalDimens.current.dp1,
                    color = LocalColorPallet.current.dividerPrimary,
                    modifier = Modifier.padding(top = LocalDimens.current.dp16)
                )
            }
            val voteLinkText = remember(useSimpleCNText, data?.linkText) {
                val funIcu = VotePollSdk.simpleCN2TraditionalCN
                if (!useSimpleCNText && funIcu != null) {
                    funIcu.invoke(data?.linkText ?: "")
                } else data?.linkText ?: ""
            }
            if (voteLinkText.isNotEmpty() && !data?.linkUrl.isNullOrEmpty()) {
                ZbText(
                    modifier = Modifier
                        .applyTestTag("tv_vote_sub_title")
                        .padding(top = LocalDimens.current.dp16)
                        .run {
                            if (data.linkUrl.isEmpty()) this
                            else singleClickable { event.onVoteExtLinkClick(data, data.linkUrl) }
                        },
                    text = voteLinkText,
                    color = LocalColorPallet.current.linkInComponentBrandSecondary,
                    type = TypographyType.Label8,
                    scaleType = with(typographyScaleType) { calculateForNewsList }
                )
            }
            var isMarkVoteResult by rememberSaveable { mutableStateOf(false) }
            var userSelectIndex by rememberSaveable(data?.id) { mutableStateOf<Int?>(null) }
            val voteStateInfo by produceState<Pair<String, PollState>>(
                key1 = data,
                key2 = isInEditMode,
                initialValue = Pair("", PollState.ContinueVote)
            ) {
                var newVoteData = data?.copy() //复制一份投票数据
                if (!isInEditMode) {
                    val voteRecord = VotePollSdk.getVoteRecords(
                        ssid = VotePollSdk.customUserId,
                        voteId = data?.item?.voteId
                    )
                    voteRecord?.voteCount?.let { userVoteCount ->
                        if (userVoteCount > (data?.item?.userCount ?: 0)) {
                            newVoteData =
                                newVoteData?.copy(item = newVoteData.item?.copy(userCount = userVoteCount))
                        }
                    }
                }
                value = newVoteData
                    ?.getVoteLimitDescriptionText(context) ?: Pair("", PollState.ContinueVote)
            }
            val (voteTipMessage, pollState) = remember(voteStateInfo) { voteStateInfo }
            LaunchedEffect(execVoteButtonCount) {
                if (execVoteButtonCount % 2 != 0)
                    return@LaunchedEffect
                userSelectIndex = null //还原投票状态，设置未选中状态
            }
            if (data?.setting?.showImages != true) { // 如果不展示图片，则只展示文本
                Column(
                    modifier = Modifier
                        .applyTestTag("v_vote_list_item_views")
                        .padding(top = LocalDimens.current.dp2)
                        .fillMaxWidth()
                ) {
                    data?.item?.answers?.fastForEachIndexed { index, item ->
                        InternalVoteOptionListItemView(
                            modifier = Modifier.padding(top = LocalDimens.current.dp16),
                            data = item,
                            voteTotalCount = data.item.itemTotal?.toLong() ?: 0L,
                            isMarkVoteResult = isMarkVoteResult,
                            showResult = (data.setting?.showResult == true) &&
                                    (execVoteButtonCount % 2 != 0 || pollState is PollState.LimitVote),
                            // assertUrlPrefix = data.assetsPrefix,
                            onClick = when {
                                ((!data.isVotePollStarted &&
                                        !data.hasVoteButton)
                                        || execVoteButtonCount % 2 != 0) ||
                                        pollState is PollState.LimitVote -> null

                                else -> fun() {
                                    if (index != userSelectIndex && userSelectIndex != null)
                                        isMarkVoteResult = false
                                    userSelectIndex = index  //赋值新的选中项
                                }
                            },
                            isSelected = userSelectIndex == index,
                        )
                    }
                }
            } else Column(
                modifier = Modifier
                    .padding(top = LocalDimens.current.dp20)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val voteItemCardHeight = remember { mutableStateMapOf<Int?, Int?>() }
                LaunchedEffect(execVoteButtonCount) {
                    if (execVoteButtonCount % 2 == 0) {
                        voteItemCardHeight.clear() //清空原来记录的数据集合
                    }
                }
                LaunchedEffect(typographyScaleType) { voteItemCardHeight.clear() }
                InternalVoteExpandedGridView(
                    modifier = Modifier
                        .applyTestTag("v_vote_grid_item_views")
                        .fillMaxWidth(),
                    enforceRefreshKey = enforceRefreshKeyForGridLayout,
                    typographyScaleType = typographyScaleType,
                    inputDataSource = data.item?.answers ?: emptyList(),
                ) { rowIndex, dataIndex, itemData ->
                    InternalVoteOptionGridItemView(
                        modifier = Modifier
                            .fillMaxWidth()
                            .onSizeChanged { size ->
                                if (voteItemCardHeight.isEmpty()) {
                                    voteItemCardHeight[rowIndex] = size.height
                                } else {
                                    if (size.height > (voteItemCardHeight[rowIndex] ?: 0)) {
                                        voteItemCardHeight[rowIndex] = size.height
                                    }
                                }
                            }
                            .sizeIn(minHeight = pixelToDip(voteItemCardHeight[rowIndex] ?: 0)),
                        data = itemData,
                        voteTotalCount = data.item?.itemTotal?.toLong() ?: 0L,
                        showResult = (data.setting.showResult == true) &&
                                (execVoteButtonCount % 2 != 0 || pollState is PollState.LimitVote),
                        showImage = data.setting.showImages,
                        showText = data.setting.showAnswerTitle == true,
                        isMarkVoteResult = isMarkVoteResult,
                        assertUrlPrefix = data.assetsPrefix,
                        onClick = when {
                            ((data.started != true &&
                                    !data.hasVoteButton) ||
                                    execVoteButtonCount % 2 != 0) ||
                                    pollState is PollState.LimitVote -> null

                            else -> fun() {
                                if (dataIndex != userSelectIndex && userSelectIndex != null)
                                    isMarkVoteResult = false
                                userSelectIndex = dataIndex //重新赋值用户选中的索引
                            }
                        },
                        isSelected = userSelectIndex == dataIndex,
                    )
                }
            }
            val isVoteButNotNeedResult = run {
                execVoteButtonCount % 2 != 0 &&
                        data?.setting?.showResult != true &&
                        pollState is PollState.ContinueVote
            }
            val hasFirstVoteInfoText = run {
                isVoteButNotNeedResult || (((execVoteButtonCount > 0 &&
                        execVoteButtonCount % 2 != 0 &&
                        pollState !is PollState.LimitVote)) &&
                        data?.setting?.showResult == true && data.item?.itemTotal != null)
            }
            if (hasFirstVoteInfoText) { //投票已结束，并且要展示投票结果的
                ZbText(
                    modifier = Modifier
                        .applyTestTag("tv_vote_tip1")
                        .padding(
                            top = LocalDimens.current.dp32,
                            start = LocalDimens.current.dp16,
                            end = LocalDimens.current.dp16
                        )
                        .fillMaxWidth(),
                    text = when {
                        isVoteButNotNeedResult ->
                            stringResource(R.string.app_user_vote_poll_thanks)

                        data?.isVotePollEnded == true ->
                            stringResource(
                                R.string.app_user_vote_poll_total_count,
                                data.item?.itemTotal?.toLong() ?: 0L
                            )

                        else -> stringResource(
                            (if (execVoteButtonCount == 0)
                                R.string.app_user_vote_poll_vote_count_only
                            else R.string.app_user_vote_poll_vote_count),
                            data?.item?.itemTotal?.toLong() ?: 0L
                        )
                    },
                    textAlign = TextAlign.Center,
                    color = LocalColorPallet.current.textSecondary,
                    type = TypographyType.Label2,
                    scaleType = with(typographyScaleType) { calculateForNewsList }
                )
            }
            if ((((execVoteButtonCount > 0 &&
                        execVoteButtonCount % 2 != 0) ||
                        data?.hasVoteButton != true) &&
                        voteTipMessage.isNotEmpty() &&
                        (data?.setting?.showResult != true ||
                                (data.setting.showResult && data.item?.itemTotal != null))) ||
                pollState is PollState.LimitVote //如果已经是被限制投票的状态了，应该展示限制投票的信息
            ) {
                ZbText(
                    modifier = Modifier
                        .applyTestTag("tv_vote_tip2")
                        .padding(
                            top = when {
                                hasFirstVoteInfoText ->
                                    LocalDimens.current.dp0

                                else -> LocalDimens.current.dp32
                            },
                            start = LocalDimens.current.dp16,
                            end = LocalDimens.current.dp16
                        )
                        .fillMaxWidth(),
                    text = voteTipMessage,
                    textAlign = TextAlign.Center,
                    color = LocalColorPallet.current.textSecondary,
                    type = TypographyType.Label2,
                    scaleType = with(typographyScaleType) { calculateForNewsList }
                )
            }
            if (data?.setting?.hasLinkButton == true || data?.hasVoteButton == true) {
                Row(
                    modifier = Modifier
                        .padding(vertical = LocalDimens.current.dp16)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(
                        LocalDimens.current.dp16,
                        Alignment.CenterHorizontally
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (data.setting?.hasLinkButton == true && execVoteButtonCount % 2 != 0) {
                        FlatButton(
                            onClick = { event.onLinkButtonClick(data, data.setting.link) },
                            modifier = Modifier.applyTestTag("btn_vote_other"),
                            colors = ButtonDefaults.buttonColors(
                                contentColor = LocalColorPallet.current.buttonSecondaryLabel,
                                containerColor = LocalColorPallet.current.buttonSecondaryDefault,
                            ),
                        ) {
                            val voteLinkLabel = remember(
                                useSimpleCNText,
                                data.setting.linkLabel
                            ) {
                                val funIcu = VotePollSdk.simpleCN2TraditionalCN
                                if (!useSimpleCNText && funIcu != null) {
                                    funIcu.invoke(data.setting.linkLabel ?: "")
                                } else data.setting.linkLabel ?: ""
                            }
                            ZbText(
                                text = voteLinkLabel,
                                type = TypographyType.Button1,
                                scaleType = with(typographyScaleType) { calculateForNewsList }
                            )
                        }
                    }
                    if (data.hasVoteButton) { // 已结束的活动，不再展示投票的按钮
                        val isVotePollRequesting = remember { AtomicBoolean(false) }
                        FlatButton(
                            onClick = {
                                //如果执行过投票了，按钮会变成继续投票，再点击一次才能投票
                                if (!data.isVotePollEnded &&
                                    execVoteButtonCount % 2 != 0
                                ) {
                                    userSelectIndex = null //置空用户选中项目
                                    execVoteButtonCount++ //变成偶数才能继续投票
                                    enforceRefreshKeyForGridLayout =
                                        System.currentTimeMillis().toString()
                                    event.onTrackVoteAgainClick(pageType, data)
                                    return@FlatButton
                                }
                                val voteInfo = data.item ?: return@FlatButton
                                val voteAnswerItemInfo = voteInfo.answers
                                    ?.getOrNull(userSelectIndex ?: return@FlatButton)
                                    ?: return@FlatButton
                                if (isVotePollRequesting.get())
                                    return@FlatButton
                                isVotePollRequesting.set(true) //标记正在发起请求
                                event.onExecVoteClick(
                                    voteData = data,
                                    data = voteInfo.voteId to listOf(voteAnswerItemInfo)
                                ) { callback ->
                                    if (callback is VoteExecResult.Success) {
                                        isMarkVoteResult = true //需要标记投票结果
                                        execVoteButtonCount++ //标记执行了投票了
                                    } else if (callback is VoteExecResult.Limited) {
                                        isMarkVoteResult = true //需要标记投票结果
                                        execVoteButtonCount++ //标记执行了投票了
                                    }
                                    isVotePollRequesting.set(false) //标记请求发起结束
                                }
                                if (data.isVotePollEnded) {
                                    isVotePollRequesting.set(false)
                                } else {
                                    event.onTrackVoteClick(pageType, voteAnswerItemInfo.title, data)
                                }
                            },
                            modifier = Modifier
                                .applyTestTag(tag = "btn_exec_vote")
                                .alpha(
                                    if (userSelectIndex == null ||
                                        pollState is PollState.LimitVote
                                    ) 0.4f else 1.0f
                                ),
                            enabled = run {
                                data.item?.answers
                                    ?.indices
                                    ?.contains(userSelectIndex) == true &&
                                        pollState is PollState.ContinueVote
                                //⚠️：达到投票上限了，应该是禁用投票按钮，而不是让其不显示
                            },
                            colors = ButtonColors(
                                containerColor = LocalColorPallet.current.buttonPrimaryDefault,
                                contentColor = LocalColorPallet.current.buttonPrimaryLabel,
                                disabledContentColor = LocalColorPallet.current.buttonPrimaryLabel,
                                disabledContainerColor = LocalColorPallet.current.buttonPrimaryDefault
                            ),
                        ) {
                            ZbText(
                                text = stringResource(
                                    if (execVoteButtonCount % 2 == 0 ||
                                        pollState is PollState.LimitVote
                                    ) R.string.app_user_vote_poll_exec
                                    else R.string.app_user_vote_poll_exec_again
                                ),
                                type = TypographyType.Button1,
                                scaleType = with(typographyScaleType) { calculateForNewsList }
                            )
                        }
                    }
                }
            }
        }
    }
    CardDividerView(
        borderConfig = borderInfo?.bottom,
        paddingHorizontal = config.pollCardHorizontalPadding
    )
}

/**
 * 扁平按钮
 * @param modifier 修饰器
 * @param enabled 是否可用
 * @param colors 颜色
 * @param contentPadding 内间距
 * @param onClick 点击事件
 * @param content 内容区域
 */
@Composable
private fun FlatButton(
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    contentPadding: PaddingValues? = null,
    onClick: () -> Unit,
    content: @Composable RowScope.() -> Unit
) {
    val context = LocalContext.current
    val currentOnClick by rememberUpdatedState(onClick)
    Button(
        modifier = modifier,
        enabled = enabled,
        colors = colors,
        content = content,
        onClick = currentOnClick,
        contentPadding = contentPadding ?: PaddingValues(
            horizontal = LocalDimens.current.dp16,
            vertical = if (DeviceUtils.isTablet(context))
                LocalDimens.current.dp8 else LocalDimens.current.dp6
        ),
    )
}

/** 效果预览方法 **/
@Composable
@Preview(name = "投票组件-浅色")
@Preview(name = "投票组件-深色", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVotePollView() = DefaultPreview {
    InternalVotePollView(
        data = VoteDataInfo(
            title = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
            item = VoteQuestionInfo(
                name = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
                answers = listOf(
                    VoteAnswerItemInfo(
                        img = "a",
                        title = "会。DeepSeek重新定义AI技术发展，让中国弯道超车"
                    ),
                    VoteAnswerItemInfo(
                        title = "不一定。它是中国科技重大进步，但影响是渐进的"
                    ),
                    VoteAnswerItemInfo(
                        title = "不会。它的影响被夸大，中国在AI领域与美国有很大差距"
                    ),
                    VoteAnswerItemInfo(
                        title = "现在下结论为时尚早，还需更多评测和反馈"
                    )
                )
            ),
            showTime = true, startTime = 1752722176811, endTime = 1752733176811
        )
    )
}

/** 效果预览方法 **/
@Composable
@Preview(name = "投票组件-浅色")
@Preview(name = "投票组件-深色", uiMode = Configuration.UI_MODE_NIGHT_YES)
private fun PreviewInternalVotePollView2() = DefaultPreview {
    InternalVotePollView(
        data = VoteDataInfo(
            title = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
            item = VoteQuestionInfo(
                name = "OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑，你对此有何看法？",
                link = "https://www.baidu.com",
                answers = listOf(
                    VoteAnswerItemInfo(
                        voteCount = 2,
                        img = "https://www.baidu.com/a.png",
                        title = "会 OpenAI发布首个视频生成模型Sora，在中国科技圈引发对自身AI发展水平的焦虑"
                    ),
                    VoteAnswerItemInfo(
                        voteCount = 3,
                        img = "https://www.baidu.com/a.png",
                        title = "不一定"
                    ),
                    VoteAnswerItemInfo(
                        voteCount = 5,
                        img = "https://www.baidu.com/a.png",
                        title = "不会"
                    ),
                    // VoteAnswerItemInfo(
                    //     img = "https://www.baidu.com/a.png",
                    //     title = "下结论为时尚早"
                    // )
                ),
                itemTotal = 10
            ),
            setting = VoteSettingInfo(
                showImages = true,
                showAnswerTitle = true,
                linkLabel = "去抽奖",
                link = "ccc"
            )
        ),
        modifier = Modifier.fillMaxWidth()
    )
}