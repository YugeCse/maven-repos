package com.sg.vote.view.handler

import android.os.Bundle
import com.sg.vote.R
import com.sg.vote.VotePollSdk
import com.sg.vote.data.beans.VoteAnswerItemInfo
import com.sg.vote.data.beans.VoteDataInfo
import com.sg.vote.track.VoteTrackData
import com.sg.vote.track.VoteTrackEvent


/** 投票卡片视图状态管理类接口 **/
internal interface InternalVotePollViewEventHandler : VotePollViewEventHandler {

    /**
     * 投票标题点击事件
     * @param data 投票信息
     * @param url 关联的链接
     */
    override fun onVoteTitleClick(data: VoteDataInfo?, url: String?) {
        VotePollSdk.voteTracker?.let { tracker ->
            val bundle = Bundle().apply {
                putParcelable("vote_data", data)
                putString("vote_title_link", url)
                putString("vote_title", data?.item?.name)
            }
            tracker.sendEvent(VoteTrackEvent.VoteTitleClick(VoteTrackData.BundleObject(bundle)))
        }
    }

    /**
     * 投票扩展文文本链接点击事件
     * @param data 投票信息
     * @param url 关联的链接
     */
    override fun onVoteExtLinkClick(data: VoteDataInfo?, url: String?) {
        VotePollSdk.voteTracker?.let { tracker ->
            val bundle = Bundle().apply {
                putParcelable("vote_data", data)
                putString("vote_ext_link", url)
                putString("vote_ext_link_text", data?.linkText)
            }
            tracker.sendEvent(VoteTrackEvent.VoteExtLinkClick(VoteTrackData.BundleObject(bundle)))
        }
    }

    /**
     * 去投票旁边的扩展按钮的点击事件，一般为：去抽奖
     * @param data 投票信息
     * @param url 关联的链接
     */
    override fun onLinkButtonClick(data: VoteDataInfo?, url: String?) {
        VotePollSdk.voteTracker?.let { tracker ->
            val bundle = Bundle().apply {
                putParcelable("vote_data", data)
                putString("vote_ext_link", url)
                putString("vote_ext_link_text", data?.setting?.linkLabel)
            }
            tracker.sendEvent(VoteTrackEvent.VoteLinkButtonClick(VoteTrackData.BundleObject(bundle)))
        }
    }

    /**
     * 投票成功
     * @param data 投票的数据实体对象
     * @param selectedItems 选中的投票答案
     * @param voteCount 用户当前投票数
     */
    override fun onVotePollSuccess(
        data: VoteDataInfo?,
        selectedItems: List<VoteAnswerItemInfo>?,
        voteCount: Int?
    ) {
        VotePollSdk.context?.let { context ->
            VotePollSdk.showToastMessage(
                context.getString(R.string.app_user_vote_poll_success)
            )
        }
        VotePollSdk.voteTracker?.let { tracker ->
            val bundle = Bundle().apply {
                putParcelable("vote_data", data)
                putInt("vote_count", voteCount ?: 0)
                putParcelableArrayList(
                    "vote_selected_items",
                    arrayListOf<VoteAnswerItemInfo>().apply {
                        addAll(
                            selectedItems ?: emptyList()
                        )
                    })
            }
            tracker.sendEvent(VoteTrackEvent.VoteSuccess(VoteTrackData.BundleObject(bundle)))
        }
    }

    /** 投票失败 **/
    override fun onVotePollFailed(message: String?) {
        if (!message?.trim().isNullOrEmpty()) {
            VotePollSdk.context?.let { context ->
                VotePollSdk.showToastMessage(message)
            }
        }
    }

    /**
     * 投票选项加载成功
     * @param pageType 页面类型
     * @param data 投票数据
     */
    override fun onVoteOptionsLoaded(pageType: String?, data: VoteDataInfo?) {}

    /**
     * 投票选项加载失败
     * @param voteId 投票ID
     * @param pageType 页面类型
     */
    override fun onVoteOptionsLoadError(voteId: String?, pageType: String?) {}

    /**
     * 投票点击事件埋点
     * @param pageType 投票活动pageType
     * @param selectedOptionTitle 投票选项名称
     * @param voteDataInfo 投票信息
     */
    override fun onTrackVoteClick(
        pageType: String?,
        selectedOptionTitle: String?,
        voteDataInfo: VoteDataInfo?
    ) {
        VotePollSdk.voteTracker?.let { tracker ->
            val bundle = VoteTrackData.Object(
                eventCategory = arrayOf(
                    "vote",
                    pageType,
                    voteDataInfo?.item?.voteId,
                    voteDataInfo?.item?.name
                ).filterNotNull().joinToString("::"),
                eventAction = "click",
                eventLabel = selectedOptionTitle
            )
            tracker.sendEvent(VoteTrackEvent.VoteSubmitSendClick(bundle))
        }
    }

    /**
     * 再次投票的点击事件埋点
     * @param pageType 投票活动pageType
     * @param voteDataInfo 投票信息
     */
    override fun onTrackVoteAgainClick(pageType: String?, voteDataInfo: VoteDataInfo?) {
        VotePollSdk.voteTracker?.let { tracker ->
            val bundle = VoteTrackData.Object(
                eventCategory = arrayOf(
                    "vote",
                    pageType,
                    voteDataInfo?.item?.voteId,
                    voteDataInfo?.item?.name
                ).filterNotNull().joinToString("::"),
                eventAction = "click",
                eventLabel = "vote again"
            )
            tracker.sendEvent(VoteTrackEvent.VoteAgainClick(bundle))
        }
    }

}